/**
 * GeckoLib glTF importer / Mesh → Cubes
 * Imports glTF as cubes by default, with an optional Poly Mesh mode that keeps
 * the original triangle geometry instead of approximating it with boxes.
 * CS2/Source 2 skin support:
 * - pivots for skinned joints are reconstructed from inverseBindMatrices;
 * - JOINTS_0 + WEIGHTS_0 can be preserved exactly in a cs2_skinning extension;
 * - native weighted meshes preview their real smooth deformation in Blockbench animation mode;
 * - the updated CS2 Lootbox renderer lets GeckoLib evaluate the bones, then
 *   performs linear-blend vertex skinning from those GeckoLib bone poses.
 * - legacy rigid GeckoMesh approximation modes remain selectable.
 *
 * The core (solveBox) does not depend on Blockbench and is covered by
 * tools/verify-conversion.mjs, which runs it against a real OBJ file.
 *
 * Install: Blockbench -> File -> Plugins -> Load Plugin from File -> this file.
 *
 * IMPORTANT: the file name must match PLUGIN_ID, otherwise Blockbench refuses
 * to load it. geckolib_model_importer.js <-> 'geckolib_model_importer'. Rename both together.
 */
(function () {

const PLUGIN_ID = 'geckolib_model_importer';

// All tolerances are relative. Absolute ones do not work here: models contain
// panels 0.001 px thick next to 8 px cubes (see the pitfalls in docs/format-notes.md).
const TOL_ORTHO = 1e-3;   // cosine between axes (flat case only)
const TOL_REL = 1e-4;     // fraction of the object bounds
const TOL_UV = 1e-3;      // texture pixels

// ---------------------------------------------------------------- vectors

const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const mul = (a, s) => [a[0] * s, a[1] * s, a[2] * s];
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const cross = (a, b) => [
	a[1] * b[2] - a[2] * b[1],
	a[2] * b[0] - a[0] * b[2],
	a[0] * b[1] - a[1] * b[0],
];
const len = a => Math.hypot(a[0], a[1], a[2]);
const norm = a => { const l = len(a); return l ? mul(a, 1 / l) : [0, 0, 0]; };
const dist = (a, b) => len(sub(a, b));

// ------------------------------------------------------------ box detection

/**
 * Decides from the unique vertices whether this is a rectangular box,
 * and returns its centre, axes and size.
 *
 * Face normals are deliberately NOT used: on degenerately thin faces the cross
 * product drops into numeric noise and lies (measured during the first analysis).
 */
function detectBox(pts) {
	if (pts.length === 8) return detectBox8(pts);
	if (pts.length === 4) return detectBox4(pts);
	return null;
}

/** Full box: look for three mutually orthogonal edges starting from p0. */
function detectBox8(pts) {
	const p0 = pts[0];
	const rest = pts.slice(1);
	const span = Math.max(...rest.map(p => dist(p, p0)));
	if (!span) return null;
	const tol = span * TOL_REL;

	for (let i = 0; i < rest.length; i++) {
		for (let j = i + 1; j < rest.length; j++) {
			for (let k = j + 1; k < rest.length; k++) {
				const e = [sub(rest[i], p0), sub(rest[j], p0), sub(rest[k], p0)];
				if (e.some(v => !len(v))) continue;

				// Orthogonality is checked as a deviation in UNITS OF LENGTH, not as an
				// angle between normalised edges. For a short edge (a panel 0.001 px
				// thick) the angle is defined by coordinate noise, and the angular
				// criterion rejects perfectly good boxes. The real check is the match
				// of all eight corners below.
				const skew = (a, b) => Math.abs(dot(e[a], e[b])) / Math.max(len(e[a]), len(e[b]));
				if (skew(0, 1) > tol || skew(1, 2) > tol || skew(0, 2) > tol) continue;

				// all 8 corners must reproduce as p0 + a subset sum of the edges
				const corners = [];
				for (const [a, b, c] of [[0,0,0],[1,0,0],[0,1,0],[0,0,1],[1,1,0],[1,0,1],[0,1,1],[1,1,1]]) {
					corners.push(add(p0, add(add(mul(e[0], a), mul(e[1], b)), mul(e[2], c))));
				}
				if (!sameSet(pts, corners, tol)) continue;

				return refineBox(pts, e);
			}
		}
	}
	return null;
}

/**
 * Refines the axes, centre and size of a box from its edges.
 *
 * A short edge must not be normalised: on a panel 0.001 px thick the edge is
 * 6e-5 long, and coordinate error (float32 from glTF especially) gives a
 * direction error of hundredths of a degree. Multiplied by the long dimensions
 * it scatters vertices by millipixels, and faces stop being recognised.
 *
 * So we take the two longest edges as the basis — those are measured precisely —
 * orthogonalise them, and obtain the third axis with a cross product.
 * Size and centre come from projecting every vertex: more precise than edges.
 */
function refineBox(pts, e) {
	const order = [0, 1, 2].sort((i, j) => len(e[j]) - len(e[i]));
	const u1 = norm(e[order[0]]);
	const u2 = norm(sub(e[order[1]], mul(u1, dot(e[order[1]], u1))));
	const u3 = cross(u1, u2);
	const axes = [u1, u2, u3];

	const size = [], mid = [];
	for (const a of axes) {
		const ds = pts.map(p => dot(p, a));
		const lo = Math.min(...ds), hi = Math.max(...ds);
		size.push(hi - lo);
		mid.push((lo + hi) / 2);
	}
	// the axes are orthonormal, so the centre is just the sum of per-axis midpoints
	const center = axes.reduce((acc, a, i) => add(acc, mul(a, mid[i])), [0, 0, 0]);
	return { center, axes, size };
}

/** Degenerate case: 4 vertices, a flat panel of zero thickness. */
function detectBox4(pts) {
	const p0 = pts[0];
	const rest = pts.slice(1);
	const span = Math.max(...rest.map(p => dist(p, p0)));
	if (!span) return null;
	const tol = span * TOL_REL;

	for (let i = 0; i < rest.length; i++) {
		for (let j = i + 1; j < rest.length; j++) {
			const e0 = sub(rest[i], p0), e1 = sub(rest[j], p0);
			const n0 = norm(e0), n1 = norm(e1);
			if (!len(n0) || !len(n1)) continue;
			if (Math.abs(dot(n0, n1)) > TOL_ORTHO) continue;
			if (!sameSet(pts, [p0, rest[i], rest[j], add(p0, add(e0, e1))], tol)) continue;

			return {
				center: add(p0, mul(add(e0, e1), 0.5)),
				axes: [n0, n1, norm(cross(n0, n1))],
				size: [len(e0), len(e1), 0],
			};
		}
	}
	return null;
}

/** Two point sets are equal as sets (within tolerance). */
function sameSet(a, b, tol) {
	if (a.length !== b.length) return false;
	const used = new Array(b.length).fill(false);
	for (const p of a) {
		const hit = b.findIndex((q, idx) => !used[idx] && dist(p, q) <= tol);
		if (hit < 0) return false;
		used[hit] = true;
	}
	return true;
}

// ------------------------------------------------- orientation candidates

/**
 * Box axes arrive in arbitrary order with arbitrary signs — that makes 24
 * different right-handed bases giving the same shape but a different rotation
 * and a different spread of the texture across faces.
 *
 * We return all 24, sorted by closeness to the identity matrix.
 * Which one is right is decided later, by where the UV land without a rotation
 * and without mirroring.
 */
function orientations(axes, size) {
	const perms = [[0,1,2],[0,2,1],[1,0,2],[1,2,0],[2,0,1],[2,1,0]];
	const out = [];
	for (const p of perms) {
		for (let mask = 0; mask < 8; mask++) {
			const vx = mul(axes[p[0]], mask & 1 ? -1 : 1);
			const vy = mul(axes[p[1]], mask & 2 ? -1 : 1);
			const vz = mul(axes[p[2]], mask & 4 ? -1 : 1);
			// right-handed bases only, otherwise the texture comes out mirrored
			if (dot(cross(vx, vy), vz) < 0.99) continue;
			out.push({ vx, vy, vz, size: [size[p[0]], size[p[1]], size[p[2]]], trace: vx[0] + vy[1] + vz[2] });
		}
	}
	return out.sort((a, b) => b.trace - a.trace);
}

// ----------------------------------------------------------------- UV

/**
 * For every cube face: the directions in which texture u and v grow, in the
 * cube's local coordinates.
 *
 * THIS IS ONLY A FALLBACK. Inside a live Blockbench the table is overwritten
 * by calibrateFaceDirs(), which measures the convention from the editor itself.
 *
 * The values below are what the measurement returned on Blockbench 5.1.6. Note
 * that `u x v = -n` on all six faces, i.e. the convention is chirally
 * consistent. Deriving it from mirroring statistics gave the opposite sign for
 * up/down and broke the picture — inference turned out worse than measurement.
 */
let FACE_DIRS = {
	north: { normal: [0, 0, -1], u: [-1, 0, 0], v: [0, -1, 0] },
	south: { normal: [0, 0,  1], u: [ 1, 0, 0], v: [0, -1, 0] },
	east:  { normal: [ 1, 0, 0], u: [0, 0, -1], v: [0, -1, 0] },
	west:  { normal: [-1, 0, 0], u: [0, 0,  1], v: [0, -1, 0] },
	up:    { normal: [0,  1, 0], u: [1, 0, 0], v: [0, 0,  1] },
	down:  { normal: [0, -1, 0], u: [1, 0, 0], v: [0, 0, -1] },
};
const FACE_NAMES = Object.keys(FACE_DIRS);

/**
 * Distributes mesh faces across the faces of the cube.
 * Strictly per face, not per vertex: one cube corner belongs to three faces and
 * carries its own UV on each; collecting by position would mix them up.
 */
function assignFaces(faces, center, o) {
	const half = mul(o.size, 0.5);
	const span = Math.max(...o.size) || 1;
	const tol = span * TOL_REL;
	const toLocal = p => {
		const d = sub(p, center);
		return [dot(d, o.vx), dot(d, o.vy), dot(d, o.vz)];
	};

	const samples = {};
	for (const name of FACE_NAMES) samples[name] = [];

	// The per-axis tolerance must not exceed half the thickness along that axis,
	// otherwise the two opposite sides of a 0.001 px panel merge: they sit exactly
	// one tolerance apart. The lower bound is needed for honestly zero thickness —
	// there both sides coincide, and the face must land on both of them.
	//
	const axisTol = a => Math.min(tol, Math.max(half[a] * 0.5, span * 1e-9));

	for (const face of faces) {
		const locals = face.positions.map(toLocal);
		for (const name of FACE_NAMES) {
			const n = FACE_DIRS[name].normal;
			const axis = n[0] ? 0 : n[1] ? 1 : 2;
			const at = axisTol(axis);
			// a mesh face lies on a cube face when ALL of its vertices are on that side
			if (!locals.every(l => Math.abs(dot(l, n) - half[axis]) < at)) continue;
			locals.forEach((pos, i) => {
				if (face.uvs[i]) samples[name].push({ pos, uv: face.uvs[i] });
			});
		}
	}
	return { samples, span };
}

/**
 * How many times the UV contradict the chosen face orientation.
 *
 * Texture u must stay constant along the face's v axis, and vice versa. If that
 * is broken the texture would have to be rotated by 90°, which geo.json cannot
 * express, so such an orientation is unusable.
 */
function countUVViolations(samples, span) {
	const tol = span * TOL_REL;
	let bad = 0;
	for (const name of FACE_NAMES) {
		const s = samples[name];
		const dirs = FACE_DIRS[name];
		for (let i = 0; i < s.length; i++) {
			for (let j = i + 1; j < s.length; j++) {
				const d = sub(s[i].pos, s[j].pos);
				if (Math.abs(dot(d, dirs.u)) < tol && Math.abs(s[i].uv[0] - s[j].uv[0]) > TOL_UV) bad++;
				if (Math.abs(dot(d, dirs.v)) < tol && Math.abs(s[i].uv[1] - s[j].uv[1]) > TOL_UV) bad++;
			}
		}
	}
	return bad;
}

/**
 * Builds the UV rectangle of a face from samples.
 *
 * Mirroring falls out naturally: if texture u decreases where the geometric one
 * grows, x1 ends up greater than x2 — Blockbench reads such a reversed
 * rectangle as a mirror.
 *
 * Degenerate faces are the exception. On panels 0.001 px thick the side faces
 * have almost no extent, and the texture direction on them is defined by noise.
 * Such axes are normalised (x1 < x2) so that random mirrors are not produced.
 *
 *
 * @param mirror false forces every rectangle to be normalised
 */
function buildFaceUV(samples, dirs, span, mirror) {
	if (!samples.length) return null;
	const tol = span * TOL_REL;

	const along = axis => {
		let lo = samples[0], hi = samples[0];
		let loP = dot(lo.pos, axis), hiP = loP;
		for (const s of samples) {
			const p = dot(s.pos, axis);
			if (p < loP) { lo = s; loP = p; }
			if (p > hiP) { hi = s; hiP = p; }
		}
		return { lo, hi, degenerate: hiP - loP < tol };
	};

	const u = along(dirs.u), v = along(dirs.v);
	let x1 = u.lo.uv[0], x2 = u.hi.uv[0];
	let y1 = v.lo.uv[1], y2 = v.hi.uv[1];

	if (!mirror || u.degenerate) { if (x1 > x2) [x1, x2] = [x2, x1]; }
	if (!mirror || v.degenerate) { if (y1 > y2) [y1, y2] = [y2, y1]; }

	return [x1, y1, x2, y2];
}

/** Builds UV for all six faces and counts how many came out mirrored. */
function buildFaces(samples, span, mirror) {
	const faceUV = {}, emptyFaces = [];
	let flips = 0;
	for (const name of FACE_NAMES) {
		const uv = buildFaceUV(samples[name], FACE_DIRS[name], span, mirror);
		if (!uv) { emptyFaces.push(name); continue; }
		faceUV[name] = uv;
		if (uv[0] > uv[2] || uv[1] > uv[3]) flips++;
	}
	return { faceUV, emptyFaces, flips };
}

/**
 * Bounding box from faces — the fallback for objects that are not boxes.
 *
 *
 * The shape is coarsened to an axis-aligned box. Without regenerating the
 * texture nothing more precise is possible, and it is far better than losing
 * the object, or the whole model.
 */
/**
 * Unit normal of a triangle, or null for a degenerate one.
 *
 * File normals cannot be trusted here: on approximated objects they are
 * smoothed per vertex and point anywhere. We compute from the points.
 */
function triangleNormal(p) {
	if (!p || p.length < 3) return null;
	const a = [p[1][0] - p[0][0], p[1][1] - p[0][1], p[1][2] - p[0][2]];
	const b = [p[2][0] - p[0][0], p[2][1] - p[0][1], p[2][2] - p[0][2]];
	const n = [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
	const len = Math.hypot(n[0], n[1], n[2]);
	return len > 1e-12 ? [n[0] / len, n[1] / len, n[2] / len] : null;
}

/**
 * Turning whatever a file draws with into plain triangles.
 *
 * Only mode 4 was read, and everything else was skipped with a warning. That
 * sounds cautious and was not: every model in the reference set — six of them,
 * from three different authors, all exported through Sketchfab — is written as
 * triangle strips, so the importer skipped every primitive in every one of them
 * and reported finding no cubes at all. The geometry was perfect: twenty-four
 * vertices to a primitive, which is six faces of four corners.
 *
 * A strip and a fan are not other kinds of geometry. They are the same triangles
 * written down more briefly, and unrolling them is four lines.
 *
 * Two things can go wrong and both have bitten.
 *
 * <b>Winding.</b> In a strip every other triangle is wound the other way and the
 * file relies on the reader to flip it back. A reader that does not gets every
 * second face inside out, which shows as a cube with holes rather than as an
 * error.
 *
 * <b>Stitches.</b> A strip is one unbroken ribbon, so a box drawn as a strip has
 * to jump from face to face, and it jumps by repeating an index. Thirty-four
 * indices come out as thirty-two triangles of which <em>twenty</em> are those
 * jumps and only twelve are the box. A jump draws nothing — it has no area — but
 * its three corners are read from two different faces of the texture at once, and
 * the UV rectangle worked out for each side then stretches over its neighbours.
 * That is what "the textures land completely wrong" looked like, and it does not
 * happen in files written as plain triangles, which is why it survived the first
 * fix.
 *
 * So a triangle with a repeated corner is dropped. It is not a triangle.
 */
const TRIANGULATE = {
	// TRIANGLES: already triangles.
	4: idx => real(triples(idx)),
	// TRIANGLE_STRIP: each new index closes a triangle with the two before it,
	// and the odd ones are reversed so that every face keeps facing outwards.
	5: idx => {
		const out = [];
		for (let i = 0; i + 2 < idx.length; i++) {
			out.push(i % 2 === 0
				? [idx[i], idx[i + 1], idx[i + 2]]
				: [idx[i + 1], idx[i], idx[i + 2]]);
		}
		return real(out);
	},
	// TRIANGLE_FAN: every triangle shares the first index.
	6: idx => {
		const out = [];
		for (let i = 1; i + 1 < idx.length; i++) out.push([idx[0], idx[i], idx[i + 1]]);
		return real(out);
	},
};

function triples(idx) {
	const out = [];
	for (let i = 0; i + 2 < idx.length; i += 3) out.push([idx[i], idx[i + 1], idx[i + 2]]);
	return out;
}

/** Only the triangles that are triangles: two corners the same is no area at all. */
function real(tris) {
	return tris.filter(t => t[0] !== t[1] && t[1] !== t[2] && t[0] !== t[2]);
}

function boxFromBounds(faces) {
	const lo = [Infinity, Infinity, Infinity], hi = [-Infinity, -Infinity, -Infinity];
	const uvLo = [Infinity, Infinity], uvHi = [-Infinity, -Infinity];
	for (const f of faces) {
		for (const p of f.positions) for (let a = 0; a < 3; a++) {
			if (p[a] < lo[a]) lo[a] = p[a];
			if (p[a] > hi[a]) hi[a] = p[a];
		}
		for (const u of f.uvs) if (u) for (let a = 0; a < 2; a++) {
			if (u[a] < uvLo[a]) uvLo[a] = u[a];
			if (u[a] > uvHi[a]) uvHi[a] = u[a];
		}
	}
	if (!isFinite(lo[0])) return null;
	const whole = isFinite(uvLo[0]) ? [uvLo[0], uvLo[1], uvHi[0], uvHi[1]] : [0, 0, 0, 0];

	// UV are assigned to EACH face separately by sorting the source triangles into
	// six directions. One shared rectangle for every face was exactly why
	// approximated objects looked like mush: every side showed the bounds of the
	// whole unwrap at once. The wedge shape is lost regardless, but the texture
	// then lands sensibly.
	const buckets = {};
	for (const name of FACE_NAMES) buckets[name] = [Infinity, Infinity, -Infinity, -Infinity];
	const seen = {};
	for (const f of faces) {
		if (!f.uvs || f.uvs.length < 3 || f.uvs.some(u => !u)) continue;
		const n = triangleNormal(f.positions);
		if (!n) continue;
		// the face whose direction is closest to the triangle normal
		let best = null, bestDot = -Infinity;
		for (const name of FACE_NAMES) {
			const d = FACE_DIRS[name].normal;
			const dot = n[0] * d[0] + n[1] * d[1] + n[2] * d[2];
			if (dot > bestDot) { bestDot = dot; best = name; }
		}
		const b = buckets[best];
		for (const u of f.uvs) {
			if (u[0] < b[0]) b[0] = u[0];
			if (u[1] < b[1]) b[1] = u[1];
			if (u[0] > b[2]) b[2] = u[0];
			if (u[1] > b[3]) b[3] = u[1];
		}
		seen[best] = true;
	}

	const faceUV = {};
	// A face with no triangles of its own gets the overall bounds: leaving it
	// empty is not an option — in Minecraft a cube has all six sides.
	for (const name of FACE_NAMES) faceUV[name] = seen[name] ? buckets[name] : whole.slice();
	return {
		center: [0, 1, 2].map(a => (lo[a] + hi[a]) / 2),
		size: [0, 1, 2].map(a => hi[a] - lo[a]),
		vx: [1, 0, 0], vy: [0, 1, 0], vz: [0, 0, 1],
		faceUV, emptyFaces: [], mirrored: 0, violations: 0,
		approximated: true,
	};
}

/**
 * Whether this object is meaningful at all.
 *
 * Exports contain fragments of 2-4 vertices with zero volume: leftovers of
 * triangulation and degenerate faces. Losing a whole model over them is absurd.
 */
function isDegenerate(faces) {
	const uniq = new Map();
	for (const f of faces) for (const p of f.positions) uniq.set(p.map(v => v.toFixed(5)).join(','), p);
	if (uniq.size <= 2) return true;
	const pts = [...uniq.values()];
	const lo = [Infinity, Infinity, Infinity], hi = [-Infinity, -Infinity, -Infinity];
	for (const p of pts) for (let a = 0; a < 3; a++) {
		if (p[a] < lo[a]) lo[a] = p[a];
		if (p[a] > hi[a]) hi[a] = p[a];
	}
	const dims = [0, 1, 2].map(a => hi[a] - lo[a]).sort((x, y) => y - x);
	// a flat shape is fine (panels), but a thread or a point is not
	return dims[1] < dims[0] * 1e-4;
}

/**
 * Splits a set of faces into connected components.
 *
 * Many exporters (Sketchfab included) merge every cube into one mesh: 1416
 * vertices and 708 triangles instead of 59 separate boxes. Without splitting,
 * such an object is not recognised as a box and the model gets rejected.
 *
 * Connectivity is computed from shared vertex positions: neighbouring cubes
 * rarely share vertices, while inside one cube they always do.
 */
function splitComponents(faces) {
	if (faces.length < 2) return [faces];

	const parent = faces.map((_, i) => i);
	const find = i => { while (parent[i] !== i) { parent[i] = parent[parent[i]]; i = parent[i]; } return i; };
	const union = (a, b) => { a = find(a); b = find(b); if (a !== b) parent[b] = a; };

	// Connectivity goes by a shared EDGE, not a shared vertex: cubes touching
	// along an edge share two vertices, and vertex connectivity glued them into
	// one 14-vertex object instead of two 8-vertex boxes.
	// Edges count, but only HONEST ones: in a closed surface an edge belongs to
	// exactly two triangles. Where two cubes meet along an edge it has four
	// adjacent triangles — such an edge must not be joined, or the cubes fuse
	// into a single 14-vertex object.
	const key = p => p.map(v => v.toFixed(5)).join(',');
	const byEdge = new Map();
	faces.forEach((f, i) => {
		const ks = f.positions.map(key);
		for (let a = 0; a < ks.length; a++) {
			const b = (a + 1) % ks.length;
			if (ks[a] === ks[b]) continue;
			const edge = ks[a] < ks[b] ? ks[a] + '|' + ks[b] : ks[b] + '|' + ks[a];
			if (!byEdge.has(edge)) byEdge.set(edge, []);
			byEdge.get(edge).push(i);
		}
	});
	for (const [, list] of byEdge) {
		if (list.length !== 2) continue;
		union(list[0], list[1]);
	}

	const groups = new Map();
	faces.forEach((f, i) => {
		const root = find(i);
		if (!groups.has(root)) groups.set(root, []);
		groups.get(root).push(f);
	});
	return [...groups.values()];
}

// ------------------------------------------------------------------ core

/**
 * The main entry point. Input is normalised so that the same maths works both
 * from Blockbench and from the Node test that reads an OBJ.
 *
 * @param faces [{ positions: [[x,y,z],…], uvs: [[u,v]|null,…] }]
 * @param opts.mirror keep mirrored UV (default: yes)
 * @returns { center, size, vx, vy, vz, faceUV, emptyFaces, violations, mirrored } | { error }
 */
function solveBox(faces, opts) {
	const mirror = !opts || opts.mirror !== false;
	const uniq = new Map();
	for (const f of faces) for (const p of f.positions) {
		uniq.set(p.map(n => n.toFixed(6)).join(','), p);
	}
	const pts = [...uniq.values()];

	const box = detectBox(pts);
	if (!box) return { error: `not a box (${pts.length} unique vertices)` };

	// We try all 24 orientations and choose by three criteria, most important
	// first: fewer violations (a 90° UV rotation), fewer mirrors, and only then
	// closeness to the identity matrix.
	//
	// The order matters. Rotating a cube by 180° does not change the roles of u
	// and v, so it produces no violations and by the first criterion ties with the
	// identity basis. If the tie-break is closeness to identity, the 180° variant
	// always loses — and the texture rotation then has to be faked with mirroring,
	// which looks like flipped on both axes.
	// That is why the mirror count comes before closeness to identity.
	let best = null;
	for (const o of orientations(box.axes, box.size)) {
		const { samples, span } = assignFaces(faces, box.center, o);
		const violations = countUVViolations(samples, span);
		// mirrors are always counted honestly for the choice, regardless of the
		// option, otherwise with mirroring off the criterion collapses to zero
		const built = buildFaces(samples, span, true);
		const cand = { o, samples, span, violations, ...built };
		if (!best
			|| violations < best.violations
			|| (violations === best.violations && built.flips < best.flips)) best = cand;
		if (!violations && !built.flips) break;
	}
	if (!best) return { error: 'could not build a right-handed axis system' };

	// the final layout is rebuilt taking the user option into account
	const final = mirror ? best : buildFaces(best.samples, best.span, false);

	return {
		center: box.center,
		size: best.o.size,
		vx: best.o.vx, vy: best.o.vy, vz: best.o.vz,
		faceUV: final.faceUV,
		emptyFaces: final.emptyFaces,
		mirrored: best.flips,
		violations: best.violations,
	};
}

// ------------------------------------------------------------- glTF parsing

const GLTF_COMPONENTS = {
	5120: { size: 1, read: (dv, o) => dv.getInt8(o) },
	5121: { size: 1, read: (dv, o) => dv.getUint8(o) },
	5122: { size: 2, read: (dv, o) => dv.getInt16(o, true) },
	5123: { size: 2, read: (dv, o) => dv.getUint16(o, true) },
	5125: { size: 4, read: (dv, o) => dv.getUint32(o, true) },
	5126: { size: 4, read: (dv, o) => dv.getFloat32(o, true) },
};
const GLTF_TYPE_SIZE = { SCALAR: 1, VEC2: 2, VEC3: 3, VEC4: 4, MAT2: 4, MAT3: 9, MAT4: 16 };

// 4x4 matrices, column-major order as in glTF
const matIdentity = () => [1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1];

function matMul(a, b) {
	const out = new Array(16);
	for (let c = 0; c < 4; c++) {
		for (let r = 0; r < 4; r++) {
			out[c * 4 + r] = a[r] * b[c * 4] + a[4 + r] * b[c * 4 + 1]
				+ a[8 + r] * b[c * 4 + 2] + a[12 + r] * b[c * 4 + 3];
		}
	}
	return out;
}

/**
 * Invert a glTF column-major 4x4 matrix.
 *
 * Skin inverse-bind matrices are authoritative for the bind-pose location of a
 * joint relative to the skinned mesh.  Using THREE here also avoids maintaining
 * a second hand-written matrix inverse next to Blockbench's own math library.
 */
function matInverse(m) {
	try {
		const tm = new THREE.Matrix4().fromArray(m);
		const det = tm.determinant();
		if (!Number.isFinite(det) || Math.abs(det) < 1e-12) return null;
		return tm.invert().toArray();
	} catch (e) {
		return null;
	}
}

/**
 * Whether the node rotation is axis-aligned, i.e. maps axes onto axes.
 *
 * Distinguishes a coordinate-system conversion (Z-up -> Y-up, always a multiple
 * of 90°) from arbitrary showcase placement. The marker is that the rotation
 * matrix turns out to be a signed permutation: exactly one unit per row and
 * per column, zeros elsewhere.
 *
 * Returns {matrix, quat} carrying a PROPER rotation only (determinant +1).
 *
 * A signed-permutation matrix with determinant -1 is a reflection, not a
 * rotation. Treating it as an axis rotation mirrors the entire imported model
 * and also feeds an invalid reflection matrix into quatFromMat(). Reflected
 * wrapper transforms are therefore rejected here and handled as disposable
 * export/showcase wrappers by the caller.
 *
 * The wrapper's offset and scale are dropped either way, or null is returned
 * if the transform is arbitrary/reflected.
 */
function axisRotationOf(node) {
	if (!node) return null;
	let m;
	if (node.matrix) m = node.matrix;
	else if (node.rotation) m = matFromTRS([0, 0, 0], node.rotation, [1, 1, 1]);
	else return null;

	// normalise the columns: the wrapper scale is irrelevant, directions matter
	const cols = [0, 1, 2].map(i => {
		const v = [m[i * 4], m[i * 4 + 1], m[i * 4 + 2]];
		const len = Math.hypot(v[0], v[1], v[2]);
		return len > 1e-6 ? v.map(x => x / len) : null;
	});
	if (cols.some(c => !c)) return null;

	const used = new Set();
	for (const c of cols) {
		// exactly one component is ±1 and the rest zero, else it is not axis-aligned
		const nz = c.map((v, i) => [v, i]).filter(([v]) => Math.abs(v) > 1e-4);
		if (nz.length !== 1 || Math.abs(Math.abs(nz[0][0]) - 1) > 1e-4) return null;
		if (used.has(nz[0][1])) return null;      // two axes onto one is not a rotation
		used.add(nz[0][1]);
	}

	const rounded = cols.map(c => c.map(v => Math.round(v)));

	// IMPORTANT: a signed permutation can be either a rotation (+1 determinant)
	// or a reflection (-1 determinant). The old importer accepted both. On models
	// whose export wrapper contains a negative scale, that reflected the complete
	// GeckoLib model. A quaternion cannot represent a reflection either, so
	// quatFromMat() on such a matrix also corrupted animated axes.
	const det = dot(rounded[0], cross(rounded[1], rounded[2]));
	if (det < 0) return null;

	const matrix = [
		rounded[0][0], rounded[0][1], rounded[0][2], 0,
		rounded[1][0], rounded[1][1], rounded[1][2], 0,
		rounded[2][0], rounded[2][1], rounded[2][2], 0,
		0, 0, 0, 1,
	];
	return { matrix, quat: quatFromMat(matrix) };
}

/**
 * Detects the specific failure case axisRotationOf intentionally rejects:
 * an axis-aligned reflected basis (determinant -1).
 */
function hasAxisReflection(node) {
	if (!node) return false;
	let m;
	if (node.matrix) m = node.matrix;
	else if (node.rotation || node.scale) {
		m = matFromTRS([0, 0, 0], node.rotation || [0, 0, 0, 1], node.scale || [1, 1, 1]);
	} else return false;

	const cols = [0, 1, 2].map(i => {
		const v = [m[i * 4], m[i * 4 + 1], m[i * 4 + 2]];
		const l = Math.hypot(v[0], v[1], v[2]);
		return l > 1e-6 ? v.map(x => x / l) : null;
	});
	if (cols.some(c => !c)) return false;

	const rounded = [];
	const used = new Set();
	for (const c of cols) {
		const nz = c.map((v, i) => [v, i]).filter(([v]) => Math.abs(v) > 1e-4);
		if (nz.length !== 1 || Math.abs(Math.abs(nz[0][0]) - 1) > 1e-4) return false;
		if (used.has(nz[0][1])) return false;
		used.add(nz[0][1]);
		rounded.push(c.map(v => Math.round(v)));
	}
	return dot(rounded[0], cross(rounded[1], rounded[2])) < 0;
}

/** Quaternion from a rotation matrix (column-major, as in glTF). */
function quatFromMat(m) {
	const [m00, m01, m02, , m10, m11, m12, , m20, m21, m22] = m;
	const tr = m00 + m11 + m22;
	if (tr > 0) {
		const s = Math.sqrt(tr + 1) * 2;
		return [(m12 - m21) / s, (m20 - m02) / s, (m01 - m10) / s, 0.25 * s];
	}
	if (m00 > m11 && m00 > m22) {
		const s = Math.sqrt(1 + m00 - m11 - m22) * 2;
		return [0.25 * s, (m10 + m01) / s, (m20 + m02) / s, (m12 - m21) / s];
	}
	if (m11 > m22) {
		const s = Math.sqrt(1 + m11 - m00 - m22) * 2;
		return [(m10 + m01) / s, 0.25 * s, (m21 + m12) / s, (m20 - m02) / s];
	}
	const s = Math.sqrt(1 + m22 - m00 - m11) * 2;
	return [(m20 + m02) / s, (m21 + m12) / s, 0.25 * s, (m01 - m10) / s];
}

function matFromTRS(t, q, s) {
	const [x, y, z, w] = q;
	const x2 = x + x, y2 = y + y, z2 = z + z;
	const xx = x * x2, xy = x * y2, xz = x * z2;
	const yy = y * y2, yz = y * z2, zz = z * z2;
	const wx = w * x2, wy = w * y2, wz = w * z2;
	return [
		(1 - (yy + zz)) * s[0], (xy + wz) * s[0], (xz - wy) * s[0], 0,
		(xy - wz) * s[1], (1 - (xx + zz)) * s[1], (yz + wx) * s[1], 0,
		(xz + wy) * s[2], (yz - wx) * s[2], (1 - (xx + yy)) * s[2], 0,
		t[0], t[1], t[2], 1,
	];
}

const matApply = (m, p) => [
	m[0] * p[0] + m[4] * p[1] + m[8] * p[2] + m[12],
	m[1] * p[0] + m[5] * p[1] + m[9] * p[2] + m[13],
	m[2] * p[0] + m[6] * p[1] + m[10] * p[2] + m[14],
];

/**
 * Extracts only the signed orthogonal basis from a glTF transform matrix.
 *
 * A quaternion can represent rotation, but not a reflection. Some CS2 assets
 * inherit a negative scale from a parent node. Geometry was already baked with
 * that mirrored basis, while animation deltas used only parentQuat and therefore
 * lost the reflection, making clips move/rotate toward the opposite/back side.
 */
function signedBasisFromMat(m) {
	// Parent transforms may contain non-uniform scale or a mirrored axis.
	// Normalising each column independently is not enough after nested scales:
	// the columns can be non-orthogonal, and feeding that matrix into a
	// quaternion conversion introduces visible rotation drift.
	//
	// Gram-Schmidt gives us a stable orthonormal frame while the sign of the
	// original determinant preserves reflections.
	const rawX = [m[0], m[1], m[2]];
	const rawY = [m[4], m[5], m[6]];
	const rawZ = [m[8], m[9], m[10]];
	const normalise = v => {
		const l = Math.hypot(v[0], v[1], v[2]) || 1;
		return [v[0] / l, v[1] / l, v[2] / l];
	};
	const x = normalise(rawX);
	const yProj = dot(rawY, x);
	let y = [
		rawY[0] - x[0] * yProj,
		rawY[1] - x[1] * yProj,
		rawY[2] - x[2] * yProj,
	];
	if (Math.hypot(y[0], y[1], y[2]) < 1e-8) {
		const fallback = Math.abs(x[0]) < 0.8 ? [1, 0, 0] : [0, 1, 0];
		const d = dot(fallback, x);
		y = [
			fallback[0] - x[0] * d,
			fallback[1] - x[1] * d,
			fallback[2] - x[2] * d,
		];
	}
	y = normalise(y);
	let z = normalise(cross(x, y));

	const rawDet =
		rawX[0] * (rawY[1] * rawZ[2] - rawY[2] * rawZ[1])
		- rawY[0] * (rawX[1] * rawZ[2] - rawX[2] * rawZ[1])
		+ rawZ[0] * (rawX[1] * rawY[2] - rawX[2] * rawY[1]);
	if (rawDet < 0) z = [-z[0], -z[1], -z[2]];

	return [
		x[0], x[1], x[2], 0,
		y[0], y[1], y[2], 0,
		z[0], z[1], z[2], 0,
		0, 0, 0, 1,
	];
}

/** Full 3x3 linear part of a transform (rotation + signed scale/shear). */
function linearPartFromMat(m) {
	return [
		m[0], m[1], m[2], 0,
		m[4], m[5], m[6], 0,
		m[8], m[9], m[10], 0,
		0, 0, 0, 1,
	];
}

function basisDeterminant(m) {
	return m[0] * (m[5] * m[10] - m[9] * m[6])
		- m[4] * (m[1] * m[10] - m[9] * m[2])
		+ m[8] * (m[1] * m[6] - m[5] * m[2]);
}

/** Quaternions [x, y, z, w]. Needed to accumulate rest rotation down the tree. */
const qMul = (a, b) => [
	a[3] * b[0] + a[0] * b[3] + a[1] * b[2] - a[2] * b[1],
	a[3] * b[1] - a[0] * b[2] + a[1] * b[3] + a[2] * b[0],
	a[3] * b[2] + a[0] * b[1] - a[1] * b[0] + a[2] * b[3],
	a[3] * b[3] - a[0] * b[0] - a[1] * b[1] - a[2] * b[2],
];

/** base64 -> Uint8Array, without depending on the environment. */
function base64ToBytes(b64) {
	if (typeof atob === 'function') {
		const bin = atob(b64);
		const out = new Uint8Array(bin.length);
		for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
		return out;
	}
	return new Uint8Array(Buffer.from(b64, 'base64'));
}

/** Splits a .glb container into its JSON and binary chunks. */
function parseGLB(bytes) {
	const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
	if (dv.getUint32(0, true) !== 0x46546C67) throw new Error('not a .glb file (missing glTF signature)');
	const total = dv.getUint32(8, true);
	let offset = 12, json = null, bin = null;
	while (offset < total) {
		const len = dv.getUint32(offset, true);
		const type = dv.getUint32(offset + 4, true);
		const start = offset + 8;
		if (type === 0x4E4F534A) json = JSON.parse(new TextDecoder().decode(bytes.subarray(start, start + len)));
		else if (type === 0x004E4942) bin = bytes.subarray(start, start + len);
		offset = start + len + (len % 4 ? 4 - (len % 4) : 0);
	}
	if (!json) throw new Error('.glb has no JSON chunk');
	return { json, bin };
}

/** Reads a whole accessor: an array of tuples sized by component count. */
function readAccessor(gltf, buffers, index) {
	const acc = gltf.accessors[index];
	const comp = GLTF_COMPONENTS[acc.componentType];
	if (!comp) throw new Error(`unknown componentType ${acc.componentType}`);
	const n = GLTF_TYPE_SIZE[acc.type];
	if (!n) throw new Error(`unknown accessor type ${acc.type}`);

	const out = [];
	if (acc.bufferView === undefined) {
		for (let i = 0; i < acc.count; i++) out.push(new Array(n).fill(0));
	} else {
		const view = gltf.bufferViews[acc.bufferView];
		const buf = buffers[view.buffer];
		if (!buf) throw new Error(`missing buffer ${view.buffer}`);
		const dv = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
		const base = (view.byteOffset || 0) + (acc.byteOffset || 0);
		const stride = view.byteStride || comp.size * n;
		for (let i = 0; i < acc.count; i++) {
			const el = [];
			for (let c = 0; c < n; c++) el.push(comp.read(dv, base + i * stride + c * comp.size));
			out.push(el);
		}
	}

	// sparse accessors: some values are overridden
	if (acc.sparse) {
		const idxAcc = acc.sparse.indices, valAcc = acc.sparse.values;
		const idxView = gltf.bufferViews[idxAcc.bufferView];
		const valView = gltf.bufferViews[valAcc.bufferView];
		const idxComp = GLTF_COMPONENTS[idxAcc.componentType];
		const ib = buffers[idxView.buffer], vb = buffers[valView.buffer];
		const idv = new DataView(ib.buffer, ib.byteOffset, ib.byteLength);
		const vdv = new DataView(vb.buffer, vb.byteOffset, vb.byteLength);
		for (let i = 0; i < acc.sparse.count; i++) {
			const target = idxComp.read(idv, (idxView.byteOffset || 0) + (idxAcc.byteOffset || 0) + i * idxComp.size);
			const el = [];
			for (let c = 0; c < n; c++) {
				el.push(comp.read(vdv, (valView.byteOffset || 0) + (valAcc.byteOffset || 0) + (i * n + c) * comp.size));
			}
			out[target] = el;
		}
	}
	return out;
}

// ---------------------------------------------- animation maths (pure)

const qConj = q => [-q[0], -q[1], -q[2], q[3]];

/** Rotates a vector by a quaternion. */
function qRotate(q, v) {
	const [x, y, z, w] = q;
	const ix = w * v[0] + y * v[2] - z * v[1];
	const iy = w * v[1] + z * v[0] - x * v[2];
	const iz = w * v[2] + x * v[1] - y * v[0];
	const iw = -x * v[0] - y * v[1] - z * v[2];
	return [
		ix * w + iw * -x + iy * -z - iz * -y,
		iy * w + iw * -y + iz * -x - ix * -z,
		iz * w + iw * -z + ix * -y - iy * -x,
	];
}

/**
 * Channel value at an arbitrary point in time.
 *
 * Needed to put a bone's position and rotation keyframes on THE SAME times.
 * When the times differ the bone pose drifts apart in the editor — seen on
 * walking and run, where position had 5 marks and rotation only 3.
 */
function qNormalize(q) {
	const l = Math.hypot(q[0], q[1], q[2], q[3]) || 1;
	return [q[0] / l, q[1] / l, q[2] / l, q[3] / l];
}

/** Exact shortest-arc spherical interpolation for glTF quaternion LINEAR tracks. */
function qSlerp(a, b, t) {
	let bb = b.slice();
	let d = a[0] * bb[0] + a[1] * bb[1] + a[2] * bb[2] + a[3] * bb[3];
	if (d < 0) {
		d = -d;
		bb = bb.map(v => -v);
	}
	if (d > 0.9995) {
		return qNormalize(a.map((v, i) => v + (bb[i] - v) * t));
	}
	const theta = Math.acos(Math.max(-1, Math.min(1, d)));
	const sinTheta = Math.sin(theta) || 1;
	const wa = Math.sin((1 - t) * theta) / sinTheta;
	const wb = Math.sin(t * theta) / sinTheta;
	return qNormalize(a.map((v, i) => v * wa + bb[i] * wb));
}

/** Value stored at a glTF key. CUBICSPLINE stores in/value/out triplets. */
function channelKeyValue(ch, index) {
	if ((ch.interpolation || 'LINEAR') === 'CUBICSPLINE') return ch.values[index * 3 + 1];
	return ch.values[index];
}

function sampleChannel(ch, t) {
	const { times, values, path } = ch;
	if (!times.length) return path === 'rotation' ? [0, 0, 0, 1] : [0, 0, 0];
	if (t <= times[0]) return channelKeyValue(ch, 0).slice();
	if (t >= times[times.length - 1]) return channelKeyValue(ch, times.length - 1).slice();
	let i = 0;
	while (i + 1 < times.length && times[i + 1] < t) i++;
	const dt = times[i + 1] - times[i];
	const k = dt > 0 ? (t - times[i]) / dt : 0;
	const interpolation = ch.interpolation || 'LINEAR';
	const a = channelKeyValue(ch, i);
	const b = channelKeyValue(ch, i + 1);

	if (interpolation === 'STEP') return a.slice();

	if (interpolation === 'CUBICSPLINE') {
		// glTF cubic spline layout for each key: inTangent, value, outTangent.
		// Tangents are derivatives per second and therefore get multiplied by dt.
		const outTan = values[i * 3 + 2];
		const inTan = values[(i + 1) * 3];
		const k2 = k * k, k3 = k2 * k;
		const h00 = 2 * k3 - 3 * k2 + 1;
		const h10 = k3 - 2 * k2 + k;
		const h01 = -2 * k3 + 3 * k2;
		const h11 = k3 - k2;
		const out = a.map((v, j) =>
			h00 * v + h10 * dt * outTan[j] + h01 * b[j] + h11 * dt * inTan[j]);
		return path === 'rotation' ? qNormalize(out) : out;
	}

	if (path === 'rotation') return qSlerp(a, b, k);
	return a.map((v, j) => v + (b[j] - v) * k);
}

/**
 * Bone rotation offset relative to the rest pose.
 *
 * Kept in the core so the very same formula can be run from Node
 * (tools/verify-animation.mjs) and not only judged by eye in the editor.
 */
function boneDeltaRotation(rest, parentQuat, value, preMultiply) {
	const q0inv = qConj(rest.rotation);
	const local = preMultiply ? qMul(q0inv, value) : qMul(value, q0inv);
	// the bone sits in the model frame, so the offset is converted into it too
	return qMul(qMul(parentQuat, local), qConj(parentQuat));
}

/**
 * Bone position offset, in pixels.
 *
 * @param deltaRot rotation offset of the same bone; only the 'rt' mode needs it
 *
 * The 'rt' mode pre-compensates the rotation: if Blockbench composes the local
 * matrix as R·T (offset INSIDE the rotation), the stored value arrives rotated,
 * and to get the intended offset it must be rotated back in advance.
 * Under a T·R composition no such correction is needed.
 */
function boneDeltaPosition(rest, parentQuat, value, mode, deltaRot, unitScale = 16) {
	const base = mode === 'absolute' ? [0, 0, 0] : rest.translation;
	const d = [value[0] - base[0], value[1] - base[1], value[2] - base[2]];
	let out = mode === 'local' ? d : qRotate(parentQuat, d);
	if (mode === 'rt' && deltaRot) out = qRotate(qConj(deltaRot), out);
	return [out[0] * unitScale, out[1] * unitScale, out[2] * unitScale];
}

/**
 * Parses glTF animations into a convenient shape.
 *
 * In glTF a channel holds ABSOLUTE TRS values of a node at every point in time,
 * while Blockbench and GeckoLib store animation as an OFFSET from the rest pose.
 * The conversion happens later, once each bone's rest pose is known — here we
 * only extract the data faithfully.
 */
function parseAnimations(gltf, buffers, warnings) {
	const out = [];
	for (const anim of gltf.animations || []) {
		const channels = [];
		let length = 0;
		for (const ch of anim.channels || []) {
			const sampler = anim.samplers[ch.sampler];
			if (!sampler || !ch.target || ch.target.node === undefined) continue;
			if (ch.target.path === 'weights') {
				warnings.push(`animation “${anim.name}”: morph targets are not supported`);
				continue;
			}
			try {
				const times = readAccessor(gltf, buffers, sampler.input).map(t => t[0]);
				const values = readAccessor(gltf, buffers, sampler.output);
				if (times.length) length = Math.max(length, times[times.length - 1]);
				channels.push({
					node: ch.target.node,
					path: ch.target.path,          // translation | rotation | scale
					interpolation: sampler.interpolation || 'LINEAR',
					times, values,
				});
			} catch (e) {
				warnings.push(`animation “${anim.name}”: channel skipped (${(e && e.message) || e})`);
			}
		}
		out.push({ name: anim.name || `animation_${out.length}`, length, channels });
	}
	return out;
}

/**
 * Packs textures into a single atlas.
 *
 * GeckoLib supports one texture per model, while exports can carry eight.
 * Shelf packing by descending height is enough: textures are almost always
 * powers of two and pack tightly.
 *
 * @param sizes [{width, height}]
 * @returns { width, height, rects: [{x, y, w, h}] }
 */
function packAtlas(sizes) {
	const order = sizes.map((s, i) => ({ i, w: s.width, h: s.height }))
		.sort((a, b) => b.h - a.h || b.w - a.w);
	const area = order.reduce((s, r) => s + r.w * r.h, 0);
	const pow2 = v => { let p = 1; while (p < v) p *= 2; return p; };

	// try widths from the smallest power of two upwards, take the first where
	// the total shelf height also fits into a power of two
	let best = null;
	for (let width = pow2(Math.max(Math.ceil(Math.sqrt(area)), order[0] ? order[0].w : 1)); width <= 8192; width *= 2) {
		const rects = new Array(sizes.length);
		let x = 0, y = 0, shelf = 0, ok = true;
		for (const r of order) {
			if (r.w > width) { ok = false; break; }
			if (x + r.w > width) { y += shelf; x = 0; shelf = 0; }
			rects[r.i] = { x, y, w: r.w, h: r.h };
			x += r.w;
			if (r.h > shelf) shelf = r.h;
		}
		if (!ok) continue;
		const height = pow2(y + shelf);
		best = { width, height, rects };
		if (height <= width) break;   // compact enough
	}
	return best || { width: 16, height: 16, rects: sizes.map(() => ({ x: 0, y: 0, w: 16, h: 16 })) };
}

/** Quaternion for a rotation about one axis, angle in degrees. */
function qAxis(axis, deg) {
	const h = (deg * Math.PI / 180) / 2;
	const q = [0, 0, 0, Math.cos(h)];
	q[axis] = Math.sin(h);
	return q;
}

/**
 * A global extra rotation for the whole model.
 *
 * Needed because up means different things to different exporters: a Sketchfab
 * export carries a Z-up -> Y-up conversion, but the author's original
 * orientation is invisible, so a model may still arrive lying down. There is no
 */
function correctionQuat(rot) {
	if (!rot) return [0, 0, 0, 1];
	let q = [0, 0, 0, 1];
	for (let a = 0; a < 3; a++) if (rot[a]) q = qMul(qAxis(a, rot[a]), q);
	return q;
}

/**
 * Picks the coordinate scale.
 *
 * A glTF unit means different things per exporter: for Blockbench it is a block
 * (16 px), for Sketchfab exports it is already a pixel. A hardcoded ×16 blew
 * such a model up 16 times (538 px across instead of 34).
 *
 * We take the scale that puts the largest dimension into a range reasonable for
 * Minecraft; all else being equal, 16 is preferred.
 */
const NICE_SCALES = [1 / 16, 1 / 8, 1 / 4, 1 / 2, 1, 2, 4, 8, 16, 32, 64];

/** Nearest round scale value (compared in log space). */
function snapScale(v) {
	let best = NICE_SCALES[0], bestErr = Infinity;
	for (const c of NICE_SCALES) {
		const err = Math.abs(Math.log(v / c));
		if (err < bestErr) { bestErr = err; best = c; }
	}
	return best;
}

/**
 * Coordinate scale from texel density.
 *
 * In Minecraft models one texture texel matches one model pixel, so the scale
 * follows from the ratio of areas: geometric versus UV.
 * We divide by 2 because textures are conventionally twice as detailed as the
 * geometry — on both verified models the ratio was exactly 2.
 *
 * @param objects objects with positions in glTF units and NORMALISED UV
 * @param sizeOf  texture size of an object: (image index) -> {width, height}
 *
 * The size comes from the object's OWN texture, not the project: after atlas
 * packing the project size became the atlas size, and a shared scale
 * overestimated density almost threefold.
 */
function texelScale(objects, sizeOf) {
	const ratios = [];
	for (const o of objects) {
	const tex = sizeOf ? sizeOf(o.image) : null;
	const k = tex ? Math.sqrt(tex.width * tex.height) : 1;
	for (const f of o.faces) {
		if (f.positions.length < 3 || !f.uvs[0] || !f.uvs[1] || !f.uvs[2]) continue;
		const [a, b, c] = f.positions, [ua, ub, uc] = f.uvs;
		const e1 = [b[0] - a[0], b[1] - a[1], b[2] - a[2]];
		const e2 = [c[0] - a[0], c[1] - a[1], c[2] - a[2]];
		const cr = cross(e1, e2);
		const geom = len(cr) / 2;
		const uv = Math.abs((ub[0] - ua[0]) * (uc[1] - ua[1]) - (uc[0] - ua[0]) * (ub[1] - ua[1])) / 2;
		if (geom < 1e-12 || uv < 1e-12) continue;
		ratios.push(Math.sqrt(uv / geom) * k);
	}
	}
	if (!ratios.length) return 0;
	ratios.sort((x, y) => x - y);
	return ratios[ratios.length >> 1] / 2;   // the median resists outliers
}

/**
 * Picks the coordinate scale.
 *
 * A glTF unit means different things per exporter: for Blockbench it is a block
 * (16 px), for Sketchfab exports a pixel. Texel density is the main signal;
 * the bounding size is a sanity check and a fallback.
 */
function pickScale(sizeInUnits, texelHint) {
	const MIN = 4, MAX = 256;
	if (texelHint > 0) {
		const snapped = snapScale(texelHint);
		const px = sizeInUnits * snapped;
		if (px >= MIN && px <= MAX) return snapped;
	}
	for (const c of [16, 1, 1 / 16]) {
		const px = sizeInUnits * c;
		if (px >= MIN && px <= MAX) return c;
	}
	return snapScale(32 / (sizeInUnits || 1));
}


// glTF sampler wrap modes. If a sampler omits wrapS/wrapT the glTF default is
// REPEAT. GeckoLib/Blockbench UVs do not preserve that behaviour reliably,
// especially once several textures are packed into one atlas, so repeated UVs
// are baked into the atlas later and remapped into positive pixel coordinates.
const GLTF_WRAP_CLAMP = 33071;
const GLTF_WRAP_REPEAT = 10497;
const GLTF_WRAP_MIRROR = 33648;

function gltfWrapMode(gltf, texture, axis) {
	if (!texture || texture.sampler === undefined) return GLTF_WRAP_REPEAT;
	const sampler = (gltf.samplers || [])[texture.sampler] || {};
	const value = axis === 0 ? sampler.wrapS : sampler.wrapT;
	return value === undefined ? GLTF_WRAP_REPEAT : value;
}

function mapAtlasUV(value, rect, axis, wrapMode) {
	if (!rect) return value;
	const start = axis === 0 ? rect.x : rect.y;
	const source = axis === 0
		? (rect.sourceW || rect.w)
		: (rect.sourceH || rect.h);
	const tileMin = axis === 0
		? (rect.tileMinU || 0)
		: (rect.tileMinV || 0);

	// CLAMP_TO_EDGE is the only mode that must not walk into the baked tiles.
	if (wrapMode === GLTF_WRAP_CLAMP) {
		const v = Math.max(0, Math.min(1, value));
		return start + v * source;
	}

	// REPEAT and MIRRORED_REPEAT are represented by actual repeated/mirrored
	// copies in the atlas. Keeping the original continuous coordinate here means
	// triangles that cross a tile boundary still interpolate correctly.
	return start + (value - tileMin) * source;
}

/**
 * Keep a single PolyMesh texture as one image. glTF repeat is represented by
 * continuous UV coordinates, while Blockbench clamps preview textures by
 * default. Set THREE wrapping directly so the preview still looks like glTF
 * without creating a physically duplicated 2x/3x atlas texture.
 */
function applyPreviewTextureWrap(texture, modeS, modeT) {
	if (!texture || typeof THREE === 'undefined') return;
	const toThreeWrap = mode => mode === GLTF_WRAP_CLAMP
		? THREE.ClampToEdgeWrapping
		: mode === GLTF_WRAP_MIRROR
			? THREE.MirroredRepeatWrapping
			: THREE.RepeatWrapping;

	const applyToMap = map => {
		if (!map) return false;
		map.wrapS = toThreeWrap(modeS);
		map.wrapT = toThreeWrap(modeT);
		map.needsUpdate = true;
		return true;
	};

	const apply = () => {
		try {
			let ok = false;
			if (texture.material && texture.material.map) ok = applyToMap(texture.material.map) || ok;
			if (texture.img && texture.img.tex) ok = applyToMap(texture.img.tex) || ok;
			return ok;
		} catch (e) {
			return false;
		}
	};

	// Blockbench may recreate a texture material during Canvas.updateAll(), which
	// silently puts wrapS/wrapT back to ClampToEdgeWrapping.  Patch THIS texture
	// instance's material getter so every newly-created material immediately gets
	// the original glTF sampler mode again.  This avoids requiring the separate
	// Repeating Textures plugin and, unlike a one-shot assignment, survives redraws.
	try {
		if (typeof texture.getMaterial === 'function' && !texture.__gltfRepeatWrappedGetMaterial) {
			const originalGetMaterial = texture.getMaterial;
			texture.getMaterial = function (...args) {
				const result = originalGetMaterial.apply(this, args);
				try {
					if (result && result.map) applyToMap(result.map);
					if (this.material && this.material.map) applyToMap(this.material.map);
					if (this.img && this.img.tex) applyToMap(this.img.tex);
				} catch (e) { /* preview-only best effort */ }
				return result;
			};
			texture.__gltfRepeatWrappedGetMaterial = true;
		}
	} catch (e) { /* older Blockbench build */ }

	// Apply now, then again after redraws/asynchronous texture decoding.
	apply();
	let attempts = 0;
	const retry = () => {
		apply();
		if (++attempts < 16) setTimeout(retry, 50);
	};
	setTimeout(retry, 0);
}

/**
 * Parses glTF from a set of files (as they sit inside a ZIP) into objects
 * suitable for solveBox.
 *
 * All three forms are supported: .gltf with an external .bin, .gltf with inline
 * base64, and binary .glb.
 *
 * @param files {name: Uint8Array}
 * @param opts.scale     coordinate scale (default 16: one glTF unit = one block)
 * @param opts.uvWidth   texture width in pixels; UV are scaled to it
 * @param opts.uvHeight  texture height
 * @returns { objects: [{name, faces}], images: [{name, mime, bytes}], warnings: [] }
 */
function parseGLTFFiles(files, opts) {
	const o = opts || {};
	const scale = o.scale === undefined ? 16 : o.scale;
	const uvW = o.uvWidth || 1, uvH = o.uvHeight || 1;
	const offset = o.offset || [0, 0, 0];
	// The outer scene node of a Sketchfab export carries the showcase placement
	// of the model: an arbitrary rotation and offset. That must be dropped, while
	// the axis conversion one level below (Z-up -> Y-up) must be kept.
	//
	// But only a REAL wrapper is dropped: the single scene root that has children
	// and no mesh of its own. With several roots, or a root carrying geometry,
	// its transform is meaningful — a broader rule broke the test fixtures where
	// all 108 objects are roots.
	const wantIgnoreRoot = o.ignoreRootTransform !== false;
	const warnings = [];

	const names = Object.keys(files);
	const lower = n => n.toLowerCase();
	const glbName = names.find(n => lower(n).endsWith('.glb'));
	const gltfName = names.find(n => lower(n).endsWith('.gltf'));
	if (!glbName && !gltfName) {
		// Sketchfab offers two kinds of archive: the autoconversion (glTF) and the
		// author's source. The latter holds .blend or .fbx, which nothing here can
		// open — and this used to be reported as a missing texture, misleading.
		const src = names.filter(n => /\.(blend1?|fbx|max|ma|mb|c4d|3ds|dae|obj)$/i.test(n))
			.map(n => n.replace(/^.*[/\\]/, ''));
		throw new Error(src.length
			? `This archive has no glTF model, only the author's source files: ${src.slice(0, 3).join(', ')}.\n`
				+ 'That is the “Original” download. You need the “glTF” (autoconverted) one: '
				+ 'the plugin requests it automatically, but when downloading by hand you must pick it from the format list.'
			: 'the archive contains neither .gltf nor .glb');
	}

	let gltf, glbBin = null;
	if (glbName) {
		const parsed = parseGLB(files[glbName]);
		gltf = parsed.json;
		glbBin = parsed.bin;
	} else {
		gltf = JSON.parse(new TextDecoder().decode(files[gltfName]));
	}

	// buffers: inline base64, a .glb chunk, or a neighbouring file in the archive
	const baseDir = (glbName || gltfName).replace(/[^/\\]*$/, '');
	const buffers = (gltf.buffers || []).map((b, i) => {
		if (!b.uri) {
			if (glbBin) return glbBin;
			throw new Error(`buffer ${i} has no uri and there is no binary chunk`);
		}
		if (b.uri.startsWith('data:')) return base64ToBytes(b.uri.slice(b.uri.indexOf(',') + 1));
		const want = decodeURIComponent(b.uri);
		const key = names.find(n => n === baseDir + want || n === want || lower(n).endsWith('/' + lower(want)));
		if (!key) throw new Error(`buffer file “${want}” is missing from the archive`);
		return files[key];
	});

	// Images. Blockbench embeds the texture into glTF as a data URI, but it can
	// equally be a separate file in the archive or a buffer chunk in a .glb —
	// all three cases are supported and raw bytes are returned.
	//
	// The order strictly follows glTF: objects reference an image by its index,
	// and simply skipping an unreadable one would shift every later index, so an
	// object would silently get someone else's texture. A placeholder without
	// bytes therefore stays in place of an unreadable image.
	const images = (gltf.images || []).map((img, i) => {
		try {
			if (img.uri && img.uri.startsWith('data:')) {
				const mime = (img.uri.slice(5, img.uri.indexOf(';')) || 'image/png');
				return {
					name: img.name || `texture_${i}.${mime.split('/')[1] || 'png'}`,
					mime,
					bytes: base64ToBytes(img.uri.slice(img.uri.indexOf(',') + 1)),
				};
			}
			if (img.uri) {
				const want = decodeURIComponent(img.uri);
				const key = names.find(n => n === baseDir + want || n === want
					|| lower(n).endsWith('/' + lower(want)) || lower(n).endsWith(lower(want)));
				if (key) return { name: want.replace(/^.*[/\\]/, ''), mime: sniffMime(files[key]), bytes: files[key] };
				warnings.push(`image “${want}” not found in the archive`);
				return { name: want.replace(/^.*[/\\]/, ''), missing: true };
			}
			if (img.bufferView !== undefined) {
				const view = gltf.bufferViews[img.bufferView];
				const buf = buffers[view.buffer];
				return {
					name: img.name || `texture_${i}.png`,
					mime: img.mimeType || 'image/png',
					bytes: buf.subarray(view.byteOffset || 0, (view.byteOffset || 0) + view.byteLength),
				};
			}
		} catch (e) {
			warnings.push(`image ${i} could not be extracted: ${(e && e.message) || e}`);
		}
		return { name: img.name || `texture_${i}`, missing: true };
	});

	// The archive may hold an image glTF does not reference — for instance when
	// the exporter lost the texture paths. We take anything suitable by content:
	// the extension is sometimes wrong, sometimes foreign entirely.
	if (!images.some(img => img.bytes)) {
		for (const n of names) {
			if (/\.(png|jpe?g|gif|webp|tga|bmp)$/i.test(n) && imageSize(files[n])) {
				images.push({ name: n.replace(/^.*[/\\]/, ''), mime: sniffMime(files[n]), bytes: files[n], role: 'color' });
				break;
			}
		}
	}

	// The role of each image. Next to colour, glTF carries normal, roughness and
	// emissive maps — meaningless in Minecraft, yet they used to enter the atlas
	// alongside colour: inflating it, throwing off texel density (hence the
	// giant size complaints) and glowing as a lilac patch on the model.
	const imageRole = new Map();
	const setRole = (texIdx, role) => {
		const t = (gltf.textures || [])[texIdx];
		if (!t || t.source === undefined) return;
		// colour wins: if an image is used as colour anywhere, it is a colour image
		if (role === 'color' || !imageRole.has(t.source)) imageRole.set(t.source, role);
	};
	for (const m of gltf.materials || []) {
		const pbr = m.pbrMetallicRoughness || {};
		if (pbr.baseColorTexture) setRole(pbr.baseColorTexture.index, 'color');
		if (pbr.metallicRoughnessTexture) setRole(pbr.metallicRoughnessTexture.index, 'aux');
		if (m.normalTexture) setRole(m.normalTexture.index, 'aux');
		if (m.emissiveTexture) setRole(m.emissiveTexture.index, 'aux');
		if (m.occlusionTexture) setRole(m.occlusionTexture.index, 'aux');
	}
	// With no colour usage at all nothing is treated as auxiliary: some exports
	// have no materials, and the single texture just sits in the archive.
	const anyColor = [...imageRole.values()].includes('color');
	images.forEach((img, i) => {
		if (img.role) return;                       // one picked from the archive is already tagged
		img.role = anyColor ? (imageRole.get(i) || 'aux') : 'color';
	});

	const objects = [];
	// Bind-pose pivots recovered from skin.inverseBindMatrices.  For skinned
	// assets this is more reliable than assuming the joint node's scene-world
	// origin is the pivot: Source 2 exporters commonly keep a mesh transform and
	// skeleton transform in different branches, while the inverse-bind matrix is
	// precisely the relation the renderer uses to make them coincide at rest.
	const skinBindCandidates = new Map();
	let skinBindMatricesRead = 0;
	let skinBindMatricesInvalid = 0;
	// The node hierarchy is needed twice: as GeckoLib bones and as animation
	// targets, which reference nodes by index.
	const hierarchy = [];
	const scene = gltf.scenes && gltf.scenes[gltf.scene || 0];
	const roots = scene ? scene.nodes : (gltf.nodes || []).map((_, i) => i);
	// The export wrapper: Sketchfab_model -> root -> GLTF_SceneRootNode.
	// The first node carries showcase placement (an arbitrary rotation and
	// offset), which we drop. An axis-aligned rotation in the chain is the
	// Z-up -> Y-up conversion, part of the model data, and it is kept.
	const WRAPPER_NAMES = ['sketchfab_model', 'root', 'gltf_scenerootnode',
		'rootnode (gltf orientation matrix)', 'rootnode (model correction matrix)'];
	// What to do with a wrapper node transform: 'drop' discards it entirely,
	// 'axis' keeps the rotation only, when it is axis-aligned.
	const skipSet = new Map();
	if (wantIgnoreRoot && roots.length === 1) {
		let idx = roots[0];
		while (idx !== undefined) {
			const n = gltf.nodes[idx];
			// a wrapper node: a known name, no geometry of its own
			if (!n || n.mesh !== undefined) break;
			if (!WRAPPER_NAMES.includes(String(n.name || '').toLowerCase())) break;
			// Two meanings live mixed together inside the wrapper.
			// A proper axis-aligned rotation is the coordinate-system conversion
			// (Z-up -> Y-up); without it the model lies on its side. A reflected
			// signed basis (negative scale / determinant -1) is NOT a rotation and
			// must be discarded here, otherwise the complete GeckoLib model is
			// mirrored. Arbitrary showcase placement is discarded as before.
			const axis = axisRotationOf(n);
			skipSet.set(idx, axis ? 'axis' : (hasAxisReflection(n) ? 'reflection' : 'drop'));
			// descend only along a single chain: the last wrapper node is exactly
			// the one that branches into the model contents
			const kids = n.children || [];
			idx = kids.length === 1 ? kids[0] : undefined;
		}
		for (const [i, mode] of skipSet) {
			const name = gltf.nodes[i].name;
			warnings.push(mode === 'axis'
				? `wrapper “${name}”: proper axis rotation kept, offset/scale discarded`
				: mode === 'reflection'
					? `wrapper “${name}”: reflected/negative-scale wrapper discarded (prevents mirrored GeckoLib model)`
					: `wrapper “${name}”: showcase placement discarded`);
		}
	}

	const visit = (nodeIndex, parent, parentIndex, parentQuat) => {
		const node = gltf.nodes[nodeIndex];
		if (!node) return;
		const wrap = skipSet.get(nodeIndex);
		const axisRot = wrap === 'axis' ? axisRotationOf(node) : null;
		const local = (wrap === 'drop' || wrap === 'reflection') ? matIdentity()
			: axisRot ? axisRot.matrix
			: node.matrix ? node.matrix
			: matFromTRS(node.translation || [0, 0, 0], node.rotation || [0, 0, 0, 1], node.scale || [1, 1, 1]);
		const world = matMul(parent, local);
		if (node.matrix && !wrap) warnings.push(`node “${node.name || nodeIndex}” uses a matrix — rest rotation for animations was not extracted`);
		const worldQuat = (wrap === 'drop' || wrap === 'reflection') ? parentQuat.slice()
			: qMul(parentQuat, (axisRot ? axisRot.quat : node.rotation) || [0, 0, 0, 1]);

		const parentBasis = signedBasisFromMat(parent);
		const parentLinear = linearPartFromMat(parent);
		hierarchy.push({
			index: nodeIndex,
			name: node.name || `node_${nodeIndex}`,
			parent: parentIndex,
			// the bone pivot is the node origin in world space
			pivot: matApply(world, [0, 0, 0]).map((v, i) => v * scale + offset[i]),
			// A wrapper has no rest pose: animations never target it, and its
			// axis-aligned rotation is already in the children's world matrix.
			rest: wrap
				? { translation: [0, 0, 0], rotation: axisRot ? axisRot.quat : [0, 0, 0, 1], scale: [1, 1, 1] }
				: {
					translation: node.translation || [0, 0, 0],
					rotation: node.rotation || [0, 0, 0, 1],
					scale: node.scale || [1, 1, 1],
				},
			// The PARENT's rest rotation in world space. A Blockbench bone sits with
			// zero rotation, so its frame is the model frame, while the glTF offset
			// is expressed locally. Conjugating by this quaternion removes the
			// difference; without it the rotation axis comes out rotated.
			parentQuat: parentQuat.slice(),
			// Signed parent frame used by animation conversion. This preserves
			// negative-scale/reflection axes that a quaternion cannot represent.
			parentBasis,
			// Exact parent linear transform for translations. Unlike parentBasis,
			// this intentionally keeps signed/non-uniform scale so a 0.1-unit
			// glTF translation becomes the same displacement as the baked geometry.
			parentLinear,
			parentMirrored: basisDeterminant(parentBasis) < 0,
			hasMesh: node.mesh !== undefined,
			objectIndex: node.mesh !== undefined ? objects.length : -1,
		});

		if (node.mesh !== undefined) {
			const mesh = gltf.meshes[node.mesh];
			const faces = [];
			// which image this object uses: material -> texture -> image
			let imageIndex = -1;

			// A glTF skin stores geometry in one mesh and assigns vertices to joints
			// through JOINTS_0 / WEIGHTS_0. GeckoLib has no vertex skinning: geometry
			// must instead live below the corresponding bone. We therefore remember
			// the dominant joint of every triangle and split by it before cubes are
			// built. Rigidly skinned game assets (weight 1.0 on one joint) map
			// perfectly; blended triangles use the strongest accumulated influence.
			const skin = node.skin !== undefined ? (gltf.skins || [])[node.skin] : null;

			// IMPORTANT: derive animated joint pivots from the skin bind pose.
			//
			// glTF skinning uses (in mesh-local space):
			//   inverse(meshWorld) * jointWorld * inverseBindMatrix
			// which is identity in the bind pose. Therefore:
			//   bindJointWorld = meshWorld * inverse(inverseBindMatrix)
			//
			// This gives the pivot in EXACTLY the same corrected world/reference
			// space as the baked Poly Mesh vertices below.  Using only the joint
			// node world origin works for simple files, but is wrong for Source 2
			// exports where the skinned mesh and skeleton live under different
			// transforms.  The symptom is exactly a strip/lid that is correct at rest
			// then swings around a point several pixels away during animation.
			if (skin && skin.inverseBindMatrices !== undefined && skin.joints && skin.joints.length) {
				try {
					const ibm = readAccessor(gltf, buffers, skin.inverseBindMatrices);
					for (let ji = 0; ji < skin.joints.length && ji < ibm.length; ji++) {
						const jointNode = skin.joints[ji];
						const invBind = ibm[ji];
						if (!invBind || invBind.length !== 16) { skinBindMatricesInvalid++; continue; }
						const bindLocal = matInverse(invBind);
						if (!bindLocal) { skinBindMatricesInvalid++; continue; }
						const bindWorld = matMul(world, bindLocal);
						const p = matApply(bindWorld, [0, 0, 0]).map((v, i) => v * scale + offset[i]);
						if (!p.every(Number.isFinite)) { skinBindMatricesInvalid++; continue; }
						if (!skinBindCandidates.has(jointNode)) skinBindCandidates.set(jointNode, []);
						skinBindCandidates.get(jointNode).push({ pivot: p, meshNode: nodeIndex, skin: node.skin });
						skinBindMatricesRead++;
					}
				} catch (e) {
					warnings.push(`skin on “${node.name || nodeIndex}”: inverse bind matrices could not be read (${(e && e.message) || e})`);
				}
			}

			for (const prim of mesh.primitives || []) {
				if (prim.mode !== undefined && !TRIANGULATE[prim.mode]) {
					warnings.push(`${node.name || mesh.name}: primitive mode ${prim.mode} skipped (points and lines are not geometry)`);
					continue;
				}
				const posIdx = prim.attributes && prim.attributes.POSITION;
				if (posIdx === undefined) continue;

				let primImageIndex = -1;
				let primTexture = null;
				if (prim.material !== undefined) {
					const mat = (gltf.materials || [])[prim.material];
					const texRef = mat && mat.pbrMetallicRoughness && mat.pbrMetallicRoughness.baseColorTexture;
					primTexture = texRef && (gltf.textures || [])[texRef.index];
					if (primTexture && primTexture.source !== undefined) {
						primImageIndex = primTexture.source;
						if (imageIndex < 0) imageIndex = primImageIndex;
					}
				}
				const wrapS = gltfWrapMode(gltf, primTexture, 0);
				const wrapT = gltfWrapMode(gltf, primTexture, 1);

				const pos = readAccessor(gltf, buffers, posIdx).map(p => {
					const w = matApply(world, p);
					return [w[0] * scale + offset[0], w[1] * scale + offset[1], w[2] * scale + offset[2]];
				});
				const uvIdx = prim.attributes.TEXCOORD_0;
				// With an atlas layout given, UV are mapped into its coordinates.
				// Repeated/mirrored UV are baked into extra atlas tiles, so unlike
				// the old t*rect.w formula negative UV remain on the right texture.
				const rect = o.uvRects && primImageIndex >= 0 ? o.uvRects[primImageIndex] : null;
				const uv = uvIdx === undefined ? null
					: readAccessor(gltf, buffers, uvIdx).map(t => rect
						? [mapAtlasUV(t[0], rect, 0, wrapS), mapAtlasUV(t[1], rect, 1, wrapT)]
						: [t[0] * uvW, t[1] * uvH]);

				const idx = prim.indices === undefined
					? pos.map((_, i) => i)
					: readAccessor(gltf, buffers, prim.indices).map(a => a[0]);

				const jointsIdx = prim.attributes && prim.attributes.JOINTS_0;
				const weightsIdx = prim.attributes && prim.attributes.WEIGHTS_0;
				const joints = skin && jointsIdx !== undefined ? readAccessor(gltf, buffers, jointsIdx) : null;
				const weights = skin && weightsIdx !== undefined ? readAccessor(gltf, buffers, weightsIdx) : null;

				// Preserve the REAL glTF skinning data per vertex.  GeckoMesh's normal
				// bone.poly_mesh path is rigid, but CS2 Lootbox now has a GeckoLib-driven
				// weighted renderer.  Keeping JOINTS_0 + WEIGHTS_0 here lets the export
				// embed exact weights instead of destructively assigning each triangle to
				// one dominant bone.  The dominant metadata is still computed so the old
				// approximation modes remain available for non-CS2 projects.
				const vertexSkin = pos.map((_, vertex) => {
					if (!skin || !joints || !skin.joints || !skin.joints.length) return [];
					const js = joints[vertex] || [];
					const ws = weights ? (weights[vertex] || []) : [];
					const influences = [];
					for (let j = 0; j < js.length; j++) {
						const jointSlot = Number(js[j]);
						const boneNode = skin.joints[jointSlot];
						if (boneNode === undefined) continue;
						const weight = weights ? Number(ws[j] || 0) : (j === 0 ? 1 : 0);
						if (!Number.isFinite(weight) || weight <= 1e-8) continue;
						influences.push({ node: boneNode, weight });
					}
					influences.sort((a, b) => b.weight - a.weight);
					const kept = influences.slice(0, 4);
					const sum = kept.reduce((v, x) => v + x.weight, 0);
					if (sum > 1e-8) for (const x of kept) x.weight /= sum;
					return kept;
				});

				const skinForTriangle = tri => {
					if (!skin || !joints || !skin.joints || !skin.joints.length) {
						return { boneNode: nodeIndex, skinNodes: [], blended: false };
					}

					const score = new Map();
					const skinNodes = new Set();
					const rigidVertexBones = [];
					let blended = false;
					for (const vertex of tri) {
						const inf = vertexSkin[vertex] || [];
						for (const x of inf) {
							skinNodes.add(x.node);
							score.set(x.node, (score.get(x.node) || 0) + x.weight);
						}
						const strongest = inf[0];
						if (inf.length > 1 || (strongest && strongest.weight < 0.999)) blended = true;
						rigidVertexBones.push(strongest && strongest.node);
					}
					if (new Set(rigidVertexBones.filter(v => v !== undefined)).size > 1) blended = true;

					let best = nodeIndex, bestWeight = -1;
					for (const [boneNode, weight] of score) {
						if (weight > bestWeight) { bestWeight = weight; best = boneNode; }
					}
					return { boneNode: best, skinNodes: [...skinNodes], blended };
				};

				for (const tri of TRIANGULATE[prim.mode === undefined ? 4 : prim.mode](idx)) {
					const triSkin = skinForTriangle(tri);
					faces.push({
						positions: tri.map(k => pos[k]),
						uvs: tri.map(k => uv ? uv[k] : null),
						// metadata used only by the importer/exporter; solveBox ignores it
						boneNode: triSkin.boneNode,
						skinNodes: triSkin.skinNodes,
						skinBlended: triSkin.blended,
						skinVertices: tri.map(k => (vertexSkin[k] || []).map(x => ({ node: x.node, weight: x.weight }))),
						image: primImageIndex,
						wrapS,
						wrapT,
					});
				}
			}
			if (faces.length) objects.push({ name: node.name || mesh.name || `object_${objects.length}`, faces, node: nodeIndex, image: imageIndex });
		}

		for (const child of node.children || []) visit(child, world, nodeIndex, worldQuat);
	};

	// The extra rotation is applied as the base coordinate system: it reaches
	// positions, bone pivots and accumulated rest rotations alike, so animations
	// stay consistent.
	const corr = correctionQuat(o.rotate);
	const base = matFromTRS([0, 0, 0], corr, [1, 1, 1]);
	for (const r of roots) visit(r, base, -1, corr.slice());

	// Replace pivots of skinned joints with the bind-pose pivots recovered above.
	// A joint can appear in more than one skin/mesh. Valid glTF files produce the
	// same world bind point in every occurrence; use their average to remove tiny
	// floating-point differences and report any real disagreement for debugging.
	let bindPivotOverrides = 0;
	let bindPivotMaxCorrection = 0;
	let bindPivotMaxSpread = 0;
	let bindPivotWorst = '';
	for (const h of hierarchy) {
		const candidates = skinBindCandidates.get(h.index);
		if (!candidates || !candidates.length) continue;
		const pivot = [0, 0, 0];
		for (const c of candidates) for (let k = 0; k < 3; k++) pivot[k] += c.pivot[k];
		for (let k = 0; k < 3; k++) pivot[k] /= candidates.length;

		let spread = 0;
		for (const c of candidates) spread = Math.max(spread, Math.hypot(
			c.pivot[0] - pivot[0], c.pivot[1] - pivot[1], c.pivot[2] - pivot[2]));
		bindPivotMaxSpread = Math.max(bindPivotMaxSpread, spread);

		const correction = Math.hypot(
			h.pivot[0] - pivot[0], h.pivot[1] - pivot[1], h.pivot[2] - pivot[2]);
		if (correction > bindPivotMaxCorrection) {
			bindPivotMaxCorrection = correction;
			bindPivotWorst = h.name;
		}
		h.nodePivot = h.pivot.slice();
		h.pivot = pivot;
		h.pivotSource = 'inverseBindMatrices';
		h.bindPivotCorrection = correction;
		bindPivotOverrides++;
	}

	const bindPivotStats = {
		matricesRead: skinBindMatricesRead,
		invalid: skinBindMatricesInvalid,
		overrides: bindPivotOverrides,
		maxCorrection: bindPivotMaxCorrection,
		maxSpread: bindPivotMaxSpread,
		worstBone: bindPivotWorst,
	};

	return { objects, images, warnings, hierarchy, animations: parseAnimations(gltf, buffers, warnings), unitScale: scale, bindPivotStats };
}

/**
 * Grid snapping. Numbers like -4.3979 or 0.0005 are technically correct but
 * impossible to work with in the editor, and a 0.25 px step is native to
 * Minecraft: that is how cubes are placed by hand.
 *
 * Angles are NOT snapped: a rotated cube legitimately has any angle, and
 * rounding to a quarter degree would break the joins. Clearing the
 * floating-point noise is enough there.
 */
/**
 * The six faces of a cube in WORLD coordinates.
 *
 * A cube's from/to are local: Blockbench rotates them about origin. So the
 * bounding box from center ± size/2 matches the real placement only for
 * unrotated cubes, and lies for the rest — including axis-aligned ones whose
 * basis is a permutation of axes (a 90° rotation).
 *
 * Coordinates are taken already snapped: separation must be computed on the
 * geometry that actually lands in the project.
 */
function cubeFaces(sol) {
	const place = placeCoords(sol);
	const half = sol.size.map(v => Math.abs(v) / 2);
	const from = place(sol.center.map((c, i) => c - half[i]));
	const to = place(sol.center.map((c, i) => c + half[i]));
	const origin = place(sol.center);
	const basis = [sol.vx, sol.vy, sol.vz];

	const lc = [0, 1, 2].map(i => (from[i] + to[i]) / 2);
	const lh = [0, 1, 2].map(i => (to[i] - from[i]) / 2);
	const toWorld = q => {
		const d = [q[0] - origin[0], q[1] - origin[1], q[2] - origin[2]];
		return [0, 1, 2].map(k => origin[k] + basis[0][k] * d[0] + basis[1][k] * d[1] + basis[2][k] * d[2]);
	};

	const faces = [];
	for (let ax = 0; ax < 3; ax++) {
		const [b1, b2] = [0, 1, 2].filter(x => x !== ax);
		for (const s of [-1, 1]) {
			const q = lc.slice();
			q[ax] += s * lh[ax];
			const c = toWorld(q);
			const n = basis[ax].map(v => v * s);
			faces.push({
				n, c,
				d: n[0] * c[0] + n[1] * c[1] + n[2] * c[2],
				u: basis[b1], v: basis[b2],
				hu: lh[b1], hv: lh[b2],
			});
		}
	}
	return faces;
}

/** Whether two rectangles lying in the same plane overlap. */
function faceRectsOverlap(f1, f2, eps) {
	const dot = (x, y) => x[0] * y[0] + x[1] * y[1] + x[2] * y[2];
	const D = [f2.c[0] - f1.c[0], f2.c[1] - f1.c[1], f2.c[2] - f1.c[2]];
	// Separating axis: if the projections fail to meet along any of the four
	// sides, the rectangles do not overlap. For rotated faces this is the only
	// way — their sides are not parallel to each other.
	const reach = (f, ax) => f.hu * Math.abs(dot(f.u, ax)) + f.hv * Math.abs(dot(f.v, ax));
	for (const ax of [f1.u, f1.v, f2.u, f2.v]) {
		if (Math.abs(dot(D, ax)) >= reach(f1, ax) + reach(f2, ax) - eps) return false;
	}
	return true;
}

/**
 * Separates cubes whose faces lie in the same plane.
 *
 * The GPU cannot decide which of two coincident faces is nearer, and the model
 * flickers (z-fighting). A hair-thin shift cures it, but coordinates must not
 * move: a clean 5 in the panel would become 4.99432, and editing the model by
 * hand would become impossible. So the inflate field is used instead: it grows
 * the cube evenly and lives apart from position and size.
 *
 * Hiding the redundant face instead is not an option: among coplanar faces
 * neither covers the other, they share a depth. Hiding the wrong one loses a
 * detail — the face overlay fitted flush into a head, for example.
 *
 * The SMALLER cube of a pair is always inflated: usually it is an overlay on
 * top of a base, and protruding outwards is natural for it. The amount
 * accumulates per layer so that three nested cubes land at three depths.
 *
 * Back-to-back joins (the bottom of one cube on the top of another) do not
 * flicker: those faces point opposite ways and are covered by the neighbour's
 * volume. They drop out on their own — the normal sign is part of the plane key.
 *
 * @param sols  solveBox results: { center, size, vx, vy, vz }
 * @returns { inflate, pairs, skipped }
 */
function resolveCoplanar(sols, step, limit) {
	const EPS = 1e-4;
	const INFLATE = step || 0.01;
	const MAX = limit || 20000;
	// How close two planes must be to count as coincident.
	// Snapping moves a rotated cube's face by hundredths of a pixel, and an exact
	// comparison would separate planes that still flicker on screen.
	const PLANE_TOL = 0.02;
	// The inflate ceiling. Kept small: a noticeable share of cubes gets inflated,
	// and on tightly packed details a large value would creep onto neighbours.
	const CAP = 0.05;
	const inflate = sols.map(() => 0);
	if (sols.length > MAX) return { inflate, pairs: 0, skipped: sols.length };

	const volume = sols.map(s => Math.abs(s.size[0] * s.size[1] * s.size[2]));
	const faces = sols.map(cubeFaces);

	// There can be thousands of cubes, and pairwise comparison is quadratic. Faces
	// go into buckets keyed by normal: only those actually sharing a plane and
	// facing the same way need comparing.
	const buckets = new Map();
	faces.forEach((list, i) => {
		for (const f of list) {
			const key = f.n.map(v => (Math.abs(v) < 1e-4 ? 0 : v).toFixed(3)).join(',');
			let bucket = buckets.get(key);
			if (!bucket) buckets.set(key, bucket = []);
			bucket.push({ i, f });
		}
	});

	// Planes are compared with a tolerance rather than for exact equality.
	// Snapping moves a rotated cube's face by hundredths of a pixel, and exact
	// comparison would separate planes that flicker on screen regardless.
	const conflicts = [];
	for (const bucket of buckets.values()) {
		if (bucket.length < 2) continue;
		bucket.sort((x, y) => x.f.d - y.f.d);
		for (let x = 0; x < bucket.length; x++) {
			for (let y = x + 1; y < bucket.length && bucket[y].f.d - bucket[x].f.d <= PLANE_TOL; y++) {
				const A = bucket[x], B = bucket[y];
				if (A.i === B.i) continue;
				if (!faceRectsOverlap(A.f, B.f, EPS)) continue;
				conflicts.push([A.i, B.i]);
			}
		}
	}

	// Largest first: otherwise layers scatter and nested cubes receive a smaller
	// offset than the ones covering them.
	conflicts.sort((p, q) => Math.max(volume[q[0]], volume[q[1]]) - Math.max(volume[p[0]], volume[p[1]]));

	let pairs = 0, capped = 0;
	const seen = new Set();
	for (const [i, j] of conflicts) {
		const tag = Math.min(i, j) + '_' + Math.max(i, j);
		if (seen.has(tag)) continue;
		seen.add(tag);
		pairs++;
		const big = volume[i] >= volume[j] ? i : j;
		const small = big === i ? j : i;
		const want = inflate[big] + INFLATE;
		if (want > inflate[small]) {
			// Ceiling: inflation must stay below half the grid step, or the cube
			// grows visibly. Deep layers hit it and stop separating — better than
			// a visible distortion of shape.
			inflate[small] = Math.min(want, CAP);
			if (want > CAP) capped++;
		}
	}

	return { inflate, pairs, capped, skipped: 0 };
}


const GRID = 0.25;

// The thickness below which a cube counts as flat. Such cubes have degenerate
// side faces: zero area, visible only once the cube has been inflated.
//
const FLAT_LIMIT = 0.01;

// How close to a grid node a coordinate must already sit for pulling it in to
// make sense. This is noise cleanup, not reshaping.
const SNAP_TOLERANCE = 0.02;

/**
 * How a particular cube's coordinates are laid down.
 *
 * Straight cubes snap to the grid, skewed ones are merely rounded. The logic
 * must be THE SAME where a cube is created and where coplanar faces are looked
 * for: otherwise separation is computed on geometry the project never gets.
 */
function placeCoords(sol) {
	return snapSafely(sol) ? snapVec : tidyVec;
}

/** Rounding without snapping: clears noise, leaves the shape alone. */
function tidyVec(v) {
	return v.map(x => {
		const r = Math.round(x * 1000) / 1000;
		return Object.is(r, -0) ? 0 : r;
	});
}

/**
 * Whether this cube can be snapped to the grid without breaking anything.
 *
 * A 0.25 px grid is coarse for small details: a pupil of 0.6 × 0.7 × 0.001
 * became 0.75 × 0.75 × 0 after snapping — a quarter larger and with no
 * thickness left, so the overlay above the eye ended up exactly in the plane of
 * the head and vanished. Its mirror twin survived if it happened to be rotated,
 * and the two eyes came out different.
 *
 * So snapping happens only where it changes almost nothing: for cubes built on
 * the grid it is noise cleanup like 4.99998 -> 5, while an off-grid detail
 * keeps its exact numbers. Round figures are not worth a broken model.
 */
function snapSafely(sol) {
	// For a rotated cube origin takes part in vertex placement, and snapping it
	// apart from from/to drags the geometry — so it is forbidden there entirely.
	if (!isIdentityBasis(sol)) return false;

	// Snap only if the cube ALREADY sits on the grid: then it is noise cleanup
	// like 4.99998 -> 5. A model built off-grid cannot be pulled onto it —
	// 0.6 would become 0.75, a quarter of the detail's size.
	const half = sol.size.map(v => Math.abs(v) / 2);
	for (let i = 0; i < 3; i++) {
		const lo = sol.center[i] - half[i];
		const hi = sol.center[i] + half[i];
		if (Math.abs(lo - snapGrid(lo)) > SNAP_TOLERANCE) return false;
		if (Math.abs(hi - snapGrid(hi)) > SNAP_TOLERANCE) return false;
		// Both bounds may sit at ONE node, and then the detail collapses into a
		// plane. A thin overlay loses its protrusion this way, lands flush in the
		// neighbour's face and disappears: exactly what happened to the pupil.
		if (Math.abs(hi - lo) > 1e-9 && Math.abs(snapGrid(hi) - snapGrid(lo)) < 1e-9) return false;
	}
	return true;
}

/**
 * Whether the cube stands unrotated: its basis matches the world axes.
 *
 * Precisely this case, not axis-aligned in general. A 90° rotation is also
 * axis-aligned, but its matrix is no longer the identity, and origin starts
 * affecting vertex placement again.
 */
function isIdentityBasis(sol) {
	const want = [sol.vx, sol.vy, sol.vz];
	for (let i = 0; i < 3; i++) {
		for (let j = 0; j < 3; j++) {
			if (Math.abs(want[i][j] - (i === j ? 1 : 0)) > 1e-6) return false;
		}
	}
	return true;
}
function snapGrid(v, step) {
	const s = step || GRID;
	const r = Math.round(v / s) * s;
	// -0 prints as "-0" and looks like a bug
	return Object.is(r, -0) ? 0 : r;
}
function snapVec(v, step) { return v.map(x => snapGrid(x, step)); }

/**
 * Bone pivots must not be snapped to the modelling grid. Poly Mesh vertices are
 * preserved at their exact glTF coordinates, so snapping a joint from e.g.
 * 3.137 px to 3.25 px changes the centre of rotation and makes thin animated
 * parts (case lids, envelope strips, weapon pieces, etc.) detach while rotating.
 *
 * Keep the glTF pivot essentially exact and only remove floating-point noise.
 */
function preciseBonePivot(v) {
	return (v || [0, 0, 0]).map(value => {
		const n = Number(value);
		if (!Number.isFinite(n) || Math.abs(n) < 1e-9) return 0;
		const r = Math.round(n * 1e6) / 1e6;
		return Object.is(r, -0) ? 0 : r;
	});
}

/** Angles: strip floating-point noise but keep the value. */
function snapAngle(deg) {
	const r = Math.round(deg * 100) / 100;
	return Object.is(r, -0) ? 0 : r;
}


/**
 * Whether the model has a ready glTF download.
 *
 * Sketchfab offers several archives: the autoconversion (gltf/glb) and the
 * author's source (.blend, .fbx, .max). Nothing here can open the latter. Some
 * models have no autoconversion at all and the field arrives with zero size.
 *
 * If the response has no archives field at all (an older API), assume glTF
 * exists: better to show too much than to hide everything.
 */
function hasGltfArchive(m) {
	if (!m || !m.archives) return true;
	const ok = a => a && typeof a.size === 'number' && a.size > 0;
	return ok(m.archives.gltf) || ok(m.archives.glb);
}

// ------------------------------------------- CPM (.cpmproject) construction

/**
 * Customizable Player Models lives in the coordinate system of vanilla
 * Minecraft models, not of Blockbench: X points the other way, Y points down
 * and starts 24 px above the feet. Rotations follow the axes.
 *
 * Derived from the mod's own Blockbench exporter (BlockbenchExport.java:255-272
 * and its convert()), not guessed.
 */
function cpmPoint(p) { return [-p[0], 24 - p[1], p[2]]; }

/** The same for a difference of two points: the 24 px shift cancels out. */
function cpmDelta(p) { return [-p[0], -p[1], p[2]]; }

/**
 * Pivots of the vanilla player parts, already in CPM coordinates.
 * Straight out of PlayerPartValues.java (px, py, pz). Independent of skin type:
 * the slim arms differ in width, not in where they hinge.
 */
const CPM_PARTS = {
	head:      [0, 0, 0],
	body:      [0, 0, 0],
	left_arm:  [5, 2, 0],
	right_arm: [-5, 2, 0],
	left_leg:  [1.9, 12, 0],
	right_leg: [-1.9, 12, 0],
};
const CPM_PART_NAMES = Object.keys(CPM_PARTS);

/**
 * Blockbench face -> CPM face, with the UV rotation each one needs.
 *
 * East and west swap because X is flipped. Up and down keep their names — CPM's
 * "up" is the face with the SMALLEST y, since y grows downwards — but their UV
 * comes out rotated by 180°: BoxRender.createTextured lays u along +X and v
 * along -Z there, while Blockbench uses -X and +Z. The mod's own exporter adds
 * the same 180° in convertUV().
 */
const CPM_FACE = {
	north: { dir: 'north', rot: '0' },
	south: { dir: 'south', rot: '0' },
	east:  { dir: 'west',  rot: '0' },
	west:  { dir: 'east',  rot: '0' },
	up:    { dir: 'up',    rot: '180' },
	down:  { dir: 'down',  rot: '180' },
};

/**
 * Euler angles of a cube for CPM, in degrees, normalised to 0..360.
 *
 * The basis is carried over into CPM coordinates by conjugation with
 * S = diag(-1, -1, 1) rather than by flipping the angles that Blockbench
 * reports. Conjugation is exact and needs no case analysis: S is its own
 * inverse and its determinant is +1, so the result is still a rotation.
 *
 * The angles are then extracted in ZYX order, i.e. R = Rz·Ry·Rx. That is the
 * order an element is actually rotated in: Rotation.asQ() builds the quaternion
 * with RotationOrder.ZYX. Quaternion also has a plain three-float constructor
 * that composes XYZ, but nothing on the element path calls it.
 */
function cpmEuler(sol) {
	return cpmEulerFromMatrix([
		[sol.vx[0], sol.vy[0], sol.vz[0]],
		[sol.vx[1], sol.vy[1], sol.vz[1]],
		[sol.vx[2], sol.vy[2], sol.vz[2]],
	]);
}

/** The same for a rotation given as a quaternion in Blockbench axes. */
function cpmEulerFromQuat(q) {
	const [x, y, z, w] = q;
	return cpmEulerFromMatrix([
		[1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
		[2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
		[2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
	]);
}

/** @param R rotation matrix in Blockbench axes, R[row][col] */
function cpmEulerFromMatrix(R) {
	return cpmEulerZYX(cpmConjugate(R));
}

/** Carries a rotation from Blockbench axes into CPM ones: S·R·S, S = diag(-1,-1,1). */
function cpmConjugate(R) {
	const s = [-1, -1, 1];
	return [0, 1, 2].map(i => [0, 1, 2].map(j => s[i] * s[j] * R[i][j]));
}

/** Euler angles in ZYX order, degrees, 0..360. The matrix is already in CPM axes. */
function cpmEulerZYX(m) {
	const clamp = v => Math.min(1, Math.max(-1, v));
	const y = Math.asin(-clamp(m[2][0]));
	let x, z;
	if (Math.abs(m[2][0]) < 0.9999999) {
		x = Math.atan2(m[2][1], m[2][2]);
		z = Math.atan2(m[1][0], m[0][0]);
	} else {
		// Gimbal lock: y is ±90°, and only the sum of x and z is defined.
		x = 0;
		z = Math.atan2(-m[0][1], m[1][1]);
	}
	return [x, y, z].map(r => cpmAngle(r * 180 / Math.PI));
}

const mat3Mul = (a, b) => [0, 1, 2].map(i => [0, 1, 2].map(j =>
	a[i][0] * b[0][j] + a[i][1] * b[1][j] + a[i][2] * b[2][j]));
const mat3T = a => [0, 1, 2].map(i => [0, 1, 2].map(j => a[j][i]));
const mat3Apply = (a, v) => [0, 1, 2].map(i => a[i][0] * v[0] + a[i][1] * v[1] + a[i][2] * v[2]);
const MAT3_ID = [[1, 0, 0], [0, 1, 0], [0, 0, 1]];

/** The rotation of a column-major 4x4, with any scale divided out. */
function mat3FromMat4(m) {
	const col = c => {
		const v = [m[c * 4], m[c * 4 + 1], m[c * 4 + 2]];
		const l = Math.hypot(v[0], v[1], v[2]) || 1;
		return [v[0] / l, v[1] / l, v[2] / l];
	};
	const [a, b, c] = [col(0), col(1), col(2)];
	return [0, 1, 2].map(i => [a[i], b[i], c[i]]);
}

/**
 * CPM stores an angle as an unsigned 16-bit fraction of a full turn
 * (IOHelper.writeAngle), so a negative value would be clamped to zero rather
 * than wrapped. Everything is brought into 0..360 before it is written.
 */
function cpmAngle(deg) {
	let r = deg % 360;
	if (r < 0) r += 360;
	r = Math.round(r * 100) / 100;
	return r >= 360 ? 0 : r;
}

/**
 * How much finer the UV grid has to be for every UV to land on a whole number.
 *
 * CPM keeps face UV in integers, but they are integers of the UV GRID, whose
 * size is stored apart from the actual picture (config.json skinSize versus
 * skin.png — the mismatch is exactly what turns on customGridSize). So a
 * fractional UV costs nothing but a larger number: the image is never touched,
 * and the viewer-side limit on texture size is measured on the image.
 *
 * The mod's own exporter multiplies by 16 whenever a single UV is fractional.
 * We take the smallest multiplier that works, so the numbers stay readable.
 */
function cpmUVScale(cubes, limit, texSize) {
	// The grid is written as a signed short (IOHelper.write2s), so it has to stay
	// under 32767 — ×16 on a 2048 texture would land exactly on the edge.
	let max = limit || 16;
	while (texSize && texSize * max > 32767 && max > 1) max /= 2;
	const values = [];
	for (const c of cubes) {
		for (const name of FACE_NAMES) {
			const uv = c.sol.faceUV[name];
			if (uv) values.push(uv[0], uv[1], uv[2], uv[3]);
		}
	}
	const off = (v, mul) => Math.abs(v * mul - Math.round(v * mul));
	for (let mul = 1; mul <= max; mul *= 2) {
		if (values.every(v => off(v, mul) < 0.01)) return { mul, exact: true, worst: 0 };
	}
	// Nothing within the ceiling makes them whole: take the ceiling and report
	// the worst rounding, in picture pixels, so the cost is visible.
	let worst = 0;
	for (const v of values) worst = Math.max(worst, off(v, max) / max);
	return { mul: max, exact: false, worst };
}

/**
 * A first guess at which bone is which part of the player, by name.
 *
 * Only a guess — the last word belongs to the person at the dialog. Models off
 * Sketchfab name their bones anything at all, and a wrong guess made silently
 * is worse than no guess. What it does buy is that a model already rigged like
 * a player, which is most of them, needs no corrections at all.
 *
 * A bone with no verdict is deliberately left out: it inherits its parent's
 * part, so an item pivot inside an arm goes along with the arm on its own.
 */
function cpmAutoAssign(hierarchy) {
	const assign = {};
	for (const h of hierarchy) {
		const n = String(h.name || '').toLowerCase().replace(/[^a-z]/g, '');
		const side = n.indexOf('left') >= 0 ? 'left' : n.indexOf('right') >= 0 ? 'right' : null;
		const limb = /arm|hand|shoulder/.test(n) ? 'arm' : /leg|foot|thigh|knee/.test(n) ? 'leg' : null;
		if (side && limb) assign[h.index] = `${side}_${limb}`;
		else if (/head|skull/.test(n)) assign[h.index] = 'head';
		else if (/body|torso|chest|spine/.test(n)) assign[h.index] = 'body';
	}
	return assign;
}

/**
 * How far the model has to be moved for its skeleton to sit on the player's.
 *
 * Centring on the bounding box is not enough, and on some models it is actively
 * wrong: this one has a long tail, so centring the box put the character itself
 * 18 px in front of the player. At rest that is invisible — the model is
 * self-consistent — but every vanilla part turns about ITS OWN pivot, and a limb
 * hanging 18 px away from that pivot swings out of the body the moment the arm
 * moves. That is what tore the first version apart in game.
 *
 * So the offset is taken from the rig instead: the average gap between the bones
 * the person mapped and the vanilla pivots they were mapped to. A whole-model
 * translation cannot deform anything — the alternative, aligning each part
 * separately, would put every limb exactly on its pivot and pull the model
 * apart at rest.
 *
 * A residual of a few pixels stays and is unavoidable: an imported character has
 * its shoulders and hips where its author put them, not where Minecraft does.
 */
function cpmAlignOffset(hierarchy, assign, k) {
	const diffs = [];
	for (const h of hierarchy) {
		const part = assign && assign[h.index];
		if (!part || !CPM_PARTS[part]) continue;
		diffs.push(sub(CPM_PARTS[part], cpmPoint(mul(h.pivot, k || 1))));
	}
	if (!diffs.length) return [0, 0, 0];
	const mean = i => diffs.reduce((s, d) => s + d[i], 0) / diffs.length;
	// Height is left alone on purpose. The import already stands the model on the
	// ground, and that is a hard constraint — averaging the rig mismatch
	// vertically pulled this model a pixel INTO the floor, which showed up the
	// moment it crouched. Sideways and depthwise there is no such anchor, and
	// that is exactly where centring on the bounding box goes wrong.
	return [mean(0), 0, mean(2)];
}

/**
 * The model tree for config.json.
 *
 * Roots are not our bones but the fixed parts of the player: everything of ours
 * hangs off them as children. A bone becomes a CPM element with no geometry
 * (size 0), a cube becomes an element with a box.
 *
 * `assign` maps a glTF node index to a player part. It may be partial: a bone
 * without an entry of its own inherits the part of its parent.
 */
function buildCPMConfig(input) {
	const hierarchy = input.hierarchy;
	const cubes = input.cubes;
	const assign = input.assign || {};
	const fallback = input.fallback || 'body';
	const uvMul = input.uvMul || 1;
	// CPM measures in player pixels, and a Sketchfab model arrives in whatever
	// units its author used, so the size here is its own setting rather than the
	// one the GeckoLib branch was imported at. Geometry scales uniformly —
	// positions, sizes and inflation — while angles and UV do not.
	const k = input.scale || 1;
	// A whole-model shift onto the player's skeleton. Only bones attached
	// straight to a player part need it: everything below them is measured
	// against its parent and comes along by itself.
	const align = input.align || [0, 0, 0];
	const warnings = [];

	// Step 1. Which player part each bone belongs to. The hierarchy is ordered
	// parent-before-child, so one pass is enough.
	const partOf = {};
	const indexOf = {};
	hierarchy.forEach((h, i) => { indexOf[h.index] = i; });
	for (const h of hierarchy) {
		const own = assign[h.index];
		const inherited = h.parent >= 0 ? partOf[h.parent] : null;
		partOf[h.index] = own || inherited || fallback;
	}

	// Step 2. Which bones are worth keeping. A bone with no cubes anywhere below
	// it carries nothing; the model gains a hundred empty elements and the tree
	// becomes unreadable. Walking backwards marks the ancestors of a keeper.
	const cubesByNode = {};
	for (const c of cubes) (cubesByNode[c.node] = cubesByNode[c.node] || []).push(c);
	const keep = {};
	for (let i = hierarchy.length - 1; i >= 0; i--) {
		const h = hierarchy[i];
		if (cubesByNode[h.index] || keep[h.index]) {
			keep[h.index] = true;
			if (h.parent >= 0) keep[h.parent] = true;
		}
	}

	// Step 2a. Collapse the nodes glTF creates just to hold a mesh.
	//
	// This is not tidiness. CPM counts EVERY element against MAX_CUBE_COUNT,
	// empty ones included (ModelDefinition:162 counts cubes.size()), and the
	// default limit is 256. One node per mesh doubles the count for nothing: the
	// node's pivot has no life of its own, and its box already carries its own
	// position. Dropping them took this model from 248 elements to 140.
	//
	// A node an animation moves is never collapsed — there it IS the pivot, and
	// merging it away would leave the animation nothing to turn.
	const animated = input.keepNodes || new Set();
	const collapse = {};
	const hostOf = {};
	for (const h of hierarchy) {
		const parentHost = h.parent >= 0 ? hostOf[h.parent] : undefined;
		collapse[h.index] = keep[h.index] && h.hasMesh && !animated.has(h.index) && parentHost !== undefined;
		hostOf[h.index] = collapse[h.index] ? parentHost : h.index;
	}

	// Step 3. The elements themselves.
	let storeID = 1000;
	const roots = {};
	const elemOf = {};
	const attachOf = {};
	const usedParts = {};

	const rootFor = part => {
		if (!roots[part]) {
			roots[part] = {
				id: part,
				// The vanilla part is hidden: our model stands in its place. Its pivot
				// is left where it is, so vanilla animation still swings the limb.
				show: false,
				showInEditor: true,
				locked: false,
				pos: vec3(0, 0, 0),
				rotation: vec3(0, 0, 0),
				dup: false,
				// When the model brings its own walk, the vanilla arm swing lands on
				// top of it and the motion is played twice. The head is normally left
				// alone even so: vanilla animation is what makes it follow the camera,
				// and a character that no longer looks where you look reads as broken.
				disableVanillaAnim: !!(input.stopVanillaAnim && input.stopVanillaAnim[part]),
				name: '',
				nameColor: 0,
				children: [],
			};
			usedParts[part] = 0;
		}
		return roots[part];
	};

	for (const h of hierarchy) {
		if (!keep[h.index] || collapse[h.index]) continue;
		const part = partOf[h.index];
		const host = h.parent >= 0 ? hostOf[h.parent] : undefined;
		const parentKept = host !== undefined && keep[host];
		// A bone whose parent went to a different part cannot hang off it: it
		// starts a new subtree under its own part, measured from that part's pivot.
		const attachToRoot = !parentKept || partOf[host] !== part;

		const pos = attachToRoot
			? sub(add(cpmPoint(mul(h.pivot, k)), align), CPM_PARTS[part])
			: cpmDelta(mul(sub(h.pivot, hierarchy[indexOf[host]].pivot), k));

		const el = cpmElement({
			name: h.name,
			pos,
			size: [0, 0, 0],
			storeID: storeID++,
		});
		el.children = [];
		elemOf[h.index] = el;
		if (attachToRoot) {
			rootFor(part).children.push(el);
			usedParts[part]++;
			attachOf[h.index] = { parent: null, part };
		} else {
			elemOf[host].children.push(el);
			attachOf[h.index] = { parent: host, part };
		}
	}

	// Step 4. Cubes, each under the bone of its own node.
	let placed = 0;
	for (const c of cubes) {
		const host = hostOf[c.node];
		const bone = elemOf[host];
		if (!bone) { warnings.push(`${c.name}: no bone for node ${c.node}, cube dropped`); continue; }
		const h = hierarchy[indexOf[host]];
		const place = placeCoords(c.sol);
		const half = c.sol.size.map(v => Math.abs(v) / 2);
		const from = place(sub(c.sol.center, half));
		const to = place(add(c.sol.center, half));
		const center = from.map((v, i) => (v + to[i]) / 2);
		const size = from.map((v, i) => Math.abs(to[i] - v) * k);

		const el = cpmElement({
			name: c.name,
			// CPM places a box as: shift by pos, rotate, shift by offset, then draw
			// size. Putting the pivot at the centre and the offset at minus half the
			// size reproduces Blockbench exactly, where a cube turns about origin and
			// our origin is the centre.
			pos: cpmDelta(mul(sub(center, h.pivot), k)),
			rotation: cpmEuler(c.sol),
			offset: size.map(v => -v / 2),
			size,
			mcScale: (c.inflate || 0) * k,
			storeID: storeID++,
			faceUV: cpmFaceUV(c.sol, uvMul),
		});
		bone.children.push(el);
		placed++;
	}

	// Empty bones can survive step 2 as ancestors of a keeper; that is fine. What
	// is not fine is a part that ended up with nothing at all.
	const parts = Object.keys(roots);
	if (!parts.length) warnings.push('nothing was assigned to any player part');

	// Every vanilla part is hidden, including the ones we did not fill: a half
	// vanilla, half custom player is never what anyone meant by replacing a model.
	for (const p of CPM_PART_NAMES) rootFor(p);

	return {
		elements: CPM_PART_NAMES.map(p => roots[p]),
		// Animations address elements by storeID and need each bone's rest position
		// to write an absolute value, so the built elements are handed back rather
		// than being rebuilt from the JSON afterwards.
		elemByNode: elemOf,
		// Where each bone actually ended up: under another bone, or straight under a
		// player part. Animations need this, because a bone's parent in the CPM tree
		// is often NOT its parent in glTF.
		attachOf,
		warnings,
		stats: { cubes: placed, bones: Object.keys(elemOf).length, parts: usedParts },
	};
}

/**
 * Which vanilla pose an animation is called by, guessed from its name.
 *
 * Sketchfab models come from Blockbench and Blockbench-likes, where these names
 * are a de facto standard: the fourteen animations of the test model all land
 * without a correction. Anything unrecognised becomes a gesture, which is the
 * safe outcome — a gesture plays on demand and never replaces vanilla motion.
 */
const CPM_POSE_GUESS = [
	[/^(idle|stand)/, 'STANDING'],
	[/^(sneak.?walk|crouch.?walk)/, 'SNEAK_WALK'],
	[/^(walk)/, 'WALKING'],
	[/^(run|sprint)/, 'RUNNING'],
	[/^(sneak|crouch|squat)$/, 'SNEAKING'],
	[/^(swim)/, 'SWIMMING'],
	[/^(sleep)/, 'SLEEPING'],
	[/^(sit|ride|riding)/, 'RIDING'],
	// Elytra flight is FLYING, not WEARING_ELYTRA: AnimationState.getMainPose
	// returns FLYING for elytraFlying, while WEARING_ELYTRA is a layer that
	// applies whenever an elytra is worn, flying or not. Plain "flying" is left
	// to creative flight, which is what the word usually means in a model.
	[/elytra/, 'FLYING'],
	[/^(fly|flying|hover)/, 'CREATIVE_FLYING'],
	[/^(fall)/, 'FALLING'],
	[/^(jump)/, 'JUMPING'],
	[/^(die|dying|death)/, 'DYING'],
	[/^(hurt|damage)/, 'HURT'],
];

/**
 * The poses offered in the dialog. CPM has about sixty, most of them about
 * holding a particular item; a list that long is unreadable, and everything
 * missing from it is still reachable inside the CPM editor afterwards.
 */
const CPM_POSE_OPTIONS = [
	'STANDING', 'WALKING', 'RUNNING', 'SNEAKING', 'SNEAK_WALK', 'JUMPING', 'FALLING',
	'SWIMMING', 'SLEEPING', 'RIDING', 'FLYING', 'CREATIVE_FLYING', 'WEARING_ELYTRA',
	'ON_LADDER', 'CLIMBING_ON_LADDER', 'DYING', 'HURT', 'ON_FIRE',
];

/**
 * The poses AnimationState.getMainPose can settle on, in its own priority order.
 *
 * Worth listing because of what happens in the gaps. The pose is chosen by
 * player state, first match wins, and if the model has nothing for the chosen
 * one it simply keeps its rest pose. That is harmless on its own — vanilla
 * animation still moves the limbs — but becomes a frozen model the moment
 * disableVanillaAnim is switched on for a part.
 */
const CPM_MAIN_POSES = [
	'SLEEPING', 'DYING', 'FLYING', 'TRIDENT_SPIN', 'FALLING', 'RIDING', 'CREATIVE_FLYING',
	'CRAWLING', 'SWIMMING', 'RETRO_SWIMMING', 'CLIMBING_ON_LADDER', 'ON_LADDER',
	'JUMPING', 'SNEAK_WALK', 'SNEAKING', 'RUNNING', 'WALKING', 'STANDING',
];

function cpmAutoPose(name) {
	const n = String(name || '').toLowerCase().trim();
	for (const [re, pose] of CPM_POSE_GUESS) if (re.test(n)) return pose;
	return 'gesture';
}

/**
 * Animations for the .cpmproject.
 *
 * CPM does not store curves. A frame is a SNAPSHOT: a list of elements with
 * their absolute position and rotation, and the frames are spread evenly over
 * `duration` (EditorAnim.animate computes the step as
 * `millis % duration / duration * frames.size()`). So the glTF curves are
 * sampled at a fixed rate, and the last frame interpolates back into the first.
 *
 * The offsets are NOT carried over one bone at a time, the way the GeckoLib
 * branch does it. There a bone keeps its glTF parent, so a local offset is all
 * that is needed. Here it is not: the head hangs off the player's head part
 * while in glTF it sits under the body, so a rotation of the body would simply
 * fail to reach it and the model would come apart mid-animation.
 *
 * So each frame is computed from the WORLD pose. For every bone we work out
 * where glTF puts it at that moment, then express that against whatever its
 * parent in the CPM tree happens to be. Bones whose two parents coincide come
 * out with exactly the local offset anyway; the ones that cross a part boundary
 * come out right instead of coming apart.
 */
function buildCPMAnimations(input) {
	const hierarchy = input.hierarchy;
	const elemByNode = input.elemByNode;
	const attachOf = input.attachOf || {};
	const poses = input.poses || {};
	const fps = input.fps || 12;
	const maxFrames = input.maxFrames || 60;
	const scale = input.scale || 16;
	const k = input.k || 1;
	// The same shift onto the player's skeleton the rest pose got. For a nested
	// bone it cancels out in the difference against its parent; for one hanging
	// off a player part it does not, because the part pivot does not move.
	const align = input.align || [0, 0, 0];
	const files = {};
	const warnings = [];
	const stats = { animations: 0, frames: 0, components: 0, skipped: [], moved: 0 };

	const byIdx = {};
	for (const h of hierarchy) byIdx[h.index] = h;

	// The base frame the parser started from: the extra rotation from the dialog
	// is baked into it, and a root node carries it as its parentQuat.
	const firstRoot = hierarchy.find(h => h.parent < 0);
	const base = matFromTRS([0, 0, 0], (firstRoot && firstRoot.parentQuat) || [0, 0, 0, 1], [1, 1, 1]);

	/** World matrices for the whole tree, with `at` overriding the rest pose. */
	const worldAll = at => {
		const w = {};
		for (const h of hierarchy) {
			const o = (at && at[h.index]) || {};
			const local = matFromTRS(
				o.translation || h.rest.translation,
				o.rotation || h.rest.rotation,
				h.rest.scale);
			w[h.index] = matMul(h.parent >= 0 ? w[h.parent] : base, local);
		}
		return w;
	};

	const restWorld = worldAll(null);
	// Rest positions come from the parser rather than from this matrix: it already
	// carries the centring offset, and reproducing that here would be a second
	// place for the two to drift apart.
	const restOrigin = {};
	for (const h of hierarchy) restOrigin[h.index] = matApply(restWorld[h.index], [0, 0, 0]);

	// Which bones have an element of their own. Cubes need no frames: they sit
	// under their bone and follow it.
	const boneNodes = hierarchy.filter(h => elemByNode[h.index]).map(h => h.index);

	for (const a of input.animations) {
		const choice = poses[a.name] || 'gesture';
		if (choice === 'skip') { stats.skipped.push(a.name); continue; }

		const channels = a.channels.filter(ch => ch.path !== 'scale');
		if (!channels.length) { warnings.push(`${a.name}: no rotation or position channels`); continue; }

		// A static pose is an animation of zero length: one frame, held.
		const isPose = a.length < 1e-6;
		const count = isPose ? 1 : Math.max(2, Math.min(maxFrames, Math.round(a.length * fps)));

		// Pass one: work out every bone's local transform in every frame, and note
		// which of them ever leave their rest pose. A bone that moves in one frame
		// is written in ALL of them — a bone that appears and vanishes between
		// frames would have the player guessing what it interpolates towards.
		const perFrame = [];
		const moves = new Set();
		for (let i = 0; i < count; i++) {
			const t = isPose ? 0 : (i / count) * a.length;
			const at = {};
			for (const ch of channels) (at[ch.node] = at[ch.node] || {})[ch.path] = sampleChannel(ch, t);
			const world = worldAll(at);

			// Where every bone stands now, in CPM coordinates, and how it is turned.
			const P = {}, R = {};
			for (const n of boneNodes) {
				const h = byIdx[n];
				const moved = matApply(world[n], [0, 0, 0]);
				const o = restOrigin[n];
				// The pivot from the parser already holds scale and centring, so only
				// the displacement since rest is scaled and added to it.
				const bb = [
					h.pivot[0] + (moved[0] - o[0]) * scale,
					h.pivot[1] + (moved[1] - o[1]) * scale,
					h.pivot[2] + (moved[2] - o[2]) * scale,
				];
				P[n] = add(cpmPoint(mul(bb, k)), align);
				// The rest pose is baked into the geometry while the bone stands
				// unrotated, so what the frame carries is the change since rest.
				R[n] = cpmConjugate(mat3Mul(mat3FromMat4(world[n]), mat3T(mat3FromMat4(restWorld[n]))));
			}

			const locals = {};
			for (const n of boneNodes) {
				const att = attachOf[n] || { parent: null, part: 'body' };
				const parentP = att.parent !== null && P[att.parent] ? P[att.parent] : CPM_PARTS[att.part] || [0, 0, 0];
				const parentR = att.parent !== null && R[att.parent] ? R[att.parent] : MAT3_ID;
				const inv = mat3T(parentR);
				const pos = mat3Apply(inv, sub(P[n], parentP));
				const rot = cpmEulerZYX(mat3Mul(inv, R[n]));
				locals[n] = { pos, rot };

				const el = elemByNode[n];
				const dp = Math.hypot(pos[0] - el.pos.x, pos[1] - el.pos.y, pos[2] - el.pos.z);
				const dr = Math.max(...rot.map(v => Math.min(v, 360 - v)));
				if (dp > 0.01 || dr > 0.05) moves.add(n);
			}
			perFrame.push(locals);
		}

		if (!moves.size) { warnings.push(`${a.name}: nothing moves, skipped`); continue; }
		stats.moved += moves.size;

		const frames = perFrame.map(locals => {
			const components = [];
			for (const n of moves) {
				const el = elemByNode[n];
				components.push({
					storeID: el.storeID,
					pos: vec3(...locals[n].pos),
					rotation: vec3(...locals[n].rot),
					scale: vec3(1, 1, 1),
					color: 'ffffff',
					show: true,
				});
			}
			stats.components += components.length;
			return { components };
		});

		const vanilla = choice !== 'gesture';
		const clean = String(a.name).replace(/[^a-zA-Z0-9.\-]/g, '');
		const id = cpmRandomId();
		const file = vanilla
			? `v_${choice.toLowerCase()}_${clean}_${id}.json`
			: `g_${clean}_${id}.json`;

		files['animations/' + file] = JSON.stringify({
			name: a.name,
			additive: false,
			// Zero-length poses would otherwise play out in a millisecond.
			duration: isPose ? 1000 : Math.max(1, Math.round(a.length * 1000)),
			priority: 0,
			loop: !isPose,
			// glTF interpolates linearly. A spline over sparse oscillating values —
			// legs in a walk cycle go +1, 0, −1, 0 — overshoots well past them.
			interpolator: isPose ? 'linear_single' : 'linear_loop',
			layerDefault: 0,
			order: 0,
			isProperty: false,
			command: false,
			layerControlled: true,
			maxValue: 100,
			interpolateVal: true,
			mustFinish: false,
			hidden: false,
			frames,
		}, null, 1);

		stats.animations++;
		stats.frames += frames.length;
	}

	return { files, warnings, stats };
}

/**
 * How large the model will be once CPM encodes it, in bytes.
 *
 * This matters more than it sounds. A local `.cpmmodel` gets a buffer of
 * exactly 30 kB (Exporter.ModelWriter: `new byte[skinCompat ? 2*1024 : 30*1024]`),
 * and anything past that has to be uploaded to a paste site instead of just
 * working. Without a number here the overflow is a surprise at the end of a long
 * export; with one it is a decision taken up front, where the levers are.
 *
 * The estimate follows the mod's own writers: saveDefinitionCubeV2 for boxes,
 * writeFaces for per-face UV, and ModelPartAnimation.write for frames — where a
 * track whose values never leave the element's rest pose is dropped entirely
 * (`hasPosChanges`), so a bone that only turns costs nothing for position.
 */
function cpmEstimateSize(config, animations, skinBytes) {
	// A CPM float is stored as a signed varint of value×682 (IOHelper DIV).
	const varLen = v => {
		let n = Math.abs(Math.round(v)) * 2;
		let len = 1;
		while (n >= 128) { n = Math.floor(n / 128); len++; }
		return len;
	};
	const vecLen = v => varLen(v.x * 682) + varLen(v.y * 682) + varLen(v.z * 682);

	let cubes = 0, count = 0;
	const byStore = {};
	const walk = list => {
		for (const el of list || []) {
			count++;
			byStore[el.storeID] = el;
			const box = el.size.x || el.size.y || el.size.z;
			// flags, parent, pos, rotation
			let n = 1 + 2 + vecLen(el.pos) + 6;
			if (box) {
				n += vecLen(el.size) + vecLen(el.offset);
				n += 1 + varLen(el.u) + varLen(el.v);
				if (el.faceUV) {
					n += 1;
					for (const f of Object.values(el.faceUV)) {
						n += varLen(f.sx) + varLen(f.sy) + varLen(f.ex) + varLen(f.ey) + 1;
					}
				}
			}
			cubes += n;
			walk(el.children);
		}
	};
	for (const root of config.elements) walk(root.children);

	let anim = 0;
	for (const raw of Object.values(animations || {})) {
		const a = typeof raw === 'string' ? JSON.parse(raw) : raw;
		const frames = a.frames.length;
		anim += 30 + (a.name || '').length;
		// A track is kept only if it leaves the element's REST pose, not merely if
		// it varies: a bone held at a constant offset still needs storing.
		const seen = {};
		for (const f of a.frames) {
			for (const c of f.components) {
				const el = byStore[c.storeID];
				if (!el) continue;
				const s = seen[c.storeID] = seen[c.storeID] || { pos: false, rot: false };
				const off = (v, r) => Math.abs(v - r) > 0.01;
				if (off(c.pos.x, el.pos.x) || off(c.pos.y, el.pos.y) || off(c.pos.z, el.pos.z)) s.pos = true;
				if (off(c.rotation.x, el.rotation.x) || off(c.rotation.y, el.rotation.y)
					|| off(c.rotation.z, el.rotation.z)) s.rot = true;
			}
		}
		for (const s of Object.values(seen)) {
			anim += 2;
			// six bytes a frame for a track: three shorts, whether angle or position
			if (s.pos) anim += 5 + 6 * frames;
			if (s.rot) anim += 5 + 6 * frames;
		}
	}

	const texture = skinBytes ? skinBytes.length : 0;
	return { cubes, anim, texture, elements: count, total: cubes + anim + texture };
}

/**
 * An id for an animation filename. CPM puts a UUID there; nothing parses it,
 * it only has to keep two animations of the same name apart.
 */
function cpmRandomId() {
	const hex = n => Array.from({ length: n }, () => Math.floor(Math.random() * 16).toString(16)).join('');
	return `${hex(8)}-${hex(4)}-${hex(4)}-${hex(4)}-${hex(12)}`;
}

function vec3(x, y, z) { return { x: round4(x), y: round4(y), z: round4(z) }; }
function round4(v) {
	const r = Math.round(v * 10000) / 10000;
	return Object.is(r, -0) ? 0 : r;
}

/** One element of the CPM tree, with every field its loader reads. */
function cpmElement(o) {
	const el = {
		name: o.name || '',
		show: true,
		texture: true,
		textureSize: 1,
		offset: vec3(...(o.offset || [0, 0, 0])),
		pos: vec3(...(o.pos || [0, 0, 0])),
		rotation: vec3(...(o.rotation || [0, 0, 0])),
		size: vec3(...(o.size || [0, 0, 0])),
		rscale: vec3(1, 1, 1),
		scale: vec3(1, 1, 1),
		u: 0,
		v: 0,
		color: 'ffffff',
		mirror: false,
		mcScale: o.mcScale || 0,
		glow: false,
		recolor: false,
		hidden: false,
		singleTex: false,
		extrude: false,
		locked: false,
		nameColor: 0,
		storeID: o.storeID || 0,
	};
	if (o.faceUV) el.faceUV = o.faceUV;
	return el;
}

/**
 * Per-face UV for one cube.
 *
 * A face missing from the map is not drawn at all — which is exactly what we
 * want for faces the source model never had. Mirroring needs no special case:
 * Blockbench writes it as a rectangle with x1 > x2, and CPM reads sx and ex in
 * the same order, so the flip carries over by itself.
 */
function cpmFaceUV(sol, mul) {
	const out = {};
	for (const name of FACE_NAMES) {
		const uv = sol.faceUV[name];
		if (!uv) continue;
		const f = CPM_FACE[name];
		out[f.dir] = {
			sx: Math.round(uv[0] * mul),
			sy: Math.round(uv[1] * mul),
			ex: Math.round(uv[2] * mul),
			ey: Math.round(uv[3] * mul),
			rot: f.rot,
			autoUV: false,
		};
	}
	return out;
}

/**
 * The files of a .cpmproject, ready to be zipped.
 *
 * Zipping is left to the caller on purpose: inside Blockbench that is JSZip,
 * and in the test harness a dozen lines of stored-entry writer. The part worth
 * checking is the content, and it is the same on both paths.
 */
function buildCPMFiles(input) {
	const built = buildCPMConfig(input);
	const config = {
		version: 1,
		skinType: input.skinType || 'default',
		elements: built.elements,
		skinSize: { x: input.uvWidth, y: input.uvHeight },
		textures: { skin: { customGridSize: input.uvWidth !== input.texWidth || input.uvHeight !== input.texHeight, anim: [] } },
		scaling: 0,
		hideHeadIfSkull: true,
		removeArmorOffset: true,
		removeBedOffset: false,
		enableInvisGlow: false,
	};
	const files = {
		'config.json': JSON.stringify(config, null, 1),
		'description.json': JSON.stringify({
			name: input.name || '',
			desc: input.description || '',
			cam: { pos: { x: 0.5, y: 1, z: 0.5 }, look: { x: 0.25, y: 0.5, z: 0.25 }, zoom: 64, copyProt: 'normal' },
		}, null, 1),
	};
	if (input.skin) files['skin.png'] = input.skin;

	let anims = { files: {}, warnings: [], stats: { animations: 0, frames: 0, components: 0, skipped: [], moved: 0 } };
	if (input.animations && input.animations.length) {
		anims = buildCPMAnimations({
			animations: input.animations,
			hierarchy: input.hierarchy,
			elemByNode: built.elemByNode,
			attachOf: built.attachOf,
			align: input.align,
			poses: input.poses,
			fps: input.fps,
			maxFrames: input.maxFrames,
			scale: input.gltfScale,
			k: input.scale,
		});
		Object.assign(files, anims.files);
	}

	return {
		files,
		config,
		warnings: built.warnings.concat(anims.warnings),
		stats: Object.assign({}, built.stats, {
			anim: anims.stats,
			size: cpmEstimateSize(config, anims.files, input.skin),
		}),
	};
}

// ------------------------------------------------------------ Node export

if (typeof Plugin === 'undefined') {
	if (typeof module !== 'undefined') {
		module.exports = {
			solveBox, detectBox, orientations, assignFaces, countUVViolations, buildFaceUV,
			FACE_DIRS, FACE_NAMES,
			parseGLTFFiles, parseGLB, parseAnimations, readAccessor, matMul, matFromTRS, matApply, matIdentity,
			qMul, qConj, qRotate, qNormalize, qSlerp, boneDeltaRotation, boneDeltaPosition, sampleChannel, channelKeyValue, pickScale, snapScale, texelScale, correctionQuat, packAtlas, splitComponents, boxFromBounds, TRIANGULATE, isDegenerate, imageSize, sniffMime, axisRotationOf, quatFromMat, signedBasisFromMat, linearPartFromMat, triangleNormal, snapGrid, snapVec, snapAngle, isIdentityBasis, placeCoords, snapSafely, tidyVec, hasGltfArchive, resolveCoplanar, cubeFaces, faceRectsOverlap,
			buildCPMFiles, buildCPMConfig, buildCPMAnimations, cpmAlignOffset, cpmEstimateSize, cpmAutoAssign, cpmAutoPose, cpmPoint, cpmDelta, cpmEuler, cpmEulerFromQuat, cpmAngle, cpmUVScale, cpmFaceUV, CPM_PARTS, CPM_PART_NAMES, CPM_FACE,
		};
	}
	return;
}

// ---------------------------------------------------- Blockbench integration

/**
 * Blockbench composes a cube rotation through THREE.Euler, and the axis order
 * depends on version and format. Guessing is not an option, so we ask
 * Blockbench itself: create a temporary cube and read order off its THREE object.
 */
// ZYX is what Blockbench actually returned when measured. Kept as a fallback
// in case the probe fails.
let EULER_ORDER = 'ZYX';
function detectEulerOrder() {
	try {
		const probe = new Cube({ from: [0, 0, 0], to: [1, 1, 1], origin: [0, 0, 0], rotation: [10, 20, 30] }).init();
		const order = probe.mesh && probe.mesh.rotation && probe.mesh.rotation.order;
		probe.remove();
		if (order) EULER_ORDER = order;
	} catch (e) {
		console.warn(`[geckolib-import] could not detect Euler order, falling back to ${EULER_ORDER}`, e);
	}
	return EULER_ORDER;
}

/**
 * Measures the UV convention from Blockbench itself.
 *
 * A probe cube is created, a deliberately asymmetric rectangle [0,0,4,8] is put
 * on every face, and the resulting geometry is read back: each pair of (vertex
 * position, its UV) shows which way u and v grow on that face.
 * No assumptions about the convention — measurement only.
 *
 * @returns {string} what was determined, for the report
 */
function calibrateFaceDirs() {
	const FACE_BY_NORMAL = {
		'0,0,-1': 'north', '0,0,1': 'south',
		'1,0,0': 'east', '-1,0,0': 'west',
		'0,1,0': 'up', '0,-1,0': 'down',
	};
	// round to the nearest axis direction
	const axisOf = v => {
		const a = [Math.abs(v[0]), Math.abs(v[1]), Math.abs(v[2])];
		const i = a.indexOf(Math.max(...a));
		const out = [0, 0, 0];
		out[i] = v[i] > 0 ? 1 : -1;
		return out;
	};

	let probe = null;
	try {
		probe = new Cube({
			from: [0, 0, 0], to: [16, 16, 16], origin: [8, 8, 8],
			box_uv: false, autouv: 0, name: '__probe__',
		}).init();
		for (const name of FACE_NAMES) probe.faces[name].uv = [0, 0, 4, 8];
		if (Canvas.updateUV) Canvas.updateUV(probe); else Canvas.updateAll();

		const geo = probe.mesh && probe.mesh.geometry;
		const posAttr = geo && geo.attributes && geo.attributes.position;
		const uvAttr = geo && geo.attributes && geo.attributes.uv;
		if (!posAttr || !uvAttr) throw new Error('cube has no position/uv attributes');
		if (posAttr.count !== 24) throw new Error(`expected 24 vertices, got ${posAttr.count}`);

		const pos = posAttr.array, buv = uvAttr.array;
		// The centre comes from the geometry itself rather than our assumptions:
		// Blockbench builds a cube relative to origin, not to zero.
		const lo = [Infinity, Infinity, Infinity], hi = [-Infinity, -Infinity, -Infinity];
		for (let k = 0; k < 24; k++) for (let a = 0; a < 3; a++) {
			const c = pos[k * 3 + a];
			if (c < lo[a]) lo[a] = c;
			if (c > hi[a]) hi[a] = c;
		}
		const mid = [0, 1, 2].map(a => (lo[a] + hi[a]) / 2);
		const half = [0, 1, 2].map(a => (hi[a] - lo[a]) / 2);
		const tol = Math.max(...half) * 1e-3;

		// The V axis in the buffer may be flipped (WebGL counts bottom-up).
		// The rectangle was placed flush against the edge: unflipped its minimum is
		// exactly 0, flipped its maximum is exactly 1.
		let vlo = Infinity, vhi = -Infinity;
		for (let k = 0; k < 24; k++) {
			const v = buv[k * 2 + 1];
			if (v < vlo) vlo = v;
			if (v > vhi) vhi = v;
		}
		const flipped = !(vlo < 0.001);

		const found = {};
		for (let f = 0; f < 6; f++) {
			const verts = [];
			for (let i = 0; i < 4; i++) {
				const k = f * 4 + i;
				verts.push({
					pos: [0, 1, 2].map(a => pos[k * 3 + a] - mid[a]),
					// work straight in buffer coordinates so as not to depend on
					// texture size; only the ordering matters, not the scale
					bu: buv[k * 2],
					bv: flipped ? -buv[k * 2 + 1] : buv[k * 2 + 1],
				});
			}
			// face normal: the one axis on which all four vertices agree
			let normal = null;
			for (let a = 0; a < 3 && !normal; a++) {
				const v0 = verts[0].pos[a];
				if (Math.abs(Math.abs(v0) - half[a]) > tol) continue;
				if (verts.every(v => Math.abs(v.pos[a] - v0) < tol)) {
					normal = [0, 0, 0];
					normal[a] = v0 > 0 ? 1 : -1;
				}
			}
			const name = normal && FACE_BY_NORMAL[normal.join(',')];
			if (!name) continue;

			// the rectangle starts at the corner with the smallest u and v
			const ulo = Math.min(...verts.map(v => v.bu));
			const vlo2 = Math.min(...verts.map(v => v.bv));
			const base = verts.find(v => Math.abs(v.bu - ulo) < 1e-6 && Math.abs(v.bv - vlo2) < 1e-6);
			if (!base) continue;
			const uEnd = verts.find(v => Math.abs(v.bv - base.bv) < 1e-6 && v.bu - base.bu > 1e-6);
			const vEnd = verts.find(v => Math.abs(v.bu - base.bu) < 1e-6 && v.bv - base.bv > 1e-6);
			if (!uEnd || !vEnd) continue;

			found[name] = { normal, u: axisOf(sub(uEnd.pos, base.pos)), v: axisOf(sub(vEnd.pos, base.pos)) };
		}

		const missing = FACE_NAMES.filter(n => !found[n]);
		if (missing.length) {
			// report what was actually seen, or debugging turns into guesswork
			throw new Error(`could not read faces: ${missing.join(', ')}`
				+ ` | bounds [${lo.map(v => v.toFixed(1))}]…[${hi.map(v => v.toFixed(1))}]`
				+ ` | bufV ${vlo.toFixed(3)}…${vhi.toFixed(3)}, flipped=${flipped}`
				+ ` | faces read: ${Object.keys(found).length}`);
		}

		const changed = FACE_NAMES.filter(n =>
			FACE_DIRS[n].u.join() !== found[n].u.join() || FACE_DIRS[n].v.join() !== found[n].v.join());
		FACE_DIRS = found;

		const table = FACE_NAMES.map(n => `${n}: u=[${found[n].u}] v=[${found[n].v}]`).join('\n  ');
		return `UV convention measured from Blockbench (V ${flipped ? 'flipped' : 'direct'}).\n` +
			`  Mismatches against the fallback table: ${changed.length}${changed.length ? ' (' + changed.join(', ') + ')' : ''}\n  ${table}`;
	} catch (e) {
		return `Could not measure the UV convention (${(e && e.message) || e}), using the fallback table.`;
	} finally {
		if (probe) { try { probe.remove(); } catch (e) { /* already gone */ } }
	}
}

/** World coordinates of a mesh vertex (vertices are stored local to origin). */
function meshVertexToWorld(mesh, v) {
	const rot = mesh.rotation || [0, 0, 0];
	let p = v;
	if (rot[0] || rot[1] || rot[2]) {
		const e = new THREE.Euler(
			THREE.MathUtils.degToRad(rot[0]),
			THREE.MathUtils.degToRad(rot[1]),
			THREE.MathUtils.degToRad(rot[2]),
			EULER_ORDER
		);
		const vec = new THREE.Vector3(v[0], v[1], v[2]).applyEuler(e);
		p = [vec.x, vec.y, vec.z];
	}
	return add(p, mesh.origin || [0, 0, 0]);
}

/** Converts a Blockbench mesh into the normalised input for solveBox. */
function meshToFaces(mesh) {
	const world = {};
	for (const vkey in mesh.vertices) world[vkey] = meshVertexToWorld(mesh, mesh.vertices[vkey]);

	const faces = [];
	for (const fkey in mesh.faces) {
		const face = mesh.faces[fkey];
		if (!face.vertices || !face.vertices.length) continue;
		faces.push({
			positions: face.vertices.map(vkey => world[vkey]),
			uvs: face.vertices.map(vkey => (face.uv && face.uv[vkey]) || null),
			texture: face.texture,
		});
	}
	return faces;
}

/**
 * Build a Blockbench Mesh directly from parsed glTF triangles.
 *
 * Parsed positions are already in the same world/reference space used by the
 * cube importer.  Keeping the mesh at origin 0 therefore preserves exactly the
 * same placement while avoiding the lossy box detection path.
 *
 * Blockbench stores face V from the top of the texture while glTF/our atlas
 * mapping uses the opposite convention for mesh export.  The V flip here is
 * reversed again by compileBlockbenchMeshIntoPolyMesh(), so what is written to
 * poly_mesh is the original atlas UV.
 */
function meshFromTriangleFaces(name, faces, texture, preserveSkinVertices = false) {
	const mesh = new Mesh({
		name,
		origin: [0, 0, 0],
		rotation: [0, 0, 0],
		autouv: 0,
		vertices: {},
	});
	const keyByPosition = new Map();
	const meshFaces = [];
	const vertexSkin = {};
	const posKey = p => p.map(v => Math.round(Number(v) * 1e6) / 1e6).join(',');
	const skinKey = influences => {
		if (!preserveSkinVertices || !Array.isArray(influences) || !influences.length) return '';
		return influences
			.filter(x => x && x.node !== undefined && Number(x.weight) > 1e-8)
			.map(x => `${x.node}:${Math.round(Number(x.weight) * 1e7) / 1e7}`)
			.sort()
			.join('|');
	};

	for (const face of faces || []) {
		if (!face.positions || face.positions.length < 3) continue;
		const keys = [];
		for (let vi = 0; vi < face.positions.length; vi++) {
			const pos = face.positions[vi];
			const influences = face.skinVertices && face.skinVertices[vi];
			// A glTF file can duplicate a position at a UV seam and, more rarely,
			// give those duplicates different skin weights.  Native preview must not
			// merge such vertices or the two weight sets become impossible to represent.
			const pk = posKey(pos) + (preserveSkinVertices ? `#${skinKey(influences)}` : '');
			let key = keyByPosition.get(pk);
			if (!key) {
				key = typeof guid === 'function' ? guid() : `v_${keyByPosition.size}`;
				keyByPosition.set(pk, key);
				mesh.vertices[key] = pos.slice(0, 3);
				if (preserveSkinVertices && Array.isArray(influences) && influences.length) {
					vertexSkin[key] = influences
						.filter(x => x && x.node !== undefined && Number(x.weight) > 1e-8)
						.map(x => ({ node: x.node, weight: Number(x.weight) }));
				}
			}
			keys.push(key);
		}
		// Degenerate triangles are useless and can upset the normal calculation.
		if (new Set(keys).size < 3) continue;

		const uv = {};
		for (let i = 0; i < keys.length; i++) {
			const src = face.uvs && face.uvs[i] ? face.uvs[i] : [0, 0];
			// Blockbench Mesh UVs use the same V orientation as its glTF importer.
			// Do NOT flip V here. The Bedrock/poly_mesh conversion below performs
			// the required V conversion once on export; flipping both places made
			// the visible texture sample the wrong half/section of the image.
			uv[keys[i]] = [Number(src[0]) || 0, Number(src[1]) || 0];
		}
		meshFaces.push(new MeshFace(mesh, {
			vertices: keys,
			uv,
			texture: texture || undefined,
		}));
	}

	mesh.addFaces(...meshFaces);
	if (Object.keys(vertexSkin).length) mesh.__cs2VertexSkin = vertexSkin;
	return mesh;
}

/**
 * Rotate a point around a Blockbench mesh origin, then encode it for the
 * selected GeckoMesh runtime.
 *
 * IMPORTANT:
 * - GeckoMesh 1.0 (CurseMaven 8266268) uses poly_mesh X exactly as stored.
 *   Export Blockbench X unchanged.
 * - GeckoMesh 1.1+ negates poly_mesh X inside PolyMeshConverter.
 *   Pre-negate X here so the runtime negation restores Blockbench X.
 *
 * Bone pivots and animations are handled by the normal Bedrock/GeckoLib codec.
 * Using the wrong convention mirrors only the PolyMesh geometry relative to
 * those bones, which is why the model looked correct in Blockbench but mirrored
 * and animated incorrectly in-game.
 */
function polyMeshExportPoint(mesh, point) {
	const origin = mesh.origin || [0, 0, 0];
	let x = point[0] + origin[0], y = point[1] + origin[1], z = point[2] + origin[2];
	const rot = mesh.rotation || [0, 0, 0];
	if (rot[0] || rot[1] || rot[2]) {
		const rx = rot[0] * Math.PI / 180, ry = rot[1] * Math.PI / 180, rz = rot[2] * Math.PI / 180;
		x -= origin[0]; y -= origin[1]; z -= origin[2];
		let t = y; y = y * Math.cos(rx) - z * Math.sin(rx); z = t * Math.sin(rx) + z * Math.cos(rx);
		t = x; x = x * Math.cos(ry) + z * Math.sin(ry); z = -t * Math.sin(ry) + z * Math.cos(ry);
		t = x; x = x * Math.cos(rz) - y * Math.sin(rz); y = t * Math.sin(rz) + y * Math.cos(rz);
		x += origin[0]; y += origin[1]; z += origin[2];
	}

	const exportX = polyMeshGeckoMeshRuntime === '1_1_plus' ? -x : x;
	return [exportX, y, z];
}

/**
 * Append one Blockbench Mesh to a Bedrock/GeckoLib poly_mesh object.
 * This is intentionally self-contained so the importer does not require the
 * separate Meshy Blockbench plugin.
 */
function compileBlockbenchMeshIntoPolyMesh(polyMesh, mesh) {
	polyMesh = polyMesh || { normalized_uvs: true, positions: [], normals: [], uvs: [], polys: [] };

	const positionIndex = new Map();
	const uvIndex = new Map();
	const normalIndex = new Map();
	const exportedPositions = {};
	const faceNormals = {};
	const vertexFaces = new Map();

	for (const key in mesh.vertices) {
		const p = polyMeshExportPoint(mesh, mesh.vertices[key]);
		exportedPositions[key] = p;
		positionIndex.set(key, polyMesh.positions.length);
		polyMesh.positions.push(p.map(v => Math.abs(v) < 1e-8 ? 0 : v));
	}

	// Compute normals from the actually exported positions. This keeps normals
	// consistent with whichever GeckoMesh runtime coordinate convention is used.
	for (const faceKey in mesh.faces) {
		const face = mesh.faces[faceKey];
		const ordered = face.getSortedVertices ? face.getSortedVertices() : face.vertices;
		if (!ordered || ordered.length < 3) continue;
		const p0 = exportedPositions[ordered[0]], p1 = exportedPositions[ordered[1]], p2 = exportedPositions[ordered[2]];
		if (!p0 || !p1 || !p2) continue;
		const a = sub(p1, p0), b = sub(p2, p0);
		let n = norm(cross(a, b));
		if (!len(n)) n = [0, 1, 0];
		faceNormals[faceKey] = n;
		for (const v of ordered) {
			if (!vertexFaces.has(v)) vertexFaces.set(v, []);
			vertexFaces.get(v).push(faceKey);
		}
	}

	for (const key in mesh.vertices) {
		let sum = [0, 0, 0];
		for (const fk of vertexFaces.get(key) || []) sum = add(sum, faceNormals[fk] || [0, 0, 0]);
		let n = norm(sum);
		if (!len(n)) n = [0, 1, 0];
		const nk = n.map(v => Math.round(v * 1e6) / 1e6).join(',');
		let ni = normalIndex.get(nk);
		if (ni === undefined) {
			ni = polyMesh.normals.length;
			normalIndex.set(nk, ni);
			polyMesh.normals.push(n);
		}
		normalIndex.set(key, ni);
	}

	for (const faceKey in mesh.faces) {
		const face = mesh.faces[faceKey];
		const ordered = face.getSortedVertices ? face.getSortedVertices() : face.vertices;
		if (!ordered || ordered.length < 3) continue;
		const poly = [];
		for (const key of ordered.slice(0, 4)) {
			const raw = face.uv && face.uv[key] ? face.uv[key] : [0, 0];
			const uv = [
				Project.texture_width ? raw[0] / Project.texture_width : 0,
				Project.texture_height ? (Project.texture_height - raw[1]) / Project.texture_height : 0,
			];
			const uk = uv.map(v => Math.round(v * 1e7) / 1e7).join(',');
			let ui = uvIndex.get(uk);
			if (ui === undefined) {
				ui = polyMesh.uvs.length;
				uvIndex.set(uk, ui);
				polyMesh.uvs.push(uv);
			}
			poly.push([positionIndex.get(key), normalIndex.get(key), ui]);
		}
		// Bedrock accepts triangles and quads; preserve the source triangle instead
		// of inventing a fourth corner.
		if (poly.length >= 3) polyMesh.polys.push(poly);
	}
	return polyMesh;
}

// ------------------------------------------------------------- CS2 weighted skin preview
//
// GeckoLib projects use ordinary Group bones, not Blockbench Armature bones, so
// Blockbench cannot apply glTF JOINTS_0/WEIGHTS_0 by itself.  The runtime mod
// already performs true linear-blend skinning from GeckoLib's live bone poses;
// this preview mirrors the same idea inside Blockbench without modifying the
// actual Mesh vertices.  It writes only to the THREE preview geometry through
// Mesh.preview_controller.displayDeformation(), so export always uses the clean
// bind-pose source data.
let weightedSkinPreviewAnimationHandler = null;
let weightedSkinPreviewDefaultPoseHandler = null;

function weightedPreviewMeshes() {
	if (typeof Mesh === 'undefined') return [];
	return Mesh.all.filter(mesh => mesh && mesh.__cs2WeightedSource && mesh.__cs2WeightedPreviewEnabled !== false);
}

function prepareWeightedSkinPreview(mesh) {
	if (!mesh || !mesh.__cs2WeightedSource || !mesh.__cs2VertexSkin || typeof THREE === 'undefined') return false;
	const source = mesh.__cs2WeightedSource;
	const meshObject = mesh.scene_object || mesh.mesh;
	if (!meshObject || !meshObject.matrixWorld) return false;

	try {
		if (typeof Canvas !== 'undefined' && Canvas.scene && Canvas.scene.updateMatrixWorld) {
			Canvas.scene.updateMatrixWorld(true);
		} else if (meshObject.updateWorldMatrix) {
			meshObject.updateWorldMatrix(true, false);
		}

		const bindMeshWorld = new THREE.Matrix4().copy(meshObject.matrixWorld);
		const bindWorldPositions = {};
		for (const vkey in mesh.vertices) {
			bindWorldPositions[vkey] = new THREE.Vector3().fromArray(mesh.vertices[vkey]).applyMatrix4(bindMeshWorld);
		}

		const boneNodes = new Set();
		for (const vkey in mesh.__cs2VertexSkin) {
			for (const inf of mesh.__cs2VertexSkin[vkey] || []) {
				if (inf && inf.node !== undefined && Number(inf.weight) > 1e-8) boneNodes.add(inf.node);
			}
		}

		const bindBoneWorldInverse = new Map();
		const missingBones = [];
		for (const node of boneNodes) {
			const group = source.groupByNode && source.groupByNode[node];
			const boneObject = group && (group.scene_object || group.mesh);
			if (!boneObject || !boneObject.matrixWorld) {
				missingBones.push(node);
				continue;
			}
			if (boneObject.updateWorldMatrix) boneObject.updateWorldMatrix(true, false);
			bindBoneWorldInverse.set(node, new THREE.Matrix4().copy(boneObject.matrixWorld).invert());
		}

		source.preview = {
			bindMeshWorld,
			bindWorldPositions,
			bindBoneWorldInverse,
			boneNodes: [...boneNodes],
			missingBones,
		};
		return true;
	} catch (e) {
		console.warn('[geckolib-import] could not prepare weighted Blockbench preview for', mesh.name, e);
		return false;
	}
}

function prepareAllWeightedSkinPreviews() {
	let prepared = 0, vertices = 0, missing = 0;
	for (const mesh of weightedPreviewMeshes()) {
		if (prepareWeightedSkinPreview(mesh)) {
			prepared++;
			vertices += Object.keys(mesh.__cs2VertexSkin || {}).length;
			missing += mesh.__cs2WeightedSource.preview?.missingBones?.length || 0;
		}
	}
	return { prepared, vertices, missing };
}

function clearWeightedSkinPreview() {
	if (typeof Mesh === 'undefined' || !Mesh.preview_controller) return;
	for (const mesh of weightedPreviewMeshes()) {
		try {
			// Rebuild from element.vertices, which always remain the bind pose.
			Mesh.preview_controller.updateGeometry(mesh);
		} catch (e) { /* project may be closing/rebuilding */ }
	}
}

function updateWeightedSkinPreview() {
	if (typeof THREE === 'undefined' || typeof Mesh === 'undefined' || !Mesh.preview_controller) return;
	const meshes = weightedPreviewMeshes();
	if (!meshes.length) return;

	// Animator updates Group transforms before dispatching display_animation_frame.
	// Force the world matrices current once here so scrubbing, playback and
	// controller previews all use the exact pose visible this frame.
	try {
		if (typeof Canvas !== 'undefined' && Canvas.scene && Canvas.scene.updateMatrixWorld) Canvas.scene.updateMatrixWorld(true);
	} catch (e) { /* best effort */ }

	const tmpWorld = new THREE.Vector3();
	const blendedWorld = new THREE.Vector3();
	const local = new THREE.Vector3();
	const base = new THREE.Vector3();

	for (const mesh of meshes) {
		const source = mesh.__cs2WeightedSource;
		let preview = source && source.preview;
		if (!preview && !prepareWeightedSkinPreview(mesh)) continue;
		preview = source.preview;

		const meshObject = mesh.scene_object || mesh.mesh;
		if (!meshObject || !meshObject.matrixWorld) continue;
		const currentMeshWorldInverse = new THREE.Matrix4().copy(meshObject.matrixWorld).invert();

		// One skin matrix per influencing bone per frame.  This is the standard
		// currentGlobal * inverse(bindGlobal) matrix, expressed in THREE world space.
		const skinMatrices = new Map();
		for (const node of preview.boneNodes || []) {
			const group = source.groupByNode && source.groupByNode[node];
			const boneObject = group && (group.scene_object || group.mesh);
			const invBind = preview.bindBoneWorldInverse.get(node);
			if (!boneObject || !invBind) continue;
			skinMatrices.set(node, new THREE.Matrix4().multiplyMatrices(boneObject.matrixWorld, invBind));
		}

		const offsets = {};
		for (const vkey in mesh.vertices) {
			const original = mesh.vertices[vkey];
			const bindWorld = preview.bindWorldPositions[vkey];
			const influences = mesh.__cs2VertexSkin[vkey] || [];
			if (!bindWorld || !influences.length) continue;

			blendedWorld.set(0, 0, 0);
			let totalWeight = 0;
			for (const inf of influences) {
				const weight = Number(inf.weight) || 0;
				const skinMatrix = skinMatrices.get(inf.node);
				if (weight <= 1e-8 || !skinMatrix) continue;
				tmpWorld.copy(bindWorld).applyMatrix4(skinMatrix);
				blendedWorld.addScaledVector(tmpWorld, weight);
				totalWeight += weight;
			}
			if (totalWeight <= 1e-8) continue;
			if (Math.abs(totalWeight - 1) > 1e-6) blendedWorld.multiplyScalar(1 / totalWeight);

			local.copy(blendedWorld).applyMatrix4(currentMeshWorldInverse);
			base.fromArray(original);
			local.sub(base);
			offsets[vkey] = [local.x, local.y, local.z];
		}

		try {
			Mesh.preview_controller.displayDeformation(mesh, offsets);
		} catch (e) {
			console.warn('[geckolib-import] weighted preview update failed for', mesh.name, e);
		}
	}
}

function installWeightedSkinPreview() {
	if (typeof Blockbench === 'undefined' || !Blockbench.on || weightedSkinPreviewAnimationHandler) return;
	weightedSkinPreviewAnimationHandler = () => updateWeightedSkinPreview();
	weightedSkinPreviewDefaultPoseHandler = event => {
		// Animator.preview() resets the default pose with reduced_updates=true on
		// every frame, then immediately applies the animated pose. Avoid rebuilding
		// the full mesh in that hot path; displayDeformation overwrites all preview
		// positions a moment later. A real return to Edit/default pose clears it.
		if (!event || !event.reduced_updates) clearWeightedSkinPreview();
	};
	Blockbench.on('display_animation_frame', weightedSkinPreviewAnimationHandler);
	Blockbench.on('display_default_pose', weightedSkinPreviewDefaultPoseHandler);
}

function uninstallWeightedSkinPreview() {
	try {
		if (typeof Blockbench !== 'undefined' && Blockbench.removeListener) {
			if (weightedSkinPreviewAnimationHandler) Blockbench.removeListener('display_animation_frame', weightedSkinPreviewAnimationHandler);
			if (weightedSkinPreviewDefaultPoseHandler) Blockbench.removeListener('display_default_pose', weightedSkinPreviewDefaultPoseHandler);
		}
	} catch (e) { /* best effort */ }
	weightedSkinPreviewAnimationHandler = null;
	weightedSkinPreviewDefaultPoseHandler = null;
}

/**
 * Compile one glTF-skinned preview Mesh into CS2 Lootbox's weighted extension.
 *
 * The source triangles live in Blockbench model/pixel space (the same space as
 * the imported bones).  The runtime renderer consumes GeckoLib model units, so
 * positions are divided by 16 here.  UVs are stored already in the final
 * orientation expected by VertexConsumer (0..1, top-left Blockbench V).
 *
 * This data deliberately lives beside bone.poly_mesh instead of replacing
 * GeckoMesh. Rigid meshes still use GeckoMesh; only meshes tagged by the glTF
 * importer as weighted are emitted here.
 */
function compileWeightedSkinMesh(mesh) {
	const source = mesh && mesh.__cs2WeightedSource;
	if (!source || !Array.isArray(source.faces) || !source.faces.length) return null;

	const bones = [];
	const boneIndex = new Map();
	const boneNameForNode = node => {
		const group = source.groupByNode && source.groupByNode[node];
		if (group && group.name) return String(group.name);
		const h = source.hierarchyByNode && source.hierarchyByNode.get && source.hierarchyByNode.get(node);
		return h && h.name ? String(h.name) : `node_${node}`;
	};
	const indexForBone = node => {
		const name = boneNameForNode(node);
		let index = boneIndex.get(name);
		if (index === undefined) {
			index = bones.length;
			boneIndex.set(name, index);
			bones.push(name);
		}
		return index;
	};

	const positions = [], uvs = [], joints = [], weights = [], indices = [];
	const vertexIndex = new Map();
	const q = v => Math.round(Number(v || 0) * 1e7) / 1e7;

	const addVertex = (position, uv, influences) => {
		let inf = Array.isArray(influences) ? influences
			.filter(x => x && x.node !== undefined && Number(x.weight) > 1e-8)
			.map(x => ({ node: x.node, weight: Number(x.weight) }))
			.sort((a, b) => b.weight - a.weight)
			.slice(0, 4) : [];
		let sum = inf.reduce((v, x) => v + x.weight, 0);
		if (sum > 1e-8) inf = inf.map(x => ({ node: x.node, weight: x.weight / sum }));

		const jointSlots = [0, 0, 0, 0];
		const weightSlots = [0, 0, 0, 0];
		for (let i = 0; i < inf.length; i++) {
			jointSlots[i] = indexForBone(inf[i].node);
			weightSlots[i] = inf[i].weight;
		}

		// No valid skin influence should not happen on a weighted primitive, but
		// falling back to the mesh's parent bone is safer than dropping a vertex.
		if (!inf.length) {
			const parentName = mesh.parent && mesh.parent.name ? String(mesh.parent.name) : '';
			let bi = boneIndex.get(parentName);
			if (bi === undefined) { bi = bones.length; boneIndex.set(parentName, bi); bones.push(parentName); }
			jointSlots[0] = bi;
			weightSlots[0] = 1;
		}

		const px = q(position && position[0]) / 16;
		const py = q(position && position[1]) / 16;
		const pz = q(position && position[2]) / 16;
		const tu = Project.texture_width ? q(uv && uv[0]) / Project.texture_width : 0;
		const tv = Project.texture_height ? q(uv && uv[1]) / Project.texture_height : 0;
		const key = [q(px), q(py), q(pz), q(tu), q(tv), ...jointSlots, ...weightSlots.map(q)].join('|');
		let vi = vertexIndex.get(key);
		if (vi !== undefined) return vi;

		vi = positions.length / 3;
		vertexIndex.set(key, vi);
		positions.push(px, py, pz);
		uvs.push(tu, tv);
		joints.push(...jointSlots);
		weights.push(...weightSlots.map(q));
		return vi;
	};

	for (const face of source.faces) {
		if (!face.positions || face.positions.length < 3) continue;
		const corner = [];
		for (let i = 0; i < 3; i++) {
			corner.push(addVertex(
				face.positions[i],
				(face.uvs && face.uvs[i]) || [0, 0],
				(face.skinVertices && face.skinVertices[i]) || []
			));
		}
		if (new Set(corner).size < 3) continue;
		// GeckoMesh reverses poly_mesh winding while converting coordinates. Match
		// that final winding so weighted and rigid meshes cull identically in-game.
		indices.push(corner[0], corner[2], corner[1]);
	}

	if (!indices.length || !bones.length) return null;
	return {
		name: String(mesh.name || 'weighted_mesh'),
		bones,
		positions,
		uvs,
		joints,
		weights,
		indices,
	};
}

let polyMeshCompileHandler = null;
let geckoMeshesPreviousValue;

// Runtime coordinate convention for exported bone.poly_mesh.
// GeckoMesh 1.1+ is the default and negates X in PolyMeshConverter. The old
// 1.0 CurseMaven converter keeps X unchanged, so it remains selectable for
// legacy projects.
let polyMeshGeckoMeshRuntime = '1_1_plus';

/** Allow Mesh elements inside GeckoLib projects while this plugin is active. */
function enableGeckoMeshEditing() {
	try {
		const f = typeof Formats !== 'undefined' && Formats.geckolib_model;
		if (!f) return;
		if (geckoMeshesPreviousValue === undefined) geckoMeshesPreviousValue = f.meshes;
		f.meshes = true;
	} catch (e) {
		console.warn('[geckolib-import] could not enable mesh editing', e);
	}
}

/**
 * Inject ordinary Mesh elements as bone.poly_mesh and weighted glTF meshes as
 * geometry.cs2_skinning.  GeckoLib ignores the custom geometry field, while
 * CS2 Lootbox reads it after GeckoLib has evaluated the animation pose.
 */
function installPolyMeshExporter() {
	if (polyMeshCompileHandler || typeof Codecs === 'undefined' || !Codecs.bedrock || !Codecs.bedrock.on) return;
	polyMeshCompileHandler = function geckolibImporterPolyMeshCompile(event) {
		try {
			if (typeof Format === 'undefined' || !Format || Format.id !== 'geckolib_model') return;
			let geometry = event && event.model;
			if (geometry && geometry['minecraft:geometry']) geometry = geometry['minecraft:geometry'][0];
			if (!geometry || !Array.isArray(geometry.bones) || typeof Group === 'undefined' || typeof Mesh === 'undefined') return;

			const weighted = [];
			for (const group of Group.all) {
				const meshes = (group.children || []).filter(child => child instanceof Mesh && child.export !== false);
				if (!meshes.length) continue;
				const bone = geometry.bones.find(b => b.name === group.name);
				if (!bone) continue;

				let poly = null;
				for (const mesh of meshes) {
					if (mesh.__cs2WeightedSource) {
						const skin = compileWeightedSkinMesh(mesh);
						if (skin) weighted.push(skin);
					} else {
						poly = compileBlockbenchMeshIntoPolyMesh(poly, mesh);
					}
				}
				if (poly && poly.polys.length) bone.poly_mesh = poly;
			}

			if (weighted.length) {
				geometry.cs2_skinning = {
					format_version: 1,
					space: 'geckolib_model_units',
					max_influences: 4,
					meshes: weighted,
				};
			} else if (geometry.cs2_skinning) {
				delete geometry.cs2_skinning;
			}
		} catch (e) {
			console.error('[geckolib-import] poly_mesh / weighted skin export failed', e);
		}
	};
	Codecs.bedrock.on('compile', polyMeshCompileHandler);
}

function uninstallPolyMeshExporter() {
	try {
		const codec = typeof Codecs !== 'undefined' && Codecs.bedrock;
		if (codec && polyMeshCompileHandler) {
			if (typeof codec.removeListener === 'function') codec.removeListener('compile', polyMeshCompileHandler);
			else if (codec.events && Array.isArray(codec.events.compile)) {
				const i = codec.events.compile.indexOf(polyMeshCompileHandler);
				if (i >= 0) codec.events.compile.splice(i, 1);
			}
		}
	} catch (e) { /* best effort */ }
	polyMeshCompileHandler = null;
	try {
		const f = typeof Formats !== 'undefined' && Formats.geckolib_model;
		if (f && geckoMeshesPreviousValue !== undefined) f.meshes = geckoMeshesPreviousValue;
	} catch (e) { /* best effort */ }
	geckoMeshesPreviousValue = undefined;
}

/**
 * Builds a Cube from a solveBox result. Shared by both paths: converting meshes
 * in an open project, and importing from a ZIP.
 */
function cubeFromSolution(name, sol, textureUUID, inflate) {
	const m = new THREE.Matrix4().makeBasis(
		new THREE.Vector3(...sol.vx),
		new THREE.Vector3(...sol.vy),
		new THREE.Vector3(...sol.vz)
	);
	const e = new THREE.Euler().setFromRotationMatrix(m, EULER_ORDER);

	// Only UNROTATED cubes may be snapped to the grid.
	//
	// A rotated cube's vertex sits at origin + R·(p - origin), so an origin
	// snapped separately from from/to drags the whole geometry along: on real
	// models vertices moved by up to 0.46 px and rectangular details turned
	// skewed. For an unrotated cube R = I, origin drops out of the formula and
	// does not affect placement at all — snapping is safe there.
	//
	// Rotated ones keep exact values with only the noise cleared: a cube at 37°
	// will not sit on a 0.25 grid anyway.
	const place = placeCoords(sol);

	const half = mul(sol.size, 0.5);
	const from = place(sub(sol.center, half));
	const to = place(add(sol.center, half));
	const cube = new Cube({
		name,
		from,
		to,
		origin: place(sol.center),
		rotation: [
			snapAngle(THREE.MathUtils.radToDeg(e.x)),
			snapAngle(THREE.MathUtils.radToDeg(e.y)),
			snapAngle(THREE.MathUtils.radToDeg(e.z)),
		],
		box_uv: false,
		autouv: 0,
		// A hair of inflation against flicker on coincident faces. Zero is not
		// written, to keep the field clean on cubes that do not need it.
		inflate: inflate || 0,
	});

	// A flat cube has four side faces of zero area: invisible, though they do
	// carry UV. Inflation gives them thickness and they show up as a band of
	// stretched pixel: the outline that was never there before. So degenerate
	// faces are hidden whenever a cube is inflated.
	const degenerate = {};
	if (inflate) {
		const AXIS_FACES = [['east', 'west'], ['up', 'down'], ['north', 'south']];
		for (let i = 0; i < 3; i++) {
			// The FINAL thickness is used, not the original: snapping collapses
			// details thinner than 0.125 px to zero, and by their original size they
			// would not count as flat yet.
			if (Math.abs(to[i] - from[i]) >= FLAT_LIMIT) continue;
			for (let j = 0; j < 3; j++) {
				if (j === i) continue;
				for (const f of AXIS_FACES[j]) degenerate[f] = true;
			}
		}
	}

	for (const fname of FACE_NAMES) {
		const cf = cube.faces[fname];
		if (sol.faceUV[fname] && !degenerate[fname]) {
			cf.uv = sol.faceUV[fname];
			if (textureUUID) cf.texture = textureUUID;
		} else {
			cf.texture = null;   // the face was absent in the source, or is degenerate
		}
	}
	return cube;
}

function convertMesh(mesh, opts) {
	const faces = meshToFaces(mesh);
	const sol = solveBox(faces, opts);
	if (sol.error) return { error: sol.error };

	const texture = faces.find(f => f.texture)?.texture
		|| (Texture.all.length ? Texture.all[0].uuid : null);
	const cube = cubeFromSolution(mesh.name, sol, texture);

	return {
		cube, basis: [sol.vx, sol.vy, sol.vz],
		emptyFaces: sol.emptyFaces, violations: sol.violations, mirrored: sol.mirrored,
	};
}

/**
 * How far the cube's actual orientation drifted from the intended one, in degrees.
 *
 * We set the rotation with Euler angles, and Blockbench builds a matrix from
 * them in its own axis order. If the order or a sign disagrees the cube ends up
 * wrong, and that is measured here instead of trusting a guessed EULER_ORDER.
 */
function rotationError(cube, basis) {
	try {
		const e = cube.mesh && cube.mesh.rotation;
		if (!e) return null;
		let worst = 0;
		[[1, 0, 0], [0, 1, 0], [0, 0, 1]].forEach((axis, i) => {
			const got = new THREE.Vector3(...axis).applyEuler(e);
			const want = basis[i];
			const cos = Math.min(1, Math.max(-1, got.x * want[0] + got.y * want[1] + got.z * want[2]));
			worst = Math.max(worst, Math.acos(cos) * 180 / Math.PI);
		});
		return worst;
	} catch (err) {
		return null;
	}
}

// ------------------------------------------------------------- action

function runConversion(options) {
	const meshes = Mesh.all.filter(m => !options.selected_only || m.selected);
	if (!meshes.length) {
		Blockbench.showQuickMessage('No meshes found', 2000);
		return;
	}
	if (Project && Project.box_uv) {
		Blockbench.showMessageBox({
			title: 'Box UV is enabled',
			message: 'This project uses Box UV, but the converter assigns UV per face.\n' +
				'Turn Box UV off in the project settings and run again.',
		});
		return;
	}

	detectEulerOrder();
	const calibration = calibrateFaceDirs();
	console.log('[geckolib-import] ' + calibration);

	Undo.initEdit({ elements: meshes, outliner: true, selection: true });

	const created = [], failed = [], rotated = [], mirrors = [], badRotation = [];
	let hiddenFaces = 0;
	const opts = { mirror: options.mirror_mode !== 'off' };

	for (const mesh of meshes) {
		let r;
		try { r = convertMesh(mesh, opts); }
		catch (err) { r = { error: String((err && err.message) || err) }; }

		if (r.error) { failed.push(`${mesh.name}: ${r.error}`); continue; }

		r.cube.addTo(mesh.parent);
		r.cube.init();
		created.push(r.cube);
		hiddenFaces += r.emptyFaces.length;
		if (r.violations) rotated.push(`${mesh.name}: ${r.violations} UV mismatches`);
		if (r.mirrored) mirrors.push(`${mesh.name} (${r.mirrored})`);

		const err = rotationError(r.cube, r.basis);
		if (err !== null && err > 0.5) badRotation.push(`${mesh.name}: ${err.toFixed(1)}°`);
	}

	// source meshes are removed only if everything converted
	if (options.delete_meshes && !failed.length) {
		for (const mesh of meshes) mesh.remove();
	}

	Undo.finishEdit('Convert meshes to cubes', { elements: created, outliner: true });
	Canvas.updateAll();

	const lines = [
		`Meshes processed: ${meshes.length}`,
		`Cubes created: ${created.length}`,
		`Not converted: ${failed.length}`,
		`Faces hidden (absent in the source): ${hiddenFaces}`,
		`Mirrored UV: ${opts.mirror ? 'as in source' : 'disabled'}`,
		`Mirrored cubes: ${mirrors.length}`,
		`Euler angle order: ${EULER_ORDER}`,
		`Cubes with a wrong rotation: ${badRotation.length}`,
		'',
		calibration,
	];
	if (badRotation.length) {
		lines.push('', 'ROTATION MISMATCH (wrong Euler angle order):',
			...badRotation.slice(0, 10));
		if (badRotation.length > 10) lines.push(`…and ${badRotation.length - 10} more`);
	}
	if (mirrors.length) {
		lines.push('', 'Mirrored: ' + mirrors.join(', '));
	}
	if (failed.length) {
		lines.push('', 'Failed:', ...failed.slice(0, 20));
		if (failed.length > 20) lines.push(`…and ${failed.length - 20} more`);
		if (options.delete_meshes) lines.push('', 'Source meshes were kept — there were errors.');
	}
	if (rotated.length) {
		lines.push('', 'The texture may be rotated:', ...rotated.slice(0, 10));
	}
	console.log('[geckolib-import]\n' + lines.join('\n'));
	Blockbench.showMessageBox({ title: 'Mesh → Cubes', message: lines.join('\n') });
}

// --------------------------------------------------------- import from ZIP

/**
 * Image size straight from the header — needed before the texture exists,
 * because it defines the project's UV space.
 *
 * Understands PNG, JPEG, GIF and WebP. PNG alone is not enough: on Sketchfab
 * textures are usually JPEG, and while only PNG was parsed such archives failed
 * with texture not found — even though the image was right there.
 */
function imageSize(bytes) {
	if (!bytes || bytes.length < 24) return null;
	const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);

	// PNG: signature, then IHDR with width and height straight away.
	if (dv.getUint32(0) === 0x89504E47) return { width: dv.getUint32(16), height: dv.getUint32(20) };

	// GIF: 'GIF8', size lives in the logical screen descriptor, little-endian.
	if (dv.getUint32(0) === 0x47494638) return { width: dv.getUint16(6, true), height: dv.getUint16(8, true) };

	// WebP: 'RIFF'...'WEBP', then three sub-formats with different layouts.
	if (dv.getUint32(0) === 0x52494646 && dv.getUint32(8) === 0x57454250) {
		const tag = dv.getUint32(12);
		if (tag === 0x56503820 && bytes.length > 30) {          // 'VP8 ' — lossy
			return { width: dv.getUint16(26, true) & 0x3FFF, height: dv.getUint16(28, true) & 0x3FFF };
		}
		if (tag === 0x5650384C && bytes.length > 25) {          // 'VP8L' — lossless
			const b = dv.getUint32(21, true);
			return { width: (b & 0x3FFF) + 1, height: ((b >> 14) & 0x3FFF) + 1 };
		}
		if (tag === 0x56503858 && bytes.length > 30) {          // 'VP8X' extended
			return {
				width: (bytes[24] | (bytes[25] << 8) | (bytes[26] << 16)) + 1,
				height: (bytes[27] | (bytes[28] << 8) | (bytes[29] << 16)) + 1,
			};
		}
		return null;
	}

	// JPEG: walk the markers until SOFn, which holds the dimensions. Segments
	// must be skipped by their length, otherwise it is easy to hit payload bytes
	// that happen to look like a marker.
	if (dv.getUint16(0) === 0xFFD8) {
		let p = 2;
		while (p + 9 < bytes.length) {
			if (bytes[p] !== 0xFF) { p++; continue; }
			const marker = bytes[p + 1];
			if (marker === 0xFF || marker === 0x01 || (marker >= 0xD0 && marker <= 0xD9)) { p += 2; continue; }
			const len = dv.getUint16(p + 2);
			// SOFn (except DHT/JPG/DAC — 0xC4, 0xC8, 0xCC) carry the frame size.
			if (marker >= 0xC0 && marker <= 0xCF && marker !== 0xC4 && marker !== 0xC8 && marker !== 0xCC) {
				return { width: dv.getUint16(p + 7), height: dv.getUint16(p + 5) };
			}
			if (len < 2) return null;
			p += 2 + len;
		}
	}
	return null;
}

/** The old name is kept: tests and external callers use it. */
const pngSize = imageSize;

/** Image type from its first bytes: the archive extension cannot be trusted. */
function sniffMime(bytes) {
	if (!bytes || bytes.length < 12) return 'image/png';
	const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
	if (dv.getUint32(0) === 0x89504E47) return 'image/png';
	if (dv.getUint16(0) === 0xFFD8) return 'image/jpeg';
	if (dv.getUint32(0) === 0x47494638) return 'image/gif';
	if (dv.getUint32(0) === 0x52494646 && dv.getUint32(8) === 0x57454250) return 'image/webp';
	return 'image/png';
}

function bytesToBase64(bytes) {
	let bin = '';
	const step = 0x8000;   // in chunks, or a large array blows the stack
	for (let i = 0; i < bytes.length; i += step) {
		bin += String.fromCharCode.apply(null, bytes.subarray(i, i + step));
	}
	return btoa(bin);
}

/**
 * Axis order for a BONE rotation. For a cube it is already measured (ZYX), but
 * a group may differ, so it is measured separately, the same way.
 */
let BONE_EULER_ORDER = 'ZYX';
let BONE_ROT_SIGN = [1, 1, 1];

/**
 * Measures how Blockbench turns a bone angle into a real rotation: axis order
 * and per-axis sign. Bone signs can well differ from cube ones — assuming them
 * blindly was tried already and cost several rounds.
 */
function calibrateBoneRotation() {
	let probe = null;
	try {
		probe = new Group({ name: '__probe_rot__' }).init();
		const refresh = () => {
			if (Canvas.updateAllBones) Canvas.updateAllBones([probe]);
			else if (Canvas.updateView) Canvas.updateView({ groups: [probe] });
			else Canvas.updateAll();
		};

		probe.rotation = [10, 20, 30];
		refresh();
		if (!probe.mesh || !probe.mesh.rotation) throw new Error('group has no mesh.rotation');
		BONE_EULER_ORDER = probe.mesh.rotation.order || BONE_EULER_ORDER;

		const signs = [1, 1, 1];
		for (let a = 0; a < 3; a++) {
			const rot = [0, 0, 0];
			rot[a] = 30;
			probe.rotation = rot;
			refresh();
			const got = [probe.mesh.rotation.x, probe.mesh.rotation.y, probe.mesh.rotation.z][a];
			signs[a] = got < 0 ? -1 : 1;
		}
		BONE_ROT_SIGN = signs;
		return `Bone rotations measured: order ${BONE_EULER_ORDER}, signs [${signs.join(', ')}]`;
	} catch (e) {
		return `Could not measure bone rotations (${(e && e.message) || e}), using ${BONE_EULER_ORDER} with signs [1, 1, 1]`;
	} finally {
		if (probe) { try { probe.remove(); } catch (e) { /* already gone */ } }
	}
}

/**
 * Measures which frame Blockbench applies a bone offset in.
 *
 * No more guessing: a probe offset is set along each axis, the frame is played,
 * and we look where the bone actually went. That yields a matrix M for which
 * actual offset = M · (written value). Inverting it is then enough to write
 * the value we want.
 *
 * If measuring fails (the API is missing) null is returned and we fall back to
 * the mode chosen in the dialog.
 */
function probeBonePositionFrame(groupByNode, parsed, report) {
	const unitScale = Number(parsed && parsed.unitScale) || 16;
	let anim = null;
	try {
		// Pick the bone with the LARGEST rest pose: only there is it visible whether
		// the mere presence of a keyframe moves the bone. A previous probe took a
		// bone with a zero rest pose and therefore could not notice this.
		const animated = new Set();
		for (const a of parsed.animations) for (const c of a.channels) animated.add(c.node);
		let target = null, best = -1;
		for (const h of parsed.hierarchy) {
			if (!groupByNode[h.index] || h.parent < 0 || !animated.has(h.index)) continue;
			const restLen = Math.hypot(h.rest.translation[0], h.rest.translation[1], h.rest.translation[2]) * unitScale;
			// A bone with a ROTATED parent is more valuable: only there is the
			// difference between local and model modes visible. A previous probe took
			// a bone with an identity parent and could not tell the modes apart.
			const score = restLen * (Math.abs(h.parentQuat[3]) < 0.999 ? 100 : 1);
			if (score > best) { best = score; target = h; }
		}
		if (!target) { report.push('Offset probe: no suitable bone found'); return null; }
		const group = groupByNode[target.index];

		const worldOf = g => {
			if (!g.mesh || !g.mesh.getWorldPosition) return null;
			if (g.mesh.updateWorldMatrix) g.mesh.updateWorldMatrix(true, false);
			const v = new THREE.Vector3();
			g.mesh.getWorldPosition(v);
			return [v.x, v.y, v.z];
		};

		anim = new Animation({ name: '__probe_pos__', loop: 'hold', length: 0.1 }).add();
		if (anim.select) anim.select();
		const animator = anim.getBoneAnimator(group);
		if (!animator) { report.push('Offset probe: no animator'); return null; }

		const play = t => {
			if (typeof Timeline !== 'undefined' && Timeline.setTime) Timeline.setTime(t);
			if (typeof Animator !== 'undefined' && Animator.preview) Animator.preview();
		};

		play(0);
		const rest = worldOf(group);
		if (!rest) { report.push('Offset probe: cannot read the bone world position'); return null; }

		const measure = (x, y, z) => {
			animator.position = [];
			animator.createKeyframe({ x, y, z }, 0, 'position', false, false);
			play(0);
			const now = worldOf(group);
			return [now[0] - rest[0], now[1] - rest[1], now[2] - rest[2]];
		};

		// THE key measurement: a keyframe holding zero. If the bone moves, the value
		// replaces the rest pose rather than adding to it.
		const snap = measure(0, 0, 0);
		const snapLen = Math.hypot(snap[0], snap[1], snap[2]);

		const cols = [measure(10, 0, 0), measure(0, 10, 0), measure(0, 0, 10)]
			.map(d => d.map((v, i) => (v - snap[i]) / 10));

		const fmt = c => '[' + c.map(v => v.toFixed(2)).join(', ') + ']';
		const targetRest = Math.hypot(target.rest.translation[0], target.rest.translation[1], target.rest.translation[2]) * unitScale;
		const targetRotated = Math.abs(target.parentQuat[3]) < 0.999;
		report.push(`Offset probe: bone “${target.name}”, rest pose ${targetRest.toFixed(1)} px,`
			+ ` parent ${targetRotated ? 'is rotated' : 'is not rotated'}`);
		report.push(`  a ZERO keyframe moves the bone by ${snapLen.toFixed(2)} px ${fmt(snap)}`);
		report.push(`  response: X→${fmt(cols[0])} Y→${fmt(cols[1])} Z→${fmt(cols[2])}`);

		// A zero response means the preview did not recompute, not that the bone
		// stayed put. Telling these apart is essential: otherwise an empty
		// measurement would masquerade as a meaningful conclusion.
		const moved = cols.some(c => c.some(v => Math.abs(v) > 0.01));
		if (!moved) {
			report.push('  the preview did not update — the probe measured nothing, mode comes from the dialog');
			return null;
		}
		report.push(snapLen > 0.5
			? `  CONCLUSION: the value REPLACES the bone offset — absolute values needed (${snapLen.toFixed(1)} px off)`
			: '  CONCLUSION: the value is ADDED to the rest pose — write offsets');
		return { cols, snap };
	} catch (e) {
		report.push(`Offset probe failed: ${(e && e.message) || e}`);
		return null;
	} finally {
		try {
			if (anim && anim.remove) anim.remove();
			else if (anim) {
				const i = Animation.all.indexOf(anim);
				if (i >= 0) Animation.all.splice(i, 1);
			}
		} catch (e) { /* not critical */ }
	}
}

/**
 * Measures the angle convention INSIDE ANIMATION KEYFRAMES.
 *
 * Until now signs were measured on a static group rotation, but
 * Bedrock-compatible formats use a different angle convention in animations
 * than in the model, and that was the last unverified spot.
 *
 * A keyframe rotating about a single axis is set on a bone, applied via
 * displayFrame(), and we look where the bone actually turned.
 */
function calibrateAnimRotation(groupByNode, parsed, report) {
	let anim = null;
	try {
		const h = parsed.hierarchy.find(x => groupByNode[x.index] && x.parent >= 0);
		if (!h) { report.push('Animation angle probe: no suitable bone'); return; }
		const group = groupByNode[h.index];

		anim = new Animation({ name: '__probe_rot__', loop: 'hold', length: 0.1 }).add();
		if (anim.select) anim.select();
		const animator = anim.getBoneAnimator(group);
		if (!animator) { report.push('Animation angle probe: no animator'); return; }

		const signs = [1, 1, 1];
		let measured = 0;
		for (let a = 0; a < 3; a++) {
			const data = { x: 0, y: 0, z: 0 };
			data[['x', 'y', 'z'][a]] = 30;
			animator.rotation = [];
			animator.createKeyframe(data, 0, 'rotation', false, false);
			if (typeof Timeline !== 'undefined' && Timeline.setTime) Timeline.setTime(0);
			try { if (animator.displayFrame) animator.displayFrame(); } catch (e) { /* handled below */ }
			const r = group.mesh && group.mesh.rotation;
			if (!r) continue;
			const got = [r.x, r.y, r.z][a];
			if (Math.abs(got) > 1e-4) { signs[a] = got < 0 ? -1 : 1; measured++; }
		}
		if (measured === 3) {
			BONE_ROT_SIGN = signs;
			report.push(`Animation angles measured: signs [${signs.join(', ')}]`);
		} else {
			report.push(`Animation angle probe: measured ${measured} of 3 axes, signs left as [${BONE_ROT_SIGN.join(', ')}]`);
		}
	} catch (e) {
		report.push(`Animation angle probe failed: ${(e && e.message) || e}`);
	} finally {
		try {
			if (anim && anim.remove) anim.remove();
			else if (anim) { const i = Animation.all.indexOf(anim); if (i >= 0) Animation.all.splice(i, 1); }
		} catch (e) { /* not critical */ }
	}
}

/**
 * Compares where bones actually stand in Blockbench with where the glTF data
 * says they must be.
 *
 * This is the measurement that was missing all along: keyframe values can each
 * be checked individually and found correct, and the model will still drift
 * apart. Here the end result is compared, so an error shows up as a miss
 * vector: a swapped axis, a wrong sign or a stray factor can all be read
 * straight off it.
 */
function verifyAnimationPose(parsed, groupByNode, report) {
	const unitScale = Number(parsed && parsed.unitScale) || 16;
	try {
		const anim = Animation.all.find(a => a.name && parsed.animations.some(x => x.name === a.name
			&& x.channels.some(c => c.path === 'translation')));
		if (!anim) { report.push('Pose check: no animation with position channels found'); return; }
		const src = parsed.animations.find(x => x.name === anim.name);

		// Only animate mode computes the pose: in edit mode Animator.preview()
		// recomputes nothing and the measurement returns the rest pose.
		let restored = false;
		if (typeof Modes !== 'undefined' && Modes.options && Modes.options.animate) {
			Modes.options.animate.select();
			restored = true;
		}
		if (anim.select) anim.select();
		if (typeof Timeline !== 'undefined' && Timeline.setTime) Timeline.setTime(0);
		if (typeof Animator !== 'undefined' && Animator.preview) Animator.preview();

		// Animator.preview() recomputed the pose in neither mode, so each animator
		// is asked to apply the frame directly. We also watch whether anything
		// changed at all, or the measurement returns the rest pose and lies again.
		let applied = 0;
		for (const key in anim.animators) {
			const an = anim.animators[key];
			try {
				if (an.displayFrame) { an.displayFrame(); applied++; }
				else if (an.displayPosition && an.displayRotation) { an.displayRotation(); an.displayPosition(); applied++; }
			} catch (e) { /* try the rest */ }
		}
		report.push(`  animators applied directly: ${applied}`);
		if (typeof Canvas !== 'undefined' && Canvas.updateAllBones) Canvas.updateAllBones();

		// glTF pose at t=0: first keyframe for animated nodes, rest pose for others
		const at0 = {};
		for (const c of src.channels) {
			if (!c.values.length) continue;
			(at0[c.node] = at0[c.node] || {})[c.path] = c.values[0];
		}
		const byIdx = {};
		for (const h of parsed.hierarchy) byIdx[h.index] = h;

		const worldOf = index => {
			const chain = [];
			for (let h = byIdx[index]; h; h = h.parent >= 0 ? byIdx[h.parent] : null) chain.unshift(h);
			let m = matIdentity();
			for (const h of chain) {
				const o = at0[h.index] || {};
				m = matMul(m, matFromTRS(
					o.translation || h.rest.translation,
					o.rotation || h.rest.rotation,
					h.rest.scale));
			}
			return matApply(m, [0, 0, 0]).map(v => v * unitScale);
		};

		// Walk EVERY animated bone and sort by depth: an ancestor's error drags its
		// whole subtree along, so it matters where the divergence appears FIRST,
		// rather than admiring its consequences on the leaves.
		const depthOf = h => { let d = 0; for (let c = h; c && c.parent >= 0; c = byIdx[c.parent]) d++; return d; };
		const animatedNodes = [...new Set(src.channels.map(c => c.node))];
		const rows = [];
		for (const index of animatedNodes) {
			const h = byIdx[index], g = groupByNode[index];
			if (!h || !g || !g.mesh || !g.mesh.getWorldPosition) continue;
			if (g.mesh.updateWorldMatrix) g.mesh.updateWorldMatrix(true, false);
			const v = new THREE.Vector3();
			g.mesh.getWorldPosition(v);
			const want = worldOf(index);
			const err = [v.x - want[0], v.y - want[1], v.z - want[2]];
			rows.push({ name: h.name, index, depth: depthOf(h), err, got: [v.x, v.y, v.z], len: Math.hypot(err[0], err[1], err[2]) });
		}
		rows.sort((a, b) => a.depth - b.depth || b.len - a.len);

		report.push(`Pose check for ${anim.name} at t=0 (by depth):`);
		for (const r of rows.slice(0, 8)) {
			report.push(`  [${r.depth}] ${r.name}: off by ${r.len.toFixed(2)} px`
				+ ` (${r.err.map(n => n.toFixed(2)).join(', ')})`);
		}
		// A self-check: if every bone sits exactly in its rest pose, the animation
		// had NOT been applied by the time of reading, and the misses are merely
		// the gap between rest and target pose. Such a measurement is useless and
		// must not be passed off as a result.
		const atRest = rows.every(r => {
			const h = byIdx[r.index];
			return h && Math.hypot(r.got[0] - h.pivot[0], r.got[1] - h.pivot[1], r.got[2] - h.pivot[2]) < 0.05;
		});
		if (atRest && rows.length) {
			report.push('  WARNING: every bone sits in its rest pose — the animation had not been applied');
			report.push('  by the time of measurement, so the numbers above mean nothing');
		} else {
			const firstBad = rows.find(r => r.len > 0.5);
			report.push(firstBad
				? `  FIRST diverging bone: ${firstBad.name} at depth ${firstBad.depth}, off by ${firstBad.len.toFixed(2)} px`
				: '  every animated bone is in place');
		}
		if (restored && Modes.options.edit) Modes.options.edit.select();
		if (!rows.length) report.push('  could not read bone positions');
	} catch (e) {
		report.push(`Pose check failed: ${(e && e.message) || e}`);
	}
}

/**
 * Chooses the Blockbench/GeckoLib loop mode for an imported glTF animation.
 *
 * glTF animation clips do not carry a "loop" flag, so blindly treating every
 * non-zero-length clip as looping makes one-shot actions such as `open`,
 * `click`, `fall`, `reload`, etc. restart forever in GeckoLib.  Auto mode is
 * deliberately conservative: known cyclic names loop; everything else plays
 * once. Static poses are held regardless of this setting.
 */
function importedAnimationLoopMode(animationName, isPose, opts) {
	if (isPose) return 'hold';

	const mode = (opts && opts.animation_loop_mode) || 'auto';
	if (mode === 'loop') return 'loop';
	if (mode === 'once') return 'once';

	const name = String(animationName || '').toLowerCase();
	const cyclic = /(^|[._\-\s])(idle|loop|walk|walking|run|running|cycle|breath|breathing|hover|swim|swimming|fly|flying|spin|spinning)([._\-\s]|$)/;
	return cyclic.test(name) ? 'loop' : 'once';
}

/** Keep Euler angles on the representation nearest to the previous keyframe. */
function continuousAngle(value, previous) {
	if (!Number.isFinite(previous)) return value;
	while (value - previous > 180) value -= 360;
	while (value - previous < -180) value += 360;
	return value;
}

/**
 * Dense sampling is needed because glTF rotation LINEAR means quaternion
 * spherical interpolation, while Blockbench/GeckoLib keyframes interpolate
 * Euler components. Converting only the sparse source keys can therefore take
 * a visibly different arc between the same endpoints.
 */
function animationAccuracyPreset(opts) {
	const preset = opts && opts.animation_accuracy_preset !== undefined
		? String(opts.animation_accuracy_preset)
		: '';
	if (preset) return preset;
	// Backward compatibility with the older select that stored the fps directly.
	const old = opts && opts.animation_sample_fps !== undefined ? String(opts.animation_sample_fps) : '';
	if (old === '0') return 'original';
	if (old === '30') return 'balanced';
	if (old === '60') return 'high';
	if (old === '120') return 'ultra';
	if (old === '240') return 'exact';
	return 'high';
}

function animationAccuracyConfig(opts) {
	const preset = animationAccuracyPreset(opts);
	if (preset === 'original') {
		return { preset, fps: 0, zeroEps: 1e-4, round: 1e4, label: 'Original glTF key times only' };
	}
	if (preset === 'balanced') {
		return { preset, fps: 30, zeroEps: 1e-5, round: 1e4, label: 'Balanced — 30 FPS bake' };
	}
	if (preset === 'ultra') {
		return { preset, fps: 120, zeroEps: 1e-7, round: 1e5, label: 'Ultra — 120 FPS bake' };
	}
	if (preset === 'exact') {
		return { preset, fps: 240, zeroEps: 1e-8, round: 1e6, label: 'Exact — 240 FPS bake, minimal rounding' };
	}
	return { preset: 'high', fps: 60, zeroEps: 1e-6, round: 1e5, label: 'High — 60 FPS bake' };
}

function animationSampleTimes(animation, channels, fps) {
	const set = new Set();
	for (const ch of channels) for (const t of ch.times || []) set.add(+Number(t).toFixed(6));
	if (fps > 0 && animation.length > 0) {
		const step = 1 / fps;
		const count = Math.ceil(animation.length * fps);
		for (let i = 0; i <= count; i++) {
			const t = Math.min(animation.length, i * step);
			set.add(+t.toFixed(6));
		}
		set.add(+animation.length.toFixed(6));
	}
	return [...set].sort((a, b) => a - b);
}

/**
 * Transfers glTF animations onto Blockbench bones.
 *
 * The main subtlety: a glTF channel holds the node's ABSOLUTE pose, while
 * Blockbench stores an OFFSET from the rest pose. In the reference model 88 of
 * 142 nodes have a non-identity rest pose, so values cannot be taken as they
 * are: rotation becomes R(t)·R0⁻¹ and translation T(t)-T0.
 */
function applyAnimations(parsed, groupByNode, report, opts) {
	if (!parsed.animations.length) return;
	// Keep animation translation in the exact same unit scale as the imported
	// geometry. Auto-scale is often x1/x2/x4 for game glTF assets; the previous
	// hard-coded x16 made animated child meshes (locks, lids, latches, keys...)
	// fly away from their correct bind position even though the static mesh was fine.
	const unitScale = Number(parsed && parsed.unitScale) || 16;
	if (opts && opts.animations === false) {
		report.push(`Animations skipped by setting (the archive has ${parsed.animations.length}).`);
		return;
	}
	if (typeof Animation === 'undefined') {
		report.push('Animations skipped: the Animation class is unavailable in this build.');
		return;
	}
	report.push(calibrateBoneRotation());
	probeBonePositionFrame(groupByNode, parsed, report);
	calibrateAnimRotation(groupByNode, parsed, report);
	const preMultiply = !!(opts && opts.anim_order === 'pre');
	const accuracy = animationAccuracyConfig(opts);
	const sampleFps = accuracy.fps;
	// Position channel modes:
	//   big      only offsets above the threshold, the rest are skipped (default)
	//   model    offset conjugated by the parent's rest rotation
	//   local    offset from rest WITHOUT conjugation
	//   absolute write T(t) as it is
	//   skip     do not transfer
	//
	// The mode was chosen by calculation, not by eye: tools/verify-animation.mjs
	// assembles a pose from our keyframes and compares it with the true glTF pose
	// across every animation and six time points. Of sixteen combinations exactly
	// one gives a zero miss: model + R(t)·R0⁻¹. The gap between model and local is
	// only 0.19 px, so the setting is indistinguishable by eye and picking it
	const posMode = (opts && opts.positions) || 'big';
	const withPositions = posMode !== 'skip';
	// Threshold: small offsets sit on bones that drag whole subtrees, doing more
	// harm than good. Large ones are exactly what the eye can see.
	const alignTimes = !!(opts && opts.align_times);
	// The threshold defaults to 0, so every offset is transferred. A value of 2 px
	// muted small offsets and served as insurance while animations were being
	// sorted out; it now remains a lever in the advanced settings in case bones
	// drift apart in an animation.
	const posMinDelta = posMode === 'big'
		? (opts && typeof opts.pos_threshold === 'number' ? opts.pos_threshold : 0)
		: 0;
	const deltaMode = posMode === 'big' ? 'model' : posMode;
	// Print what actually arrived from the dialog: if a setting fails to reach
	// here, both options give the same picture and that looks like a mystery.
	report.push(`Rotation formula: ${preMultiply ? 'R0⁻¹·R(t)' : 'R(t)·R0⁻¹'}`
		+ ` (from dialog: ${opts ? JSON.stringify(opts.anim_order) : 'nothing'})`);
	report.push(`Position channels: ${posMode}` + (posMode === 'big' ? ` (threshold ${posMinDelta} px)` : '') + `; translation scale x${unitScale}`);
	report.push(`Animation sampling: ${accuracy.label}`);
	const mirroredParents = parsed.hierarchy.filter(h => h.parentMirrored).length;
	if (mirroredParents) report.push(`Animation coordinate basis: ${mirroredParents} bone(s) inherit a mirrored parent frame; signed-basis conversion enabled`);

	// parentQuat lives on the node itself, not inside rest: taking only h.rest
	// would silently give the conjugation an identity quaternion and do nothing
	const restOf = {};
	for (const h of parsed.hierarchy) {
		restOf[h.index] = {
			translation: h.rest.translation,
			rotation: h.rest.rotation,
			scale: h.rest.scale,
			parentQuat: h.parentQuat,
			parentBasis: h.parentBasis || matIdentity(),
			parentLinear: h.parentLinear || h.parentBasis || matIdentity(),
			parentMirrored: !!h.parentMirrored,
		};
	}

	let ok = 0, failed = 0;
	// Everything that can silently fail is counted: without these numbers
	// debugging animations turns into guesswork.
	let noGroup = 0, noAnimator = 0, keyframes = 0, kfErrors = '';
	let posSkipped = 0, maxPosDelta = 0, maxPosApplied = 0, posConjugated = 0, resampled = 0;
	const lostMotion = [], poses = [];

	for (const a of parsed.animations) {
		try {
			// Some animations are static poses: zero length, one keyframe, rotations
			// that never change. They must be held rather than played instantly,
			// otherwise it looks like an animation a millisecond long.
			const isPose = a.length < 1e-6;
			if (isPose) poses.push(a.name);
			const anim = new Animation({
				name: a.name,
				loop: importedAnimationLoopMode(a.name, isPose, opts),
				length: isPose ? 0.25 : a.length,
			}).add();

			// When creating a keyframe Blockbench touches the SELECTED animation, and
			// without one it fails on `null.setLength()`. The keyframes still get
			// written, but some settings are not applied — hence the drift.
			try { if (anim.select) anim.select(); } catch (e) { /* fallback below */ }
			if (typeof Animation !== 'undefined' && !Animation.selected) Animation.selected = anim;

			// channels of one node go into a single animator
			const byNode = {};
			for (const ch of a.channels) (byNode[ch.node] = byNode[ch.node] || []).push(ch);

			for (const nodeIndex in byNode) {
				const group = groupByNode[nodeIndex];
				if (!group) { noGroup++; continue; }
				const animator = anim.getBoneAnimator(group);
				if (!animator) { noAnimator++; continue; }
				const rest = restOf[nodeIndex] || { translation: [0, 0, 0], rotation: [0, 0, 0, 1] };

				// Position and rotation channels are placed on THE SAME times.
				// When the times differ, the bone pose drifts apart in the editor:
				// exactly walking and run broke, where position had 5 marks and rotation
				// only 3. Wherever the times matched, or there was no rotation,
				// everything worked. The size of the offset had nothing to do with it.
				const chans = byNode[nodeIndex].filter(c => c.path !== 'scale');
				const rotCh = chans.find(c => c.path === 'rotation');
				let posCh = chans.find(c => c.path === 'translation');

				if (posCh) {
					let chMax = 0;
					for (let vi = 0; vi < posCh.times.length; vi++) {
						const v = channelKeyValue(posCh, vi);
						chMax = Math.max(chMax, Math.hypot(
							v[0] - rest.translation[0],
							v[1] - rest.translation[1],
							v[2] - rest.translation[2]) * unitScale);
					}
					if (!withPositions || chMax < posMinDelta) {
						posSkipped += posCh.times.length;
						if (chMax > maxPosDelta) maxPosDelta = chMax;
						if (chMax > 0.3) lostMotion.push(`${a.name}/${group.name} ${chMax.toFixed(2)}px`);
						posCh = null;
					}
				}
				if (!rotCh && !posCh) continue;

				const q0 = new THREE.Quaternion(rest.rotation[0], rest.rotation[1], rest.rotation[2], rest.rotation[3]);
				const q0inv = q0.clone().invert();
				// The rest pose is baked into the cubes' world coordinates while the
				// bone sits at zero rotation, so its frame is the model frame. The glTF
				// offset, however, is computed in the node's LOCAL frame; conjugating by
				// the parent's rest rotation converts one into the other.
				const pq = rest.parentQuat || [0, 0, 0, 1];
				const qp = new THREE.Quaternion(pq[0], pq[1], pq[2], pq[3]);
				const qpInv = qp.clone().invert();
				const parentBasis = rest.parentBasis || matIdentity();
				const parentBasis4 = new THREE.Matrix4().fromArray(parentBasis);
				const parentBasisInv4 = parentBasis4.clone().invert();
				// Translation must keep the parent's real scale. Geometry was baked with
				// the complete parent matrix, so throwing scale away here changes the
				// distance moved by animated children. Rotation still uses the
				// orthonormal signed basis above because quaternions cannot contain scale.
				const parentLinear4 = new THREE.Matrix4().fromArray(rest.parentLinear || parentBasis);
				const parentLinear3 = new THREE.Matrix3().setFromMatrix4(parentLinear4);

				// Time alignment is a hypothesis guarded by its own flag. Without it
				// each channel is written on its own times, exactly as in glTF.
				const timeSet = new Set();
				if (alignTimes) {
					if (rotCh) for (const t of rotCh.times) timeSet.add(+t.toFixed(6));
					if (posCh) for (const t of posCh.times) timeSet.add(+t.toFixed(6));
				}
				const times = [...timeSet].sort((x, y) => x - y);
				const denseTimes = sampleFps > 0
					? animationSampleTimes(a, [rotCh, posCh].filter(Boolean), sampleFps)
					: null;
				// a bone whose channels sat on different times is the very one that
				// broke the pose; count them to see the fix working
				if (!denseTimes && rotCh && posCh && (rotCh.times.length !== times.length || posCh.times.length !== times.length)) resampled++;

				let previousEuler = null;
				const writeAt = (t, useRot, usePos) => {
					// Blockbench stores keyframe values as strings and parses them as
					// Molang expressions. A number like 4.8e-8 arrives in scientific
					// notation where e is not a digit; parsing can yield NaN and then the
					// whole bone flies off, though the useful magnitude is one pixel.
					// So noise is pinned to zero and the rest is rounded.
					const clean = v => {
						if (!isFinite(v) || Math.abs(v) < accuracy.zeroEps) return 0;
						return Math.round(v * accuracy.round) / accuracy.round;
					};
					const write = (raw, channel) => {
						const data = { x: clean(raw.x), y: clean(raw.y), z: clean(raw.z) };
						try {
							const kf = animator.createKeyframe(data, t, channel, false, false);
							if (kf) {
								keyframes++;
								// Interpolation is set EXPLICITLY. glTF uses linear, while
								// Blockbench also has catmullrom and bezier; smoothing over
								// sparse oscillating values (legs in walking: +1, 0, -1, 0, +1)
								// overshoots far beyond the given points.
								try { kf.interpolation = 'linear'; } catch (e) { /* may be read-only */ }
							} else if (!kfErrors) kfErrors = 'createKeyframe returned nothing';
						} catch (err) {
							if (!kfErrors) kfErrors = `createKeyframe threw: ${(err && err.message) || err}`;
						}
					};

					if (rotCh && useRot) {
						const v = sampleChannel(rotCh, t);
						const q = new THREE.Quaternion(v[0], v[1], v[2], v[3]);
						const local = preMultiply ? q0inv.clone().multiply(q) : q.clone().multiply(q0inv);
						// Use the signed parent basis instead of parentQuat alone. A mirrored
						// coordinate frame changes the apparent sign of rotations.
						const localMatrix = new THREE.Matrix4().makeRotationFromQuaternion(local);
						const deltaMatrix = parentBasis4.clone().multiply(localMatrix).multiply(parentBasisInv4);
						const delta = new THREE.Quaternion().setFromRotationMatrix(deltaMatrix).normalize();
						const e = new THREE.Euler().setFromQuaternion(delta, BONE_EULER_ORDER);
						let ex = THREE.MathUtils.radToDeg(e.x) * BONE_ROT_SIGN[0];
						let ey = THREE.MathUtils.radToDeg(e.y) * BONE_ROT_SIGN[1];
						let ez = THREE.MathUtils.radToDeg(e.z) * BONE_ROT_SIGN[2];
						if (previousEuler) {
							ex = continuousAngle(ex, previousEuler[0]);
							ey = continuousAngle(ey, previousEuler[1]);
							ez = continuousAngle(ez, previousEuler[2]);
						}
						previousEuler = [ex, ey, ez];
						write({ x: ex, y: ey, z: ez }, 'rotation');
					}
					if (posCh && usePos) {
						const v = sampleChannel(posCh, t);
						const base = deltaMode === 'absolute' ? [0, 0, 0] : rest.translation;
						const d = new THREE.Vector3(v[0] - base[0], v[1] - base[1], v[2] - base[2]);
						if (deltaMode !== 'local') d.applyMatrix3(parentLinear3);
						// Pre-compensation: if the editor applies the offset INSIDE the
						// bone rotation, the stored value arrives rotated. We rotate it
						// back in advance by that bone's rotation at this moment.
						if (deltaMode === 'rt' && rotCh) {
							const rv = sampleChannel(rotCh, t);
							const rq = new THREE.Quaternion(rv[0], rv[1], rv[2], rv[3]);
							const rlocal = preMultiply ? q0inv.clone().multiply(rq) : rq.clone().multiply(q0inv);
							const rlocalMatrix = new THREE.Matrix4().makeRotationFromQuaternion(rlocal);
							const rdeltaMatrix = parentBasis4.clone().multiply(rlocalMatrix).multiply(parentBasisInv4);
							const rdelta = new THREE.Quaternion().setFromRotationMatrix(rdeltaMatrix).normalize();
							d.applyQuaternion(rdelta.clone().invert());
						}
						maxPosApplied = Math.max(maxPosApplied, d.length() * unitScale);
						if (deltaMode !== 'local' && (Math.abs(qp.w) < 0.999999 || rest.parentMirrored)) posConjugated++;
						write({ x: d.x * unitScale, y: d.y * unitScale, z: d.z * unitScale }, 'position');
					}
				};

				if (denseTimes) {
					// glTF quaternion interpolation cannot be represented exactly by sparse
					// Euler keys. Resampling both channels on the same timeline preserves
					// the visible path and also prevents child translations from drifting.
					//
					// Ultra/Exact intentionally keep a dense baked timeline so GeckoLib's
					// in-game result stays as close as possible to the Blockbench preview.
					for (const t of denseTimes) writeAt(t, !!rotCh, !!posCh);
					if (rotCh && posCh) resampled++;
				} else if (alignTimes) {
					for (const t of times) writeAt(t, true, true);
				} else {
					if (rotCh) for (const t of rotCh.times) writeAt(t, true, false);
					if (posCh) for (const t of posCh.times) writeAt(t, false, true);
				}
			}
			// the length is recomputed from the actual keyframes: a value set in
			// advance may not match what really landed
			try { if (anim.setLength) anim.setLength(); } catch (e) { /* optional */ }
			ok++;
		} catch (e) {
			failed++;
			report.push(`  animation ${a.name}: ${(e && e.message) || e}`);
		}
	}

	// verify the keyframes really settled into the project rather than vanishing
	let stored = 0, animators = 0;
	try {
		for (const anim of Animation.all) {
			for (const key in anim.animators) {
				animators++;
				const an = anim.animators[key];
				for (const ch of ['rotation', 'position', 'scale']) {
					if (an[ch] && an[ch].length) stored += an[ch].length;
				}
			}
		}
	} catch (e) { /* not critical */ }

	verifyAnimationPose(parsed, groupByNode, report);

	// Return the model to its rest pose. Otherwise the last animation stays
	// selected, Blockbench shows the pose FROM IT, and that is indistinguishable
	// from the cubes having been assembled in the wrong places.
	try {
		if (typeof Animation !== 'undefined') Animation.selected = null;
		if (typeof Timeline !== 'undefined' && Timeline.setTime) Timeline.setTime(0);
		if (typeof Modes !== 'undefined' && Modes.options && Modes.options.edit) Modes.options.edit.select();
	} catch (e) { report.push(`  could not restore the rest pose: ${(e && e.message) || e}`); }

	report.push(`Animations transferred: ${ok}, failed: ${failed} (bone axis order: ${BONE_EULER_ORDER})`);
	report.push(`  keyframes created: ${keyframes}, stored in project: ${stored}, animators: ${animators}`);
	report.push(`  time alignment: ${sampleFps > 0
		? `dense ${sampleFps} FPS, bones sampled ${resampled}`
		: (alignTimes ? `source-key alignment on, bones resampled ${resampled}` : 'source key times')}`);
	if (posSkipped) {
		report.push(`  position channels skipped: ${posSkipped} keyframes, largest dropped offset ${maxPosDelta.toFixed(2)} px`);
		if (lostMotion.length) {
			const top = lostMotion.sort((x, y) => parseFloat(y.split(' ').pop()) - parseFloat(x.split(' ').pop()));
			report.push(`  largest dropped: ${top.slice(0, 8).join(', ')}`);
		}
	} else if (maxPosApplied) {
		report.push(`  largest applied offset: ${maxPosApplied.toFixed(2)} px`
			+ `, conjugations applied: ${posConjugated}`);
	}
	if (noGroup) report.push(`  channels without a bone: ${noGroup}`);
	if (noAnimator) report.push(`  bones without an animator: ${noAnimator}`);
	if (poses.length) report.push(`  static poses (held, not played): ${poses.join(', ')}`);
	if (kfErrors) report.push(`  first keyframe error: ${kfErrors}`);
	const skipped = parsed.animations.reduce((s, a) => s + a.channels.filter(c => c.path === 'scale').length, 0);
	if (skipped) report.push(`  scale channels skipped: ${skipped} — GeckoLib does not animate them`);
}

/**
 * Draws every texture into one atlas and returns a data URL.
 *
 * Asynchronous because the images must be decoded. The project texture is
 * created immediately and its content filled in once ready, so the whole import
 * does not have to be restructured around waiting.
 */
function buildAtlasDataURL(images, layout, tileSpecs) {
	return new Promise(resolve => {
		try {
			const canvas = document.createElement('canvas');
			canvas.width = layout.width;
			canvas.height = layout.height;
			const ctx = canvas.getContext('2d');
			ctx.imageSmoothingEnabled = false;   // pixel art, no smoothing
			let pending = images.length;
			if (!pending) return resolve(canvas.toDataURL());

			const drawTile = (el, x, y, w, h, flipX, flipY) => {
				ctx.save();
				ctx.translate(x + (flipX ? w : 0), y + (flipY ? h : 0));
				ctx.scale(flipX ? -1 : 1, flipY ? -1 : 1);
				ctx.drawImage(el, 0, 0, w, h);
				ctx.restore();
			};

			images.forEach((img, i) => {
				const el = new Image();
				const done = () => { if (--pending === 0) resolve(canvas.toDataURL()); };
				el.onload = () => {
					const r = layout.rects[i];
					const spec = tileSpecs && tileSpecs[i];
					try {
						if (!spec) {
							ctx.drawImage(el, r.x, r.y, r.w, r.h);
						} else {
							for (let ty = 0; ty < spec.countV; ty++) {
								for (let tx = 0; tx < spec.countU; tx++) {
									const absU = spec.minTileU + tx;
									const absV = spec.minTileV + ty;
									const flipX = spec.modeS === GLTF_WRAP_MIRROR && Math.abs(absU) % 2 === 1;
									const flipY = spec.modeT === GLTF_WRAP_MIRROR && Math.abs(absV) % 2 === 1;
									drawTile(el,
										r.x + tx * spec.sourceW,
										r.y + ty * spec.sourceH,
										spec.sourceW, spec.sourceH,
										flipX, flipY);
								}
							}
						}
					} catch (e) { /* skip a broken one */ }
					done();
				};
				el.onerror = done;
				el.src = 'data:' + (img.mime || 'image/png') + ';base64,' + bytesToBase64(img.bytes);
			});
		} catch (e) {
			resolve(null);
		}
	});
}

/** Builds a project from an unpacked archive. */
/**
 * What the last import produced. The CPM export needs the same hierarchy, boxes
 * and texture, and it has to survive between two dialogs — so it is kept here
 * rather than threaded through. Declared BEFORE the function that fills it:
 * a `let` used above its declaration is a temporal-dead-zone error, and this
 * plugin has already been bitten by that once.
 */
let lastImport = null;

/** Build a GeckoLib Blockbench project using Mesh elements instead of Cubes. */
function buildPolyMeshProject(ctx) {
	const {
		parsed, sourceName, report, images, layout, tileSpecs, size,
		chosenScale, needAtlas, opts, previewWrap,
	} = ctx;

	// Keep the exporter in the same coordinate convention as the runtime mod.
	// GeckoMesh 1.1+ is the current/default coordinate convention. Keep 1.0
	// selectable for older CurseMaven builds, but do not silently fall back to it.
	// Using the wrong convention mirrors PolyMesh geometry relative to the bones.
	polyMeshGeckoMeshRuntime =
		opts && opts.geckomesh_runtime === '1_0' ? '1_0' : '1_1_plus';

	enableGeckoMeshEditing();
	installPolyMeshExporter();
	newProject(Formats.geckolib_model);
	Project.name = (sourceName || 'model').replace(/\.[^.]*$/, '');
	Project.box_uv = false;
	Project.texture_width = size.width;
	Project.texture_height = size.height;

	const needRedraw = needAtlas || (images[0].mime && images[0].mime !== 'image/png');
	const atlasTexture = new Texture({
		name: needAtlas ? 'atlas.png' : (images[0].name || 'texture.png').replace(/\.[^.]*$/, '.png'),
	});
	if (needRedraw) {
		atlasTexture.add();
		buildAtlasDataURL(images, layout, tileSpecs).then(url => {
			if (url) atlasTexture.fromDataURL(url);
			if (previewWrap) applyPreviewTextureWrap(atlasTexture, previewWrap.modeS, previewWrap.modeT);
			Canvas.updateAll();
		});
	} else {
		atlasTexture.fromDataURL('data:' + (images[0].mime || 'image/png') + ';base64,' + bytesToBase64(images[0].bytes)).add();
		if (previewWrap) applyPreviewTextureWrap(atlasTexture, previewWrap.modeS, previewWrap.modeT);
	}

	// Preserve the exact bone hierarchy used by the cube path so existing glTF
	// animation conversion continues to target the same nodes.
	const groupByNode = {};
	for (const h of parsed.hierarchy) {
		const g = new Group({ name: h.name, origin: preciseBonePivot(h.pivot) }).init();
		if (h.parent >= 0 && groupByNode[h.parent]) g.addTo(groupByNode[h.parent]);
		groupByNode[h.index] = g;
	}

	const requestedSkinningMode = opts && opts.skinning_mode;
	const skinningMode = ['native', 'auto', 'continuous', 'dominant'].includes(requestedSkinningMode)
		? requestedSkinningMode
		: 'native';
	const hierarchyByNode = new Map(parsed.hierarchy.map(h => [h.index, h]));
	const parentOfNode = node => {
		const h = hierarchyByNode.get(node);
		return h && h.parent >= 0 ? h.parent : undefined;
	};
	const commonAncestor = nodes => {
		const unique = [...new Set(Array.from(nodes || []).filter(n => hierarchyByNode.has(n)))];
		if (!unique.length) return undefined;
		const otherSets = unique.slice(1).map(n => {
			const set = new Set();
			for (let p = n; p !== undefined; p = parentOfNode(p)) set.add(p);
			return set;
		});
		for (let p = unique[0]; p !== undefined; p = parentOfNode(p)) {
			if (otherSets.every(set => set.has(p))) return p;
		}
		return undefined;
	};
	const isAncestorOf = (ancestor, node) => {
		for (let p = node; p !== undefined; p = parentOfNode(p)) if (p === ancestor) return true;
		return false;
	};
	// A smooth ribbon driven by strip000 -> strip001 -> ... is a special case that
	// GeckoMesh can approximate much better than a general smooth-skinned surface.
	// If every influencing joint is comparable in one ancestor chain, assigning
	// successive triangles to their dominant chain joint produces articulated rigid
	// sections instead of one completely rigid "bamboo".  Sibling-driven body
	// surfaces (root/top/bottom) are NOT a chain and therefore stay continuous.
	const isLinearBoneChain = nodes => {
		const unique = [...new Set(Array.from(nodes || []).filter(n => hierarchyByNode.has(n)))];
		if (unique.length < 2) return false;
		for (let i = 0; i < unique.length; i++) {
			for (let j = i + 1; j < unique.length; j++) {
				if (!isAncestorOf(unique[i], unique[j]) && !isAncestorOf(unique[j], unique[i])) return false;
			}
		}
		return true;
	};

	let meshCount = 0, triangleCount = 0, dropped = 0, untextured = 0;
	let smoothComponentsKept = 0, smoothFacesKept = 0;
	let chainComponentsSplit = 0, chainFacesSplit = 0;
	let weightedMeshCount = 0, weightedFaceCount = 0;
	const smoothExamples = [], chainExamples = [], weightedExamples = [];
	for (const obj of parsed.objects) {
		let sourceFaces = obj.faces || [];

		// Native CS2 mode keeps every glTF-skinned primitive intact.  The Mesh is
		// still created so the bind pose can be inspected/edited in Blockbench, but
		// the Bedrock compile hook excludes it from bone.poly_mesh and instead writes
		// exact JOINTS_0/WEIGHTS_0 into geometry.cs2_skinning.  At runtime CS2 Lootbox
		// asks GeckoLib for the animated bone pose and performs the vertex blend.
		if (skinningMode === 'native') {
			const weightedFaces = sourceFaces.filter(face => Array.isArray(face.skinVertices)
				&& face.skinVertices.some(v => Array.isArray(v) && v.length));
			if (weightedFaces.length) {
				const valid = weightedFaces.filter(f => !isDegenerate([f]));
				dropped += weightedFaces.length - valid.length;
				if (valid.length) {
					const influences = new Set();
					for (const face of valid) for (const node of face.skinNodes || []) influences.add(node);
					let anchor = commonAncestor(influences);
					if (anchor === undefined) anchor = valid.find(face => face.boneNode !== undefined)?.boneNode;
					if (anchor === undefined) anchor = obj.node;

					const mesh = meshFromTriangleFaces(`${obj.name}_weighted`, valid, atlasTexture, true);
					mesh.__cs2WeightedSource = { faces: valid, groupByNode, hierarchyByNode };
					mesh.__cs2WeightedPreviewEnabled = !opts || opts.weighted_skin_preview !== false;
					const parent = groupByNode[anchor] || groupByNode[obj.node];
					if (parent) mesh.addTo(parent); else mesh.addTo('root');
					mesh.init();
					meshCount++;
					triangleCount += valid.length;
					weightedMeshCount++;
					weightedFaceCount += valid.length;
					if (weightedExamples.length < 4) {
						const names = [...influences].map(n => hierarchyByNode.get(n)?.name || n);
						weightedExamples.push(`${obj.name}: ${valid.length} faces / ${names.length} bones`);
					}
					if (obj.image < 0) untextured++;
				}
			}
			const weightedSet = new Set(weightedFaces);
			sourceFaces = sourceFaces.filter(face => !weightedSet.has(face));
		}
		// GeckoLib/GeckoMesh transforms a complete poly_mesh with one bone; it does
		// not retain glTF JOINTS_0/WEIGHTS_0 per vertex.  There is therefore no exact
		// representation of Source 2 smooth skinning.  The default AUTO mode uses a
		// hybrid approximation:
		//   * general blended surfaces stay on one common ancestor so the body does
		//     not explode into detached triangles;
		//   * blended surfaces driven by a single linear bone chain are segmented by
		//     dominant joint, allowing ribbons/tear strips/tails to articulate.
		// CONTINUOUS keeps every blended island rigid. DOMINANT is the old behaviour
		// that splits every blended triangle, including the main body.
		const assignedBone = new Map();
		if (skinningMode !== 'dominant') {
			const components = splitComponents(sourceFaces).map(faces => {
				const influences = new Set();
				for (const face of faces) for (const node of face.skinNodes || []) influences.add(node);
				return { faces, influences, blended: faces.some(face => !!face.skinBlended) };
			});

			// Rigid components always keep their exact owning bone. In AUTO, a smooth
			// component driven by one ancestor chain is intentionally segmented by the
			// dominant joint of each triangle. This is what restores bending of the
			// dossier's envelope_strip000..005 while leaving the envelope body intact.
			const continuousIds = [];
			for (let i = 0; i < components.length; i++) {
				const component = components[i];
				if (!component.blended) {
					for (const face of component.faces) assignedBone.set(face, face.boneNode === undefined ? obj.node : face.boneNode);
					continue;
				}
				if (skinningMode === 'auto' && isLinearBoneChain(component.influences)) {
					for (const face of component.faces) assignedBone.set(face, face.boneNode === undefined ? obj.node : face.boneNode);
					chainComponentsSplit++;
					chainFacesSplit += component.faces.length;
					if (chainExamples.length < 4) {
						const names = [...component.influences].map(n => hierarchyByNode.get(n)?.name || n);
						chainExamples.push(`${component.faces.length} faces → ${names.join(' -> ')}`);
					}
				} else {
					continuousIds.push(i);
				}
			}

			// Several disconnected shells can belong to the SAME smooth-skinned part.
			// Merge continuous candidates that share influences before choosing a common
			// ancestor, otherwise caps/backfaces can still float independently.
			const parent = new Map(continuousIds.map(i => [i, i]));
			const find = i => {
				let p = parent.get(i);
				while (p !== parent.get(p)) { parent.set(p, parent.get(parent.get(p))); p = parent.get(p); }
				return p;
			};
			const unite = (a, b) => { a = find(a); b = find(b); if (a !== b) parent.set(b, a); };
			for (let ai = 0; ai < continuousIds.length; ai++) {
				for (let bi = ai + 1; bi < continuousIds.length; bi++) {
					const a = components[continuousIds[ai]], b = components[continuousIds[bi]];
					let overlaps = false;
					for (const node of a.influences) if (b.influences.has(node)) { overlaps = true; break; }
					if (overlaps) unite(continuousIds[ai], continuousIds[bi]);
				}
			}

			const islands = new Map();
			for (const i of continuousIds) {
				const root = find(i);
				if (!islands.has(root)) islands.set(root, []);
				islands.get(root).push(components[i]);
			}

			for (const island of islands.values()) {
				const influences = [];
				const islandFaces = [];
				for (const component of island) {
					islandFaces.push(...component.faces);
					influences.push(...component.influences);
				}
				let anchor = commonAncestor(influences);
				if (anchor === undefined) anchor = islandFaces.find(face => face.boneNode !== undefined)?.boneNode;
				if (anchor === undefined) anchor = obj.node;
				for (const face of islandFaces) assignedBone.set(face, anchor);
				smoothComponentsKept += island.length;
				smoothFacesKept += islandFaces.length;
				if (smoothExamples.length < 4) {
					const bone = hierarchyByNode.get(anchor);
					smoothExamples.push(`${islandFaces.length} faces / ${island.length} shell(s) → ${(bone && bone.name) || anchor}`);
				}
			}
		}

		const buckets = new Map();
		for (const face of sourceFaces) {
			// AUTO and CONTINUOUS both pre-compute the intended bone in assignedBone:
			// AUTO keeps general smooth islands together while still segmenting linear
			// bone chains; CONTINUOUS keeps every blended island together. Only the
			// explicit DOMINANT mode should bypass that assignment.
			const fallbackBone = face.boneNode === undefined ? obj.node : face.boneNode;
			const boneNode = skinningMode === 'dominant'
				? fallbackBone
				: (assignedBone.get(face) ?? fallbackBone);
			if (!buckets.has(boneNode)) buckets.set(boneNode, []);
			buckets.get(boneNode).push(face);
		}

		let bi = 0;
		for (const [boneNode, faces] of buckets) {
			const valid = faces.filter(f => !isDegenerate([f]));
			dropped += faces.length - valid.length;
			if (!valid.length) continue;
			const bone = parsed.hierarchy.find(h => h.index === boneNode);
			const suffix = buckets.size > 1 && bone ? `_${bone.name}` : '';
			const mesh = meshFromTriangleFaces(`${obj.name}${suffix}${buckets.size > 1 ? `_${++bi}` : ''}`, valid, atlasTexture);
			const parent = groupByNode[boneNode] || groupByNode[obj.node];
			if (parent) mesh.addTo(parent);
			else mesh.addTo('root');
			mesh.init();
			meshCount++;
			triangleCount += valid.length;
			if (obj.image < 0) untextured++;
		}
	}

	const lines = [
		`Imported from: ${sourceName}`,
		...report,
		'Geometry mode: Poly Mesh (original glTF triangles preserved)',
		`GeckoMesh runtime: ${polyMeshGeckoMeshRuntime === '1_1_plus'
			? '1.1+ (runtime negates X)'
			: '1.0 / CurseMaven (runtime keeps X)'}`,
		`Geometry/animation unit scale: x${parsed.unitScale || chosenScale}` ,
		`Skinning: ${skinningMode === 'native'
			? `native CS2 weighted renderer — ${weightedMeshCount} mesh(es), ${weightedFaceCount} faces${weightedExamples.length ? '; ' + weightedExamples.join(', ') : ''}`
			: skinningMode === 'auto'
				? `auto hybrid — ${chainComponentsSplit} chain component(s) segmented (${chainFacesSplit} faces${chainExamples.length ? '; ' + chainExamples.join(', ') : ''}); ${smoothComponentsKept} general blended component(s) kept continuous (${smoothFacesKept} faces${smoothExamples.length ? '; ' + smoothExamples.join(', ') : ''})`
				: skinningMode === 'continuous'
					? `keep all blended components continuous (${smoothComponentsKept} component(s), ${smoothFacesKept} faces${smoothExamples.length ? '; ' + smoothExamples.join(', ') : ''})`
					: 'legacy dominant joint per triangle'}`,
		`Poly Mesh elements created: ${meshCount}`,
		`Triangles preserved: ${triangleCount}`,
		`Bones created: ${parsed.hierarchy.length}`,
		parsed.bindPivotStats && parsed.bindPivotStats.overrides
			? `Bone pivots: ${parsed.bindPivotStats.overrides} skinned joint(s) reconstructed from inverse bind matrices; max correction ${parsed.bindPivotStats.maxCorrection.toFixed(3)} px${parsed.bindPivotStats.worstBone ? ` on “${parsed.bindPivotStats.worstBone}”` : ''}`
			: 'Bone pivots: exact glTF node positions (no usable inverse bind matrices)',
		`Texture: ${size.width}×${size.height}`,
		`Objects without a material: ${untextured}`,
	];
	if (dropped) lines.push(`Degenerate triangles dropped: ${dropped}`);
	lines.push(skinningMode === 'native'
		? 'NOTE: skinned primitives export as geometry.cs2_skinning and are rendered from GeckoLib bone poses by the updated CS2 Lootbox renderer. Rigid primitives still use bone.poly_mesh/GeckoMesh.'
		: 'NOTE: the exported .geo.json uses bone.poly_mesh. Stock GeckoLib Java currently does not render poly_mesh; a runtime renderer/loader extension is required.');

	try {
		applyAnimations(parsed, groupByNode, lines, opts);
	} catch (e) {
		console.error('[geckolib-import] animation transfer failed', e);
		lines.push('', `ANIMATIONS WERE NOT TRANSFERRED: ${(e && e.message) || e}`,
			'The model and texture were still built correctly.');
	}
	if (parsed.warnings.length) lines.push('', 'Warnings:', ...parsed.warnings.slice(0, 8));

	Canvas.updateAll();
	let weightedPreviewStats = { prepared: 0, vertices: 0, missing: 0 };
	if (skinningMode === 'native' && (!opts || opts.weighted_skin_preview !== false)) {
		weightedPreviewStats = prepareAllWeightedSkinPreviews();
		lines.push(`Blockbench weighted preview: ${weightedPreviewStats.prepared} mesh(es), ${weightedPreviewStats.vertices} skinned vertices${weightedPreviewStats.missing ? `, ${weightedPreviewStats.missing} missing bone binding(s)` : ''}`);
	}
	// Canvas.updateAll may recreate the material and reset texture wrapping.
	// Re-assert the sampler after the final project rebuild as well.
	if (previewWrap) applyPreviewTextureWrap(atlasTexture, previewWrap.modeS, previewWrap.modeT);
	console.log('[geckolib-import] poly_mesh import\n' + lines.join('\n'));
	lastImport = {
		parsed, solved: [], images, layout, size, chosenScale, sourceName,
		texture: atlasTexture, needAtlas, geometryMode: 'poly_mesh',
	};
	showImportReport({
		title: 'Import finished — Poly Mesh',
		summary: [
			['Poly Meshes', String(meshCount)],
			['Triangles', String(triangleCount)],
			['Bones', String(parsed.hierarchy.length)],
			['Texture', `${size.width}×${size.height}`],
			['Animations', String(parsed.animations.length)],
			['Scale', `×${chosenScale}`],
		],
		warning: skinningMode === 'native'
			? 'Weighted glTF meshes export in geometry.cs2_skinning. Blockbench previews the same smooth weights while scrubbing/playing animations, and the updated CS2 Lootbox renderer performs the equivalent skinning in-game from GeckoLib bone poses.'
			: 'Poly Mesh preserves the source geometry, but stock GeckoLib Java currently does not render bone.poly_mesh. Use it only with a runtime renderer/loader that supports it.',
		log: lines.join('\n'),
		name: (sourceName || 'model').replace(/\.[^.]*$/, ''),
	});
	return lastImport;
}

function buildFromFiles(files, sourceName, opts) {
	const report = [];

	// A probe parse in glTF units: both the texture size and the model bounds are
	// needed to pick the coordinate scale.
	let probe;
	const rotate = [
		Number((opts && opts.rot_x) || 0),
		Number((opts && opts.rot_y) || 0),
		0,
	];
	try { probe = parseGLTFFiles(files, { scale: 1, uvWidth: 1, uvHeight: 1, rotate }); }
	catch (e) { Blockbench.showMessageBox({ title: 'Import failed', message: String((e && e.message) || e) }); return; }

	// Objects reference an image by its glTF index, and unreadable ones fall out
	// of the list, so the indices shift after filtering. A map from glTF index to
	// atlas index is kept, otherwise an object silently receives someone else's
	// piece of texture.
	const sized = probe.images.map(img => ({ ...img, size: imageSize(img.bytes) }));
	// Only colour goes into the atlas: normal and roughness maps are useless in
	// Minecraft yet take up just as much room.
	const usable = img => !!img.size && img.role !== 'aux';
	const images = sized.filter(usable);
	const remap = [];
	let next = 0;
	sized.forEach((img, i) => { remap[i] = usable(img) ? next++ : -1; });

	if (!images.length) {
		const what = sized.length
			? `Images in the archive: ${sized.length}, but none usable as colour `
				+ '(PNG, JPEG, GIF and WebP are supported).'
			: 'No images were found in the archive.';
		Blockbench.showMessageBox({ title: 'Import failed', message: what });
		return;
	}
	const aux = sized.filter(img => img.size && img.role === 'aux').length;
	const unread = sized.filter(img => !img.size).length;
	if (aux) report.push(`Auxiliary maps skipped: ${aux} (normals, specular) — unused in Minecraft`);
	if (unread) report.push(`Images skipped: ${unread} — format not recognised`);

	// The main texture is the one most objects use: its size defines the
	// project's UV space.
	const usage = {};
	for (const o of probe.objects) {
		const i = remap[o.image];
		if (i >= 0) usage[i] = (usage[i] || 0) + 1;
	}
	let mainIndex = 0, mainCount = -1;
	images.forEach((img, i) => { if ((usage[i] || 0) > mainCount) { mainCount = usage[i] || 0; mainIndex = i; } });

	// glTF permits UV outside 0..1 and defaults to REPEAT. GeckoLib/Blockbench
	// cannot safely rely on sampler wrapping, and an atlas makes raw repeated UV
	// actively wrong because they wander into a neighbouring texture. Measure the
	// tile range required by each colour image and bake those repeats into its
	// atlas rectangle. MIRRORED_REPEAT is baked with alternating flipped copies.
	const repeatStats = images.map(() => ({
		minU: Infinity, maxU: -Infinity, minV: Infinity, maxV: -Infinity,
		modeS: null, modeT: null,
	}));
	for (const obj of probe.objects) {
		for (const face of obj.faces) {
			const srcImage = face.image === undefined ? obj.image : face.image;
			const atlasImage = remap[srcImage];
			if (atlasImage === undefined || atlasImage < 0) continue;
			const stat = repeatStats[atlasImage];
			const modeS = face.wrapS === undefined ? GLTF_WRAP_REPEAT : face.wrapS;
			const modeT = face.wrapT === undefined ? GLTF_WRAP_REPEAT : face.wrapT;
			if (modeS !== GLTF_WRAP_CLAMP) stat.modeS = stat.modeS === GLTF_WRAP_MIRROR || modeS === GLTF_WRAP_MIRROR
				? GLTF_WRAP_MIRROR : GLTF_WRAP_REPEAT;
			if (modeT !== GLTF_WRAP_CLAMP) stat.modeT = stat.modeT === GLTF_WRAP_MIRROR || modeT === GLTF_WRAP_MIRROR
				? GLTF_WRAP_MIRROR : GLTF_WRAP_REPEAT;
			for (const uv of face.uvs || []) {
				if (!uv) continue;
				if (modeS !== GLTF_WRAP_CLAMP) {
					stat.minU = Math.min(stat.minU, uv[0]);
					stat.maxU = Math.max(stat.maxU, uv[0]);
				}
				if (modeT !== GLTF_WRAP_CLAMP) {
					stat.minV = Math.min(stat.minV, uv[1]);
					stat.maxV = Math.max(stat.maxV, uv[1]);
				}
			}
		}
	}

	const tileRange = (min, max) => {
		if (!Number.isFinite(min) || !Number.isFinite(max)) return [0, 0];
		// A coordinate exactly on +1 belongs to the previous tile edge. The tiny
		// epsilon prevents allocating a useless extra tile for ordinary 0..1 UV.
		const eps = 1e-7;
		let a = Math.floor(min + eps);
		let b = Math.ceil(max - eps) - 1;
		if (b < a) b = a;
		// Malformed exports can contain UV thousands of tiles away. Refuse to
		// allocate a gigantic canvas; sixteen tiles per axis is already generous.
		if (b - a + 1 > 16) {
			const centre = Math.floor((a + b) / 2);
			a = centre - 7;
			b = centre + 8;
		}
		return [a, b];
	};

	const requestedGeometryMode = opts && opts.geometry_mode === 'poly_mesh' ? 'poly_mesh' : 'cubes';
	// A single PolyMesh texture does not need repeat copies baked into an atlas.
	// Preserve out-of-range UVs and let texture wrapping do the repetition. This
	// fixes e.g. a 2048x2048 source becoming a duplicated 4096x2048 texture.
	const keepSinglePolyTexture = requestedGeometryMode === 'poly_mesh' && images.length === 1;

	const tileSpecs = images.map((img, i) => {
		const stat = repeatStats[i];
		const [measuredMinU, measuredMaxU] = stat.modeS ? tileRange(stat.minU, stat.maxU) : [0, 0];
		const [measuredMinV, measuredMaxV] = stat.modeT ? tileRange(stat.minV, stat.maxV) : [0, 0];
		const minTileU = keepSinglePolyTexture ? 0 : measuredMinU;
		const maxTileU = keepSinglePolyTexture ? 0 : measuredMaxU;
		const minTileV = keepSinglePolyTexture ? 0 : measuredMinV;
		const maxTileV = keepSinglePolyTexture ? 0 : measuredMaxV;
		return {
			sourceW: img.size.width,
			sourceH: img.size.height,
			minTileU, maxTileU,
			minTileV, maxTileV,
			countU: maxTileU - minTileU + 1,
			countV: maxTileV - minTileV + 1,
			modeS: stat.modeS || GLTF_WRAP_REPEAT,
			modeT: stat.modeT || GLTF_WRAP_REPEAT,
		};
	});

	const tiledTextures = tileSpecs.filter(s => s.countU > 1 || s.countV > 1).length;
	const layout = packAtlas(tileSpecs.map(s => ({
		width: s.sourceW * s.countU,
		height: s.sourceH * s.countV,
	})));
	const needAtlas = images.length > 1 || tiledTextures > 0;
	const size = { width: layout.width, height: layout.height };
	if (images.length > 1) {
		report.push(`Textures in archive: ${images.length} → packed into a ${layout.width}×${layout.height} atlas`);
	}
	if (keepSinglePolyTexture && (repeatStats[0].modeS || repeatStats[0].modeT)) {
		report.push('Poly Mesh repeat UVs preserved without duplicating the source texture');
	}
	if (tiledTextures) {
		report.push(`Repeated UV baked into atlas: ${tiledTextures} texture${tiledTextures === 1 ? '' : 's'}`);
		for (let i = 0; i < tileSpecs.length; i++) {
			const s = tileSpecs[i];
			if (s.countU > 1 || s.countV > 1) {
				report.push(`  ${images[i].name}: ${s.countU}×${s.countV} tiles `
					+ `(U ${s.minTileU}..${s.maxTileU}, V ${s.minTileV}..${s.maxTileV})`);
			}
		}
	}

	// Coordinate scale: for Blockbench a glTF unit is a block, for Sketchfab
	// exports it is already a pixel. A hardcoded ×16 blew such models up 16 times.
	let lo = [Infinity, Infinity, Infinity], hi = [-Infinity, -Infinity, -Infinity];
	for (const o of probe.objects) for (const f of o.faces) for (const q of f.positions) {
		for (let a = 0; a < 3; a++) { if (q[a] < lo[a]) lo[a] = q[a]; if (q[a] > hi[a]) hi[a] = q[a]; }
	}
	const sizeUnits = Math.max(hi[0] - lo[0], hi[1] - lo[1], hi[2] - lo[2]) || 1;
	// Texel density is computed on the probe parse: there the UV are normalised
	// and the size is taken from each object's own texture.
	const density = texelScale(probe.objects, i => images[remap[i] >= 0 ? remap[i] : mainIndex].size);

	// How much UV spills outside its texture. In glTF that is legal — the texture
	// tiles — but an atlas cannot tile: the coordinate wanders onto a neighbouring
	// image, which is the usual cause of a model arriving with the wrong texture.
	let uvTotal = 0, uvOutside = 0, noMaterial = 0;
	for (const o of probe.objects) {
		if (o.image < 0) noMaterial++;
		for (const f of o.faces) {
			for (const uv of f.uvs || []) {
				if (!uv) continue;
				uvTotal++;
				if (uv[0] < -1e-4 || uv[0] > 1 + 1e-4 || uv[1] < -1e-4 || uv[1] > 1 + 1e-4) uvOutside++;
			}
		}
	}
	const uvOutsideShare = uvTotal ? +(100 * uvOutside / uvTotal).toFixed(1) : 0;
	if (uvOutsideShare > 0.5) {
		report.push(`UV outside the texture: ${uvOutsideShare}% — `
			+ (keepSinglePolyTexture ? 'preserved as repeating Poly Mesh UVs' : 'glTF sampler tiling was baked into the atlas'));
	}

	const custom = Number((opts && opts.scale_custom) || 0);
	const autoScale = pickScale(sizeUnits, density);
	const chosenScale = custom > 0
		? custom
		: (opts && opts.scale_mode && opts.scale_mode !== 'auto')
			? Number(opts.scale_mode)
			: autoScale;

	report.push(`Coordinate scale: ${chosenScale}`
		+ (custom > 0 ? ' (set manually)' : density > 0 ? ` (from texel density ${density.toFixed(2)})` : '')
		+ ` — bounds ${sizeUnits.toFixed(2)} units → ${(sizeUnits * chosenScale).toFixed(1)} px`);
	// Auto-detection relies on conventions, and those do not always hold.
	// Neighbouring options are shown so a manual choice can be an informed one.
	report.push('  other options: ' + [chosenScale * 4, chosenScale * 2, chosenScale / 2, chosenScale / 4]
		.map(c => `×${c} → ${(sizeUnits * c).toFixed(0)} px`).join(', '));

	// Centre it the Minecraft way: X and Z to zero, the bottom on the ground.
	// The bounds are already in glTF units, so we simply multiply.
	// Centring used to be OFF by default: a model may have a meaningful position
	// relative to the origin, and moving it unasked is wrong. The offset is
	// computed and printed regardless, so it is visible whether turning it on
	// makes sense.
	let offset = [0, 0, 0];
	const wouldOffset = [
		-((lo[0] + hi[0]) / 2) * chosenScale,
		-lo[1] * chosenScale,
		-((lo[2] + hi[2]) / 2) * chosenScale,
	];
	if (opts && opts.recenter) {
		offset = wouldOffset;
		report.push(`Model moved to centre by [${offset.map(v => v.toFixed(1)).join(', ')}] px`);
	} else if (wouldOffset.some(v => Math.abs(v) > 1)) {
		report.push(`Model sits off-centre by [${wouldOffset.map(v => v.toFixed(1)).join(', ')}] px`);
		report.push('  enable Centre the model if that is a problem');
	}

	// Licence: most downloadable models require attribution, and losing that
	// information during import is not acceptable.
	const licenseKey = Object.keys(files).find(n => /license[.]txt$/i.test(n));
	if (licenseKey) {
		const text = new TextDecoder().decode(files[licenseKey]).trim();
		report.push('Licence from the archive:');
		for (const l of text.split(String.fromCharCode(10)).map(x => x.trim()).filter(Boolean).slice(0, 4)) {
			report.push('  ' + l);
		}
	}

	const parsed = parseGLTFFiles(files, {
		scale: chosenScale, offset, rotate,
		uvWidth: size.width, uvHeight: size.height,
		// The rectangles are converted to glTF image numbering. Besides the atlas
		// rectangle we keep the ORIGINAL image dimensions and the first baked tile:
		// UV -0.7 must mean "70% through tile -1", not -70% of the whole atlas.
		uvRects: sized.map((img, i) => {
			const ai = remap[i] >= 0 ? remap[i] : mainIndex;
			const r = layout.rects[ai];
			const s = tileSpecs[ai];
			return {
				...r,
				sourceW: s.sourceW,
				sourceH: s.sourceH,
				tileMinU: s.minTileU,
				tileMinV: s.minTileV,
			};
		}),
	});
	if (rotate.some(v => v)) report.push(`Extra rotation: X ${rotate[0]}°, Y ${rotate[1]}°`);

	// What came out of the export wrapper gets its own line rather than sitting
	// among warnings: if a model arrives lying down, that is the first thing to know.
	const wrapNotes = parsed.warnings.filter(w => w.indexOf('wrapper') >= 0);
	if (wrapNotes.length) {
		report.push('Export wrapper:');
		for (const w of wrapNotes) report.push('  ' + w);
	}

	const geometryMode = requestedGeometryMode;
	if (geometryMode === 'poly_mesh') {
		return buildPolyMeshProject({
			parsed, sourceName, report, images, layout, tileSpecs, size,
			chosenScale, needAtlas, opts,
			previewWrap: keepSinglePolyTexture ? {
				modeS: tileSpecs[0].modeS,
				modeT: tileSpecs[0].modeT,
			} : null,
		});
	}

	// A skinned glTF mesh can contain the body, lid, latch, etc. in ONE primitive.
	// GeckoLib animation works by parenting cubes to bones, so split first by the
	// dominant skin joint recorded on each face (and by material image), then split
	// each bucket into connected cube components.
	const split = [];
	let splitCount = 0;
	let skinBuckets = 0;
	for (const obj of parsed.objects) {
		const buckets = new Map();
		for (const face of obj.faces) {
			const boneNode = face.boneNode === undefined ? obj.node : face.boneNode;
			const image = face.image === undefined ? obj.image : face.image;
			const key = `${boneNode}|${image}`;
			if (!buckets.has(key)) buckets.set(key, { boneNode, image, faces: [] });
			buckets.get(key).faces.push(face);
		}
		if (buckets.size > 1) skinBuckets += buckets.size;

		let bucketIndex = 0;
		for (const bucket of buckets.values()) {
			const parts = splitComponents(bucket.faces);
			if (parts.length > 1) splitCount++;
			const boneInfo = parsed.hierarchy.find(h => h.index === bucket.boneNode);
			const boneSuffix = buckets.size > 1 && boneInfo ? `_${boneInfo.name}` : '';
			parts.forEach((faces, i) => split.push({
				...obj,
				node: bucket.boneNode,
				image: bucket.image,
				name: `${obj.name}${boneSuffix}${parts.length > 1 ? `_${i + 1}` : ''}`,
				faces,
			}));
			bucketIndex++;
		}
	}
	parsed.objects = split;
	if (skinBuckets) {
		report.push(`Skinned mesh separated by bone/material: ${skinBuckets} buckets`);
	}
	if (splitCount) {
		report.push(`Merged meshes split into connected cubes: ${split.length} objects`);
	}

	// Step 1. Check ALL the geometry before creating anything: the user must not
	// end up with a half-built project. Only the box/not-a-box verdict matters
	// here; it does not depend on the UV convention, so the layout result is NOT
	// taken from this pass.
	// Objects are sorted into three buckets. A single bad object used to cancel
	// the whole import — the journal shows that for six models out of forty
	// exactly one object was in the way, and the whole model was lost.
	const badMode = (opts && opts.bad_objects) || 'box';
	const notBoxes = [];
	const skipped = [];
	let degenerate = 0;
	for (const obj of parsed.objects) {
		if (isDegenerate(obj.faces)) { degenerate++; obj.drop = true; continue; }
		const sol = solveBox(obj.faces);
		if (!sol.error) continue;
		notBoxes.push(`${obj.name}: ${sol.error}`);
		if (badMode === 'abort') continue;
		obj.bad = true;
		if (badMode === 'skip') { obj.drop = true; skipped.push(obj.name); }
	}
	parsed.objects = parsed.objects.filter(o => !o.drop);
	if (degenerate) report.push(`Degenerate fragments dropped: ${degenerate}`);
	if (notBoxes.length) {
		report.push(`Not boxes: ${notBoxes.length} — `
			+ (badMode === 'skip' ? 'skipped' : badMode === 'box' ? 'replaced with their bounding box' : 'import cancelled'));
		for (const n of notBoxes.slice(0, 5)) report.push('  ' + n);
	}
	if (notBoxes.length && badMode === 'abort') {
		Blockbench.showMessageBox({
			title: 'This model is not made of cubes',
			message: `Could not represent ${notBoxes.length} of ${parsed.objects.length} objects as cubes.\n\n`
				+ notBoxes.slice(0, 12).join('\n')
				+ (notBoxes.length > 12 ? `\n…and ${notBoxes.length - 12} more` : '')
				+ '\n\nSupport for arbitrary geometry (voxelisation) is not implemented yet.',
		});
		return;
	}

	newProject(Formats.geckolib_model);
	Project.name = (sourceName || 'model').replace(/\.[^.]*$/, '');
	// IMPORTANT: geckolib_model defaults to box_uv = true, while we need per-face
	// UV, otherwise Blockbench re-unwraps them and the layout is lost.
	Project.box_uv = false;
	Project.texture_width = size.width;
	Project.texture_height = size.height;

	// One texture per project, as GeckoLib requires.
	// Redrawing is not only for the atlas: Blockbench stores textures as PNG, and
	// a Sketchfab JPEG must first go through a canvas, or it lands in the project
	// labelled png and fails to open.
	const needRedraw = needAtlas || (images[0].mime && images[0].mime !== 'image/png');
	const atlasTexture = new Texture({ name: needAtlas ? 'atlas.png' : (images[0].name || 'texture.png').replace(/\.[^.]*$/, '.png') });
	if (needRedraw) {
		atlasTexture.add();
		// the content is filled in once the images decode
		buildAtlasDataURL(images, layout, tileSpecs).then(url => {
			if (url) atlasTexture.fromDataURL(url);
			Canvas.updateAll();
		});
	} else {
		atlasTexture.fromDataURL('data:' + (images[0].mime || 'image/png') + ';base64,' + bytesToBase64(images[0].bytes)).add();
	}

	// Step 2. Measure Blockbench conventions — that needs a live project.
	detectEulerOrder();
	const calibration = calibrateFaceDirs();

	// Step 3. Only NOW is the final UV layout computed.
	// The order matters: solveBox relies on FACE_DIRS, and computing before
	// calibration lays everything out by the fallback table — exactly the
	// 180°-rotated-texture bug already caught once.
	const solved = [];
	let approximated = 0;
	for (const obj of parsed.objects) {
		const sol = solveBox(obj.faces);
		if (!sol.error) { solved.push({ obj, sol }); continue; }
		if (badMode !== 'box') continue;
		const approx = boxFromBounds(obj.faces);
		if (approx) { solved.push({ obj, sol: approx }); approximated++; }
	}
	// The approximation share is the only honest measure of result quality.
	// Without it the import succeeded even on models that turned out to be almost
	// entirely wedges and bevels: the project opened, looked like mush, and there
	// was no way to tell why. Better to say plainly that the model does not fit.
	const approxShare = solved.length ? Math.round(100 * approximated / solved.length) : 0;
	if (approximated) {
		report.push(`Approximated with a bounding box: ${approximated} of ${solved.length} (${approxShare}%)`);
		report.push(approxShare >= 30
			? '  WARNING: this model is mostly NOT cube-based — wedges, bevels, rounded shapes. '
				+ 'Such objects lose their shape, so the result is only approximate.'
			: '  Approximated objects lost their shape, but their texture is laid out per face.');
	}

	// bones: the hierarchy is walked in order, a parent always before its child
	const groupByNode = {};
	for (const h of parsed.hierarchy) {
		const g = new Group({ name: h.name, origin: preciseBonePivot(h.pivot) }).init();
		if (h.parent >= 0 && groupByNode[h.parent]) g.addTo(groupByNode[h.parent]);
		groupByNode[h.index] = g;
	}

	// Cubes that landed in one plane are separated in depth via inflate:
	// otherwise the GPU cannot decide which face is nearer and the model
	// flickers. Coordinates stay clean throughout.
	const wantZFight = !opts || opts.zfight !== false;
	const coplanar = wantZFight
		? resolveCoplanar(solved.map(s => s.sol))
		: { inflate: solved.map(() => 0), pairs: 0, capped: 0, skipped: 0 };
	if (coplanar.skipped) {
		report.push(`Coplanar face separation skipped: ${coplanar.skipped} objects — too many`);
	}
	if (coplanar.capped) {
		report.push(`  layers that hit the inflate ceiling: ${coplanar.capped} — flicker may remain there`);
	}
	if (coplanar.pairs) {
		report.push(`Coplanar faces separated: ${coplanar.pairs} `
			+ '(via Inflate, coordinates untouched)');
	}

	let hidden = 0, mirrored = 0, untextured = 0;
	for (let si = 0; si < solved.length; si++) {
		const { obj, sol } = solved[si];
		if (obj.image < 0) untextured++;
		const cube = cubeFromSolution(obj.name, sol, atlasTexture.uuid, coplanar.inflate[si]);
		const parent = groupByNode[obj.node];
		if (parent) cube.addTo(parent);
		cube.init();
		hidden += sol.emptyFaces.length;
		mirrored += sol.mirrored ? 1 : 0;
	}

	const lines = [
		`Imported from: ${sourceName}`,
		// facts gathered before the project existed (scale, textures)
		...report,
		`Cubes created: ${solved.length}`,
		`Bones created: ${parsed.hierarchy.length}`,
		parsed.bindPivotStats && parsed.bindPivotStats.overrides
			? `Bone pivots: ${parsed.bindPivotStats.overrides} skinned joint(s) reconstructed from inverse bind matrices; max correction ${parsed.bindPivotStats.maxCorrection.toFixed(3)} px${parsed.bindPivotStats.worstBone ? ` on “${parsed.bindPivotStats.worstBone}”` : ''}`
			: 'Bone pivots: exact glTF node positions (no usable inverse bind matrices)',
		`Texture: ${size.width}×${size.height}`,
		`Objects without a material: ${untextured}`,
		`Faces hidden: ${hidden}`,
		`Mirrored cubes: ${mirrored}`,
	];
	// A failure in animations must not bring down the whole import: cubes and
	// texture are already built, and losing them over animations makes no sense.
	try {
		applyAnimations(parsed, groupByNode, lines, opts);
	} catch (e) {
		console.error('[geckolib-import] animation transfer failed', e);
		lines.push('', `ANIMATIONS WERE NOT TRANSFERRED: ${(e && e.message) || e}`,
			'The model and texture were still built correctly.');
	}
	if (parsed.warnings.length) lines.push('', 'Warnings:', ...parsed.warnings.slice(0, 8));
	lines.push('', calibration);

	Canvas.updateAll();
	console.log('[geckolib-import] import\n' + lines.join('\n'));
	// Everything worked out along the way is handed back: the CPM branch needs the
	// very same hierarchy, boxes and texture, and re-deriving them would mean a
	// second copy of the scale and atlas logic that could drift from this one.
	lastImport = {
		parsed, solved, images, layout, size, chosenScale, sourceName,
		texture: atlasTexture,
		needAtlas,
	};
	showImportReport({
		title: 'Import finished',
		summary: [
			['Cubes', String(solved.length)],
			['Bones', String(parsed.hierarchy.length)],
			['Texture', `${size.width}×${size.height}`],
			['Animations', String(parsed.animations.length)],
			['Scale', `×${chosenScale}`],
		].concat(approximated
			? [['Approximated', `${approximated} of ${solved.length} (${approxShare}%)`]]
			: []),
		warning: approxShare >= 30
			? 'This model is mostly not cube-based: wedges and bevels became boxes, so shape was lost.'
			: null,
		log: lines.join('\n'),
		name: (sourceName || 'model').replace(/\.[^.]*$/, ''),
	});
	return lastImport;
}

/**
 * The import summary: the gist up front, details behind a scroll, the log as a file.
 *
 * showMessageBox neither scrolls nor wraps long lines: a forty-line report ran
 * off the edges of the window and could not be read. The details are needed
 * though — breakages are diagnosed from them — so they stay, but stop getting in
 * the way of anyone who only wants to know how many cubes came out.
 */
function showImportReport(info) {
	const esc = s => String(s).replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
	const rows = info.summary
		.map(([k, v]) => `<div class="mtc_rep_k">${esc(k)}</div><div class="mtc_rep_v">${esc(v)}</div>`)
		.join('');

	const dialog = new Dialog({
		id: PLUGIN_ID + '_report',
		title: info.title,
		buttons: ['Done'],
		onConfirm() { this.hide(); },
		lines: [
			'<style>'
			+ '.mtc_rep_grid { display: grid; grid-template-columns: max-content 1fr; gap: 4px 14px; margin-bottom: 12px; }'
			+ '.mtc_rep_k { opacity: 0.7; }'
			+ '.mtc_rep_v { font-weight: 600; }'
			+ '.mtc_rep_warn { border-left: 3px solid var(--color-warning, #d9a441); padding: 6px 10px;'
			+ '  margin-bottom: 12px; background: rgba(217,164,65,0.12); }'
			+ '.mtc_rep_log { max-height: 320px; overflow: auto; white-space: pre-wrap; word-break: break-word;'
			+ '  font-family: var(--font-code, monospace); font-size: 11px; line-height: 1.45;'
			+ '  background: var(--color-back, #21252b); padding: 8px; border-radius: 4px; }'
			+ '.mtc_rep_bar { display: flex; gap: 8px; align-items: center; margin-top: 10px; }'
			+ '</style>'
			+ `<div class="mtc_rep_grid">${rows}</div>`
			+ (info.warning ? `<div class="mtc_rep_warn">${esc(info.warning)}</div>` : '')
			+ '<details><summary style="cursor:pointer;margin-bottom:8px">Import details</summary>'
			+ `<div class="mtc_rep_log">${esc(info.log)}</div>`
			+ '<div class="mtc_rep_bar">'
			+ '<button class="mtc_rep_save">Save log…</button>'
			+ '<button class="mtc_rep_copy">Copy</button>'
			+ '<span class="mtc_rep_said" style="opacity:0.7"></span>'
			+ '</div></details>',
		],
	});
	dialog.show();

	const root = dialog.object || document;
	const said = root.querySelector('.mtc_rep_said');
	const tell = t => { if (said) said.textContent = t; };

	const save = root.querySelector('.mtc_rep_save');
	if (save) {
		save.addEventListener('click', () => {
			try {
				Blockbench.export({
					type: 'Text log',
					extensions: ['txt'],
					name: `${info.name || 'import'}-log`,
					content: info.log,
				});
			} catch (e) {
				tell('could not save: ' + ((e && e.message) || e));
			}
		});
	}
	const copy = root.querySelector('.mtc_rep_copy');
	if (copy) {
		copy.addEventListener('click', () => {
			// The clipboard can be unavailable in a sandbox — then say so honestly
			// instead of silently doing nothing.
			try {
				navigator.clipboard.writeText(info.log).then(
					() => tell('copied'),
					() => tell('clipboard unavailable — save to a file instead'));
			} catch (e) {
				tell('clipboard unavailable — save to a file instead');
			}
		});
	}
}

// ------------------------------------------------------- Sketchfab browser

const SKETCHFAB_API = 'https://api.sketchfab.com/v3';
const SKETCHFAB_TOKEN_KEY = PLUGIN_ID + '_sketchfab_token';

function sketchfabToken(value) {
	try {
		if (value !== undefined) localStorage.setItem(SKETCHFAB_TOKEN_KEY, value || '');
		return localStorage.getItem(SKETCHFAB_TOKEN_KEY) || '';
	} catch (e) {
		return '';
	}
}

/**
 * Model search. No token needed — the endpoint is public.
 *
 * Only downloadable models are searched: the rest cannot be fetched anyway, and
 * showing them would only raise false expectations.
 */
function sketchfabSearch(query) {
	const params = [
		'type=models',
		'downloadable=true',
		'archives_flavours=false',
		'count=24',
		'q=' + encodeURIComponent(query || ''),
	];
	return sketchfabFetchPage(SKETCHFAB_API + '/search?' + params.join('&'));
}

/** Loads a page of results. The `next` field already holds a ready URL. */
function sketchfabFetchPage(url) {
	return fetch(url).then(r => {
		if (!r.ok) throw new Error('search returned HTTP ' + r.status);
		return r.json();
	});
}

/**
 * Downloads a model and returns the unpacked files.
 *
 * The archive link is temporary, so it is fetched immediately. Its layout is
 * exactly what the import already parses: scene.gltf, scene.bin, textures/.
 */
function sketchfabDownload(uid, onProgress) {
	const token = sketchfabToken();
	if (!token) return Promise.reject(new Error('no API token set'));

	onProgress && onProgress('requesting link…');
	return fetch(SKETCHFAB_API + '/models/' + uid + '/download', {
		headers: { Authorization: 'Token ' + token },
	}).then(r => {
		if (r.status === 401) throw new Error('token rejected (401)');
		if (r.status === 403) throw new Error('no permission to download this model (403)');
		if (!r.ok) throw new Error('HTTP ' + r.status);
		return r.json();
	}).then(info => {
		const src = info.gltf || info.glb;
		if (!src || !src.url) throw new Error('the response has no glTF link');
		onProgress && onProgress('downloading archive…');
		return fetch(src.url);
	}).then(r => {
		if (!r.ok) throw new Error('archive returned HTTP ' + r.status);
		return r.arrayBuffer();
	}).then(buf => {
		onProgress && onProgress('unpacking…');
		return JSZip.loadAsync(buf);
	}).then(zip => {
		const entries = {};
		const tasks = [];
		zip.forEach((relPath, entry) => {
			if (entry.dir) return;
			tasks.push(entry.async('uint8array').then(data => { entries[relPath] = data; }));
		});
		return Promise.all(tasks).then(() => entries);
	});
}

/** Browser styles: custom markup does not inherit Blockbench styling. */
let sketchfabCSS = null;
function addSketchfabStyles() {
	if (sketchfabCSS || typeof Blockbench.addCSS !== 'function') return;
	sketchfabCSS = Blockbench.addCSS(`
		.mtc_sf_bar { display: flex; gap: 6px; margin-bottom: 8px; }
		.mtc_sf_bar input { flex: 1; }
		.mtc_sf_status { margin: 4px 0; opacity: 0.8; min-height: 18px; }
		.mtc_sf_results { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
			gap: 8px; max-height: 380px; overflow-y: auto; }
		.mtc_sf_card { border: 1px solid var(--color-border); border-radius: 4px;
			padding: 4px; cursor: pointer; font-size: 11px; }
		.mtc_sf_card:hover { background-color: var(--color-selected); }
		.mtc_sf_card img { width: 100%; aspect-ratio: 16/9; object-fit: cover; border-radius: 2px;
			background: var(--color-back); }
		.mtc_sf_more { display: flex; align-items: center; justify-content: center;
			min-height: 90px; font-weight: bold; }
		.mtc_sf_name { font-weight: bold; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
		.mtc_sf_meta { opacity: 0.7; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
	`);
}

/**
 * The Sketchfab browser: search and download straight from Blockbench.
 *
 * Only downloadable models are shown, always with author and licence: nearly
 * all of them require attribution, and that must not be lost.
 */
function openSketchfabBrowser() {
	if (typeof fetch !== 'function') {
		Blockbench.showMessageBox({ title: 'No network', message: 'This Blockbench build has no fetch available.' });
		return;
	}
	if (typeof JSZip === 'undefined') {
		Blockbench.showMessageBox({ title: 'JSZip missing', message: 'Nothing available to unpack the archive.' });
		return;
	}
	addSketchfabStyles();

	const dialog = new Dialog({
		id: PLUGIN_ID + '_sketchfab',
		title: 'Sketchfab — model search',
		width: 760,
		lines: [
			'<div class="mtc_sf_bar">'
			+ '<input type="text" class="dark_bordered mtc_sf_query" placeholder="search for, e.g.: dwarf house">'
			+ '<button class="mtc_sf_find">Search</button>'
			+ '<button class="mtc_sf_token">Token…</button>'
			+ '</div>'
			+ '<div class="mtc_sf_status"></div>'
			+ '<div class="mtc_sf_results"></div>',
		],
		singleButton: true,
	});
	dialog.show();

	const root = document.querySelector('.dialog#' + PLUGIN_ID + '_sketchfab') || document;
	const q = root.querySelector('.mtc_sf_query');
	const status = root.querySelector('.mtc_sf_status');
	const results = root.querySelector('.mtc_sf_results');
	const say = t => { if (status) status.textContent = t; };

	const askToken = () => {
		new Dialog({
			id: PLUGIN_ID + '_sf_token',
			title: 'Sketchfab token',
			form: {
				token: { label: 'API token', type: 'text', value: sketchfabToken() },
				hint: {
					type: 'info',
					text: 'A token is only needed for downloads; search works without one. '
						+ 'You can get one in your Sketchfab profile settings, under Password & API. '
						+ 'Only models the author allowed to be downloaded can be fetched.',
				},
			},
			onConfirm(form) { sketchfabToken(form.token.trim()); this.hide(); say('token saved'); },
		}).show();
	};

	const importModel = model => {
		// Check the format BEFORE downloading: fetching tens of megabytes only to
		// then say there is nothing to build into is a bad deal.
		if (!requireGeckolib()) return;
		say('preparing ' + model.name + '…');
		sketchfabDownload(model.uid, say)
			.then(entries => {
				say('unpacked, asking for settings…');
				dialog.hide();
				askImportOptions(opts => {
					const built = buildFromFiles(entries, model.name || 'sketchfab', opts);
					// attribution is always printed, even without a license.txt in the archive
					console.log('[geckolib-import] Sketchfab: «' + model.name + '» — '
						+ ((model.user && model.user.displayName) || '?') + ', '
						+ ((model.license && model.license.label) || 'licence not stated'));
					return built;
				});
			})
			.catch(e => say('failed: ' + ((e && e.message) || e)));
	};

	let nextUrl = null;
	let shown = 0;
	let hiddenNoGltf = 0;

	const render = (data, append) => {
		if (!results) return;
		if (!append) { results.innerHTML = ''; shown = 0; }
		const raw = data.results || [];
		nextUrl = data.next || null;

		// Keep only models with a glTF autoconversion. For some, the download is
		// merely the author's source (.blend, .fbx), which nothing here can open,
		// and such cards used to look usable right up until the import was tried.
		const list = raw.filter(hasGltfArchive);
		hiddenNoGltf += raw.length - list.length;

		if (!list.length && !append) {
			say(hiddenNoGltf
				? `nothing found (hidden without glTF: ${hiddenNoGltf})`
				: 'nothing found');
			return;
		}
		shown += list.length;
		say('shown: ' + shown + (nextUrl ? ' (more available)' : ' — that is all')
			+ (hiddenNoGltf ? ` · hidden without glTF: ${hiddenNoGltf}` : ''));
		for (const m of list) {
			const thumbs = (m.thumbnails && m.thumbnails.images) || [];
			// take the smallest preview at least 200 px wide: quick to load, still decent
			const sorted = thumbs.slice().sort((a, b) => a.width - b.width);
			const thumb = sorted.find(t => t.width >= 200) || sorted[sorted.length - 1];
			const card = document.createElement('div');
			card.className = 'mtc_sf_card';
			const NL = String.fromCharCode(10);
			card.title = (m.name || '') + NL + 'Author: ' + ((m.user && m.user.displayName) || '?')
				+ NL + 'Licence: ' + ((m.license && m.license.label) || '?');
			const kb = m.archives && m.archives.gltf ? Math.round(m.archives.gltf.size / 1024) : null;
			card.innerHTML =
				(thumb ? '<img src="' + thumb.url + '">' : '<img>')
				+ '<div class="mtc_sf_name"></div>'
				+ '<div class="mtc_sf_meta mtc_sf_author"></div>'
				+ '<div class="mtc_sf_meta mtc_sf_lic"></div>';
			// text goes through textContent: model names sometimes contain markup
			card.querySelector('.mtc_sf_name').textContent = m.name || '(unnamed)';
			card.querySelector('.mtc_sf_author').textContent = (m.user && m.user.displayName) || '';
			card.querySelector('.mtc_sf_lic').textContent =
				((m.license && m.license.label) || '') + (kb ? ' · ' + (kb > 1024 ? (kb / 1024).toFixed(1) + ' MB' : kb + ' KB') : '');
			card.addEventListener('click', () => importModel(m));
			results.appendChild(card);
		}
		// the more button stays the last tile so the grid is not broken
		const oldMore = results.querySelector('.mtc_sf_more');
		if (oldMore) oldMore.remove();
		if (nextUrl) {
			const more = document.createElement('div');
			more.className = 'mtc_sf_card mtc_sf_more';
			more.textContent = 'Show more';
			more.addEventListener('click', () => {
				const url = nextUrl;
				nextUrl = null;
				say('loading more…');
				sketchfabFetchPage(url)
					.then(d => render(d, true))
					.catch(e => say('error: ' + ((e && e.message) || e)));
			});
			results.appendChild(more);
		}
	};

	const doSearch = () => {
		say('searching…');
		sketchfabSearch(q ? q.value : '').then(render).catch(e => say('search error: ' + ((e && e.message) || e)));
	};

	if (root.querySelector('.mtc_sf_find')) root.querySelector('.mtc_sf_find').addEventListener('click', doSearch);
	if (root.querySelector('.mtc_sf_token')) root.querySelector('.mtc_sf_token').addEventListener('click', askToken);
	if (q) {
		// Blockbench treats Enter in a dialog as confirmation and closes the window,
		// so the event must be stopped before it bubbles.
		q.addEventListener('keydown', e => {
			if (e.key !== 'Enter') return;
			e.preventDefault();
			e.stopPropagation();
			doSearch();
		});
	}
	say(sketchfabToken() ? 'token set — you can search and download' : 'no token: search works, press Token… to enable downloads');
}

/**
 * Asks for the import settings.
 *
 * Kept separate: the same dialog serves both the file import and downloads from
 * the Sketchfab browser.
 */
function askImportOptions(onReady) {
	// Visibility rule: advanced fields appear once the checkbox is ticked.
	const adv = form => !!form.advanced;

	new Dialog({
		id: PLUGIN_ID + '_import_dialog',
		title: 'Import GeckoLib from ZIP',
		// Expanded by a checkbox: an ordinary user needs four settings, the other
		// eight are levers for diagnosing breakage. Eleven fields in a row read like
		// a cockpit and get in the way of anyone who just wants to open a model.
		form: {
			scale_mode: {
				label: 'Model size', type: 'select', default: 'auto',
				options: { auto: 'Detect automatically', 16: '×16 (unit = block)', 1: '×1 (unit = pixel)' },
			},
			geometry_mode: {
				label: 'Geometry', type: 'select', default: 'cubes',
				options: {
					cubes: 'Cubes (current / compatible)',
					poly_mesh: 'Poly Mesh (preserve glTF triangles)',
				},
			},
			poly_hint: {
				type: 'info', condition: form => form.geometry_mode === 'poly_mesh',
				text: 'Poly Mesh keeps the original glTF shape instead of converting it to boxes. '
					+ 'It exports Bedrock poly_mesh data directly from this plugin; no Meshy plugin is required. '
					+ 'Note: stock GeckoLib Java currently parses poly_mesh but does not render it, so your mod renderer/loader must support it.',
			},
			geckomesh_runtime: {
				label: 'GeckoMesh runtime', type: 'select', default: '1_1_plus',
				condition: form => form.geometry_mode === 'poly_mesh',
				options: {
					'1_1_plus': '1.1+ — current/default (runtime flips X)',
					'1_0': '1.0 — legacy CurseMaven converter',
				},
			},
			geckomesh_runtime_hint: {
				type: 'info',
				condition: form => form.geometry_mode === 'poly_mesh',
				text: '1.1+ is the default. Use 1.0 only with the older CurseMaven converter. Choosing the wrong runtime version mirrors '
					+ 'the mesh in-game and makes bone animations appear incorrect even when Blockbench is right.',
			},
			skinning_mode: {
				label: 'Smooth skinning', type: 'select', default: 'native',
				condition: form => form.geometry_mode === 'poly_mesh',
				options: {
					native: 'CS2LootBox native weighted skinning — exact (recommended)',
					auto: 'GeckoMesh approximation — preserve body + segment bone chains',
					continuous: 'GeckoMesh approximation — keep every blended component rigid',
					dominant: 'GeckoMesh approximation — split by dominant joint (legacy)',
				},
			},
			skinning_mode_hint: {
				type: 'info',
				condition: form => form.geometry_mode === 'poly_mesh',
				text: 'Native weighted skinning preserves the original glTF JOINTS_0/WEIGHTS_0 inside the exported .geo.json. The CS2LootBox Forge renderer then skins those vertices from GeckoLib’s live animated bones. '
					+ 'The other modes remain as rigid GeckoMesh approximations for projects that do not use the updated renderer.',
			},
			weighted_skin_preview: {
				label: 'Preview native skinning in Blockbench', type: 'checkbox', value: true,
				condition: form => form.geometry_mode === 'poly_mesh' && form.skinning_mode === 'native',
			},
			weighted_skin_preview_hint: {
				type: 'info',
				condition: form => form.geometry_mode === 'poly_mesh' && form.skinning_mode === 'native' && form.weighted_skin_preview !== false,
				text: 'The viewport will deform the intact weighted mesh from the animated GeckoLib bone groups while you scrub or play the timeline. This is preview-only: bind-pose vertices and exported JOINTS_0/WEIGHTS_0 are never modified.',
			},
			recenter: { label: 'Centre the model and place it on the ground', type: 'checkbox', value: true },
			rot_x: {
				label: 'Extra rotation around X', type: 'select', default: '0',
				options: { 0: 'none', '-90': '−90° (model lies face up)', 90: '+90°', 180: '180°' },
			},
			rot_y: {
				label: 'Extra rotation around Y', type: 'select', default: '90',
				options: { 0: 'none', 90: '90°', 180: '180° (faces backwards)', 270: '270°' },
			},
			animations: { label: 'Transfer animations', type: 'checkbox', value: true },
			animation_loop_mode: {
				label: 'Animation looping', type: 'select', default: 'auto',
				condition: form => form.animations !== false,
				options: {
					auto: 'Auto — idle/walk/run/etc. loop; actions play once',
					once: 'Play all non-pose animations once',
					loop: 'Loop all non-pose animations',
				},
			},
			animation_accuracy_preset: {
				label: 'Animation accuracy', type: 'select', default: 'ultra',
				condition: form => form.animations !== false,
				options: {
					ultra: 'Ultra — 120 FPS bake (recommended for CS2 cases)',
					high: 'High — 60 FPS bake',
					balanced: 'Balanced — 30 FPS bake',
					exact: 'Exact — 240 FPS bake, minimal rounding',
					original: 'Original glTF key times only',
				},
			},
			animation_accuracy_hint: {
				type: 'info',
				condition: form => form.animations !== false,
				text: 'Ultra/Exact bake dense rotation + position keys so GeckoLib in-game matches Blockbench as closely as possible. '
					+ 'Exact is the closest, but it creates the biggest animation JSON.',
			},

			advanced: { label: 'Advanced settings', type: 'checkbox', value: false },

			adv_hint: {
				type: 'info', condition: adv,
				text: 'Below are the levers for when a model does not arrive as expected. '
					+ 'Change them one at a time: turning several at once makes it impossible to tell '
					+ 'what actually helped.',
			},
			scale_custom: {
				label: 'Custom scale (0 = unset)', type: 'number',
				value: 8, min: 0, max: 64, step: 0.05, condition: adv,
			},
			bad_objects: {
				label: 'Objects that are not cubes', type: 'select', default: 'box', condition: adv,
				options: {
					box: 'Approximate with a bounding box',
					skip: 'Skip them',
					abort: 'Cancel the import',
				},
			},
			positions: {
				label: 'Position channels in animations', type: 'select', default: 'big', condition: adv,
				options: {
					big: 'Larger than the threshold',
					rt: 'All, with rotation pre-compensation',
					model: 'All',
					skip: 'Do not transfer',
					local: 'All, without conjugation',
					absolute: 'Absolute value (bones fly upwards)',
				},
			},
			pos_threshold: {
				label: 'Position threshold, px', type: 'number',
				value: 0, min: 0, max: 30, step: 0.1, condition: adv,
			},
			align_times: {
				label: 'Align keyframe times', type: 'checkbox', value: false, condition: adv,
			},
			zfight: {
				label: 'Separate coplanar faces (anti-flicker)', type: 'checkbox',
				value: true, condition: adv,
			},
			anim_order: {
				label: 'Rotation formula', type: 'select', default: 'post', condition: adv,
				options: { post: 'R(t)·R0⁻¹ (default)', pre: 'R0⁻¹·R(t) (if animations drift apart)' },
			},
			hint: {
				type: 'info', condition: adv,
				text: 'The maths gives exactly two exact options: All — if Blockbench adds the offset '
					+ 'outside the rotation, and pre-compensated — if inside. '
					+ 'If bones drift apart in an animation, raise the position threshold to 2 px: '
					+ 'small offsets are then dropped, which is a known-good state.',
			},
		},
		onConfirm(form) { this.hide(); onReady(form); },
	}).show();
}

/**
 * Whether the GeckoLib format exists. That plugin installs separately, and
 * without it there is nothing to build a project into.
 *
 * The dependency is deliberately soft: the mesh-to-cube converter is useful on
 * its own, so the plugin always loads and the check sits where the format is
 * actually needed — at the entrance to the import.
 */
function geckolibAvailable() {
	return typeof Formats !== 'undefined' && !!Formats.geckolib_model;
}

function requireGeckolib() {
	if (geckolibAvailable()) {
		enableGeckoMeshEditing();
		installPolyMeshExporter();
		installWeightedSkinPreview();
		return true;
	}
	new Dialog({
		id: PLUGIN_ID + '_need_geckolib',
		title: 'GeckoLib plugin required',
		buttons: ['Open plugin list', 'Cancel'],
		lines: [
			'<p>The import builds a project in the <b>GeckoLib Animated Model</b> format, '
			+ 'which comes from a separate plugin — and it is not installed right now.</p>'
			+ '<p style="opacity:0.75">Install <b>GeckoLib Animation Utils</b> from '
			+ 'File → Plugins and run the import again. Converting an already-open model '
			+ 'from meshes to cubes (Filter menu) works without it.</p>',
		],
		onConfirm() {
			this.hide();
			// Different builds open the plugin list differently, so both routes are
			// tried and neither failing is reported.
			try {
				if (typeof Plugins !== 'undefined' && Plugins.dialog) Plugins.dialog.show();
				else if (typeof BarItems !== 'undefined' && BarItems.plugins_window) BarItems.plugins_window.click();
			} catch (e) { /* not critical: the user can open it manually */ }
		},
		onCancel() { this.hide(); },
	}).show();
	return false;
}

function importFromZip() {
	if (typeof JSZip === 'undefined') {
		Blockbench.showMessageBox({ title: 'JSZip missing', message: 'This Blockbench build has no JSZip, so archives cannot be unpacked.' });
		return;
	}
	if (!requireGeckolib()) return;
	askImportOptions(opts => pickAndImport(opts));
}

// ------------------------------------------------- CPM export from Blockbench

/**
 * Import a glTF archive and save it as a .cpmproject.
 *
 * The ordinary import runs first, in full. That is not a detour: the UV
 * convention is MEASURED from a live Blockbench (calibrateFaceDirs builds a
 * probe cube and reads its buffers), and without a project there is nothing to
 * measure it on — the fallback table would be used instead, which is exactly
 * the guessing that produced 180°-rotated textures once already.
 *
 * The side effect is welcome anyway: the project stays open, so the model can
 * be looked at and corrected before it goes into the game.
 */
function importCPMFromZip() {
	if (typeof JSZip === 'undefined') {
		Blockbench.showMessageBox({ title: 'JSZip missing', message: 'This Blockbench build has no JSZip, so archives cannot be unpacked.' });
		return;
	}
	// The GeckoLib format is needed even here, because the import builds its
	// project in it. Nothing in the CPM output depends on GeckoLib — that is a
	// rough edge of reusing the import whole, not a property of the format.
	if (!requireGeckolib()) return;
	askImportOptions(opts => {
		// CPM has no Bedrock poly_mesh equivalent; always build its intermediate
		// project as cubes even if Poly Mesh was selected in the dialog.
		opts.geometry_mode = 'cubes';
		pickAndImport(opts, built => {
		if (!built) return;
		askCPMOptions(built, form => saveCPMProject(built, form));
		});
	});
}

/**
 * The CPM dialog: how big the model should be, and which bone is which part of
 * the player.
 *
 * The size is its own setting and not the one the import ran at. CPM measures in
 * player pixels — 32 px tall — while a Sketchfab model arrives in whatever units
 * its author used, so one number cannot serve both formats.
 *
 * The mapping is offered rather than decided. A guess by name is filled in, and
 * on a model already rigged like a player it needs no corrections; on anything
 * else a silent guess would be worse than none.
 */
function askCPMOptions(built, onReady) {
	const hierarchy = built.parsed.hierarchy;
	const guess = cpmAutoAssign(hierarchy);

	// Only the bones worth asking about: the ones the guess spoke for, plus the
	// top of the tree. Thirty-two selects would be a cockpit, and the rest of the
	// bones inherit their parent's part anyway.
	const roots = hierarchy.filter(h => h.parent < 0).map(h => h.index);
	const candidates = hierarchy.filter(h => guess[h.index] || roots.includes(h.index)
		|| (h.parent >= 0 && roots.includes(h.parent)));

	const options = { '': 'inherit from parent' };
	for (const p of CPM_PART_NAMES) options[p] = p.replace('_', ' ');

	let height = 0;
	{
		let lo = Infinity, hi = -Infinity;
		for (const s of built.solved) {
			const half = Math.abs(s.sol.size[1]) / 2;
			lo = Math.min(lo, s.sol.center[1] - half);
			hi = Math.max(hi, s.sol.center[1] + half);
		}
		height = hi - lo;
	}

	const form = {
		cpm_height: {
			label: 'Model height in player pixels', type: 'number',
			value: 32, min: 1, max: 512, step: 1,
		},
		height_hint: {
			type: 'info',
			text: `A player is 32 px tall. The imported model measures ${height.toFixed(1)} px, `
				+ 'so the height set here decides how much it is scaled by.',
		},
		map_hint: {
			type: 'info',
			text: 'Every bone below becomes a part of the player. A bone left on '
				+ '"inherit" goes wherever its parent went, so only the joints need answering.',
		},
	};
	for (const h of candidates) {
		form['b_' + h.index] = {
			label: h.name, type: 'select',
			default: guess[h.index] || '',
			options,
		};
	}
	form.fallback = {
		label: 'Everything not covered above', type: 'select', default: 'body', options: (() => {
			const o = {};
			for (const p of CPM_PART_NAMES) o[p] = p.replace('_', ' ');
			return o;
		})(),
	};
	form.align = {
		label: 'Line the rig up with the player skeleton', type: 'checkbox', value: true,
	};
	form.align_hint = {
		type: 'info',
		text: 'Moves the whole model so the bones mapped above sit on the vanilla pivots. '
			+ 'Without it a model built off-centre — one with a tail, say — looks right standing '
			+ 'still and tears apart as soon as an arm moves, because vanilla turns each limb '
			+ 'about its own pivot.',
	};

	// Animations. A vanilla pose replaces what the player does in that state; a
	// gesture waits to be played on demand. Gesture is the safe default, so
	// anything the guess does not recognise ends up harmless rather than
	// overriding walking.
	const anims = built.parsed.animations || [];
	if (anims.length) {
		const poseOptions = { gesture: 'gesture (played on demand)', skip: 'do not transfer' };
		for (const p of CPM_POSE_OPTIONS) poseOptions[p] = 'pose: ' + p.toLowerCase().replace(/_/g, ' ');
		form.anim_hint = {
			type: 'info',
			text: `The archive has ${anims.length} animations. A pose replaces vanilla motion in that `
				+ 'state; a gesture is played on demand and changes nothing by itself.',
		};
		form.anim_fps = {
			label: 'Animation sampling, frames per second', type: 'number',
			value: 12, min: 2, max: 30, step: 1,
		};
		form.stop_vanilla = {
			label: 'Switch vanilla motion off on the parts we animate', type: 'checkbox', value: false,
		};
		form.stop_vanilla_hint = {
			type: 'info',
			text: 'Off by default, and deliberately. It stops the vanilla arm swing from landing on '
				+ 'top of the model\'s own walk — but the flag is per BODY PART, not per pose, so in '
				+ 'any state you have no animation for (falling, on a ladder, swinging a sword) that '
				+ 'part simply freezes. Turn it on only once the poses you actually use are covered.',
		};
		form.head_camera = {
			label: 'Head keeps following the camera', type: 'checkbox', value: false,
		};
		form.head_camera_hint = {
			type: 'info',
			text: 'Leave this off when the model brings its own animations. In Minecraft the head is '
				+ 'not attached to the body, so an animation that lays the character flat has to carry '
				+ 'the head across by itself — and the camera look rotation, applied on top about the '
				+ 'neck, then swings that offset and the head sails off the body. Turn it on for a '
				+ 'model with no animations of its own, where nothing competes.',
		};
		for (let i = 0; i < anims.length; i++) {
			form['a_' + i] = {
				label: anims[i].name, type: 'select',
				default: cpmAutoPose(anims[i].name),
				options: poseOptions,
			};
		}
	}

	new Dialog({
		id: PLUGIN_ID + '_cpm_dialog',
		title: 'Export to Customizable Player Models',
		form,
		onConfirm(f) {
			this.hide();
			const assign = {};
			for (const h of candidates) {
				const v = f['b_' + h.index];
				if (v) assign[h.index] = v;
			}
			const poses = {};
			for (let i = 0; i < anims.length; i++) poses[anims[i].name] = f['a_' + i] || 'gesture';
			onReady({
				assign,
				fallback: f.fallback,
				scale: height > 0 ? Number(f.cpm_height) / height : 1,
				align: f.align !== false,
				stopVanilla: anims.length ? f.stop_vanilla === true : false,
				// With no animations of its own there is nothing to compete with the
				// camera, so the head may as well keep following it.
				headCamera: anims.length ? f.head_camera === true : true,
				poses,
				fps: Number(f.anim_fps) || 12,
			});
		},
	}).show();
}

/** Builds the archive and hands it to Blockbench to save. */
function saveCPMProject(built, form) {
	const cubes = built.solved.map((s, i) => ({
		name: s.obj.name,
		node: s.obj.node,
		sol: s.sol,
		inflate: 0,
	}));
	// Nodes an animation moves keep their own element: collapsing one would leave
	// the animation nothing to turn.
	const animated = new Set();
	for (const a of built.parsed.animations) for (const ch of a.channels) animated.add(ch.node);

	const uv = cpmUVScale(cubes, 16, Math.max(built.size.width, built.size.height));
	const align = form.align === false
		? [0, 0, 0]
		: cpmAlignOffset(built.parsed.hierarchy, form.assign, form.scale);
	const stopVanillaAnim = {};
	if (form.stopVanilla) {
		for (const p of CPM_PART_NAMES) if (p !== 'head') stopVanillaAnim[p] = true;
	}
	// The head is its own decision, and a consequential one.
	//
	// In Minecraft the head is NOT a child of the body: both hang off the player
	// origin, so tilting the body never moves the head. When an animation lays the
	// character flat — flying — the head has to be carried across by the animation
	// itself, and ours does compute that. But the vanilla look rotation is then
	// applied on top, about the head pivot at the neck, and it swings that whole
	// carried-across offset around: the head sails off the body.
	//
	// So with animations of its own, the model drives the head and it stays put.
	// The cost is that it no longer follows the camera.
	if (!form.headCamera) stopVanillaAnim.head = true;

	cpmSkinBytes(built).then(skin => {
		const out = buildCPMFiles({
			hierarchy: built.parsed.hierarchy,
			cubes,
			assign: form.assign,
			fallback: form.fallback,
			keepNodes: animated,
			scale: form.scale,
			align,
			stopVanillaAnim,
			uvMul: uv.mul,
			texWidth: built.size.width,
			texHeight: built.size.height,
			uvWidth: built.size.width * uv.mul,
			uvHeight: built.size.height * uv.mul,
			skin,
			name: (built.sourceName || 'model').replace(/\.[^.]*$/, ''),
			animations: built.parsed.animations,
			poses: form.poses,
			fps: form.fps,
			gltfScale: built.chosenScale,
		});

		const zip = new JSZip();
		for (const [name, data] of Object.entries(out.files)) zip.file(name, data);
		// Compressed, like CPM's own projects: animation frames are snapshots of
		// every moving bone, so the JSON is bulky and repetitive — exactly what
		// deflate is good at. Uncompressed this model came to 1.7 MB.
		return zip.generateAsync({ type: 'arraybuffer', compression: 'DEFLATE' }).then(buf => {
			const parts = Object.entries(out.stats.parts).filter(([, n]) => n > 0).map(([p]) => p);
			const lines = [
				`Cubes: ${out.stats.cubes}`,
				`Bones: ${out.stats.bones}`,
				`Player parts used: ${parts.join(', ') || 'none'}`,
				`Scale: ×${form.scale.toFixed(3)}`,
				`UV grid: ${built.size.width * uv.mul}×${built.size.height * uv.mul} (×${uv.mul}) `
					+ `over a ${built.size.width}×${built.size.height} texture`
					+ (uv.exact ? ', exact' : `, rounded by up to ${uv.worst.toFixed(3)} px`),
				`Animations: ${out.stats.anim.animations} of ${built.parsed.animations.length}, `
					+ `${out.stats.anim.frames} frames at ${form.fps} fps`,
				`Rig aligned to the player by [${align.map(v => v.toFixed(1)).join(', ')}] px (height untouched)`,
				`Vanilla motion: ${form.stopVanilla ? 'off on body, arms and legs' : 'on'}`
					+ `, head ${form.headCamera ? 'follows the camera' : 'driven by the model'}`,
			];
			// Worth spelling out: an unaligned model looks fine standing still and
			// tears itself apart the moment a limb moves.
			if (Math.max(...align.map(Math.abs)) > 4) {
				lines.push('  a shift this large means the model was not built around the player skeleton; '
					+ 'without it the limbs would swing about pivots far outside themselves');
			}
			// Which player states the model actually answers for. The gaps only bite
			// when vanilla motion is switched off, but then they bite hard.
			const covered = new Set(Object.values(form.poses || {}).filter(p => p !== 'gesture' && p !== 'skip'));
			const missing = CPM_MAIN_POSES.filter(p => !covered.has(p));
			lines.push(`Poses covered: ${[...covered].join(', ') || 'none'}`);
			if (missing.length) {
				lines.push(`  no animation for: ${missing.join(', ')}`);
				if (form.stopVanilla) {
					lines.push('  and vanilla motion is off, so in those states the model will stand frozen. '
						+ 'That is what the setting costs.');
				}
			}
			if (out.stats.anim.skipped.length) {
				lines.push(`  not transferred: ${out.stats.anim.skipped.join(', ')}`);
			}
			const kb = n => (n / 1024).toFixed(1) + ' kB';
			const size = out.stats.size;
			lines.push(`Encoded size, estimated: ${kb(size.total)} `
				+ `(model ${kb(size.cubes)}, animations ${kb(size.anim)}, texture ${kb(size.texture)})`);
			// The budget for a local .cpmmodel is exactly 30 kB, and past it the mod
			// demands an upload to a paste site. Better known here than at the end of
			// an export, where the levers are already out of reach.
			if (size.total > 30 * 1024) {
				lines.push('  over the 30 kB budget for a local .cpmmodel: File/Test ingame will still work, '
					+ 'but a normal export will ask you to upload the model. '
					+ 'Lower the sampling rate or transfer fewer animations to fit.');
			}
			// The viewer decides whether a model loads, and both defaults are easy to
			// exceed without noticing. Better said here than debugged in game.
			const boxes = out.stats.cubes + out.stats.bones;
			if (boxes > 256) lines.push(`WARNING: ${boxes} elements — over the default MAX_CUBE_COUNT of 256, `
				+ 'so other players will not see the model unless they raise it.');
			if (Math.max(built.size.width, built.size.height) > 256) {
				lines.push(`WARNING: the texture is ${built.size.width}×${built.size.height} — over the default `
					+ 'MAX_TEX_SHEET_SIZE of 256. The UV grid is free, the picture is not.');
			}
			for (const w of out.warnings) lines.push(`Warning: ${w}`);
			console.log('[geckolib-import] cpm export\n' + lines.join('\n'));

			Blockbench.export({
				type: 'Customizable Player Models Project',
				extensions: ['cpmproject'],
				name: (built.sourceName || 'model').replace(/\.[^.]*$/, ''),
				content: buf,
				savetype: 'buffer',
			});
			showImportReport({
				title: 'Exported to CPM',
				summary: [
					['Cubes', String(out.stats.cubes)],
					['Bones', String(out.stats.bones)],
					['Parts', parts.join(', ') || 'none'],
					['Scale', `×${form.scale.toFixed(2)}`],
					['UV grid', `×${uv.mul}`],
					['Animations', `${out.stats.anim.animations} (${out.stats.anim.frames} frames)`],
					['Encoded size', `~${(out.stats.size.total / 1024).toFixed(1)} kB`],
				],
				warning: boxes > 256
					? `${boxes} elements is over the default limit of 256: other players will not see this model `
						+ 'until they raise MAX_CUBE_COUNT.'
					: out.stats.size.total > 30 * 1024
						? `About ${(out.stats.size.total / 1024).toFixed(0)} kB, over the 30 kB budget for a local `
							+ '.cpmmodel. File/Test ingame still works; a normal export will ask you to upload.'
						: null,
				log: lines.join('\n'),
				name: (built.sourceName || 'model').replace(/\.[^.]*$/, ''),
			});
		});
	}).catch(e => {
		console.error('[geckolib-import] cpm export failed', e);
		Blockbench.showMessageBox({ title: 'CPM export failed', message: String((e && e.message) || e) });
	});
}

/**
 * The skin for the archive, as PNG bytes.
 *
 * A single PNG goes in as it came. Anything else — an atlas, or a JPEG from
 * Sketchfab — has to be redrawn through a canvas first: CPM reads skin.png with
 * an image decoder that expects a PNG, whatever the file is called.
 */
function cpmSkinBytes(built) {
	if (!built.needAtlas && built.images.length === 1 && built.images[0].mime === 'image/png') {
		return Promise.resolve(built.images[0].bytes);
	}
	return buildAtlasDataURL(built.images, built.layout).then(url => {
		if (!url) throw new Error('the texture could not be assembled');
		return base64ToBytes(url.slice(url.indexOf(',') + 1));
	});
}

function pickAndImport(opts, then) {
	Blockbench.import({
		extensions: ['zip'],
		type: 'Archive with a glTF model',
		readtype: 'buffer',
	}, files => {
		const file = files[0];
		if (!file) return;
		JSZip.loadAsync(file.content).then(zip => {
			const entries = {};
			const tasks = [];
			zip.forEach((relPath, entry) => {
				if (entry.dir) return;
				tasks.push(entry.async('uint8array').then(data => { entries[relPath] = data; }));
			});
			return Promise.all(tasks).then(() => {
				const built = buildFromFiles(entries, file.name, opts);
				if (then) then(built);
			});
		}).catch(e => {
			console.error('[geckolib-import] import failed', e);
			Blockbench.showMessageBox({ title: 'Import failed', message: String((e && e.message) || e) });
		});
	});
}

/**
 * An entry on the start screen, next to the formats.
 *
 * The import creates a project itself, so demanding an empty one beforehand is
 * pointless. Blockbench offers no API for adding custom tiles to the start
 * screen, so they are inserted into the DOM by hand: several selectors are
 * tried and the working one is recorded so diagnostics can show it.
 */
let startScreenStatus = 'not attempted';
let importFormat = null;

/**
 * The start screen entry.
 *
 * Blockbench offers no API for custom tiles, and inserting them into the DOM by
 * hand failed twice: custom markup drifted and looked paler than its neighbours,
 * and cloning a neighbour dragged its icon along. So a real ModelFormat is
 * registered — then Blockbench draws the tile itself, with proper spacing,
 * colour and highlighting — but project creation is swapped for the ZIP import.
 */
function registerStartScreenFormat() {
	try {
		if (typeof ModelFormat === 'undefined') { startScreenStatus = 'ModelFormat unavailable'; return; }
		importFormat = new ModelFormat({
			id: PLUGIN_ID + '_zip',
			name: 'GeckoLib from ZIP',
			description: 'glTF + texture → GeckoLib cubes or preserved Poly Mesh',
			icon: 'folder_zip',
			category: 'general',
			show_on_start_screen: true,
			// Without this the format page is empty: Blockbench does not know what to
			// write, nor what to call the action.
			format_page: {
			button_text: 'Select archive…',
			content: [
				{ type: 'h3', text: 'Model from a glTF archive' },
				{ type: 'text', text: 'Takes a .zip with a glTF model and its textures and builds '
					+ 'a finished GeckoLib project: bones, geometry, textures and animations.' },
				{ type: 'text', text: 'Requires the GeckoLib Animation Utils plugin — its format is '
					+ 'what the project is built into.' },
				{ type: 'text', text: 'Choose Cubes for the normal GeckoLib workflow, or Poly Mesh to keep '
					+ 'the original glTF triangles without box approximation.' },
				{ type: 'text', text: 'Size and orientation are detected automatically. Everything else '
					+ 'lives under «Advanced settings» in the import dialog.' },
			],
			},
		});
		// The format exists only for the tile: instead of an empty project it starts
		// the import, which creates the project itself.
		importFormat.new = function () { importFromZip(); return false; };
		startScreenStatus = 'registered ModelFormat ' + importFormat.id;
	} catch (e) {
		startScreenStatus = 'error: ' + ((e && e.message) || e);
	}
}

// ------------------------------------------------------- environment diagnostics

/**
 * Shows what is available inside Blockbench.
 *
 * A user's Blockbench build may have no developer console, so the plugin serves
 * as its own console: the result goes into a window from which it can be copied
 * in full.
 */
function environmentReport() {
	const has = v => { try { return typeof eval(v); } catch (e) { return 'none'; } };
	const keys = obj => { try { return Object.keys(obj).join(', '); } catch (e) { return '—'; } };

	const lines = [
		`Blockbench: ${typeof Blockbench !== 'undefined' && Blockbench.version || '?'}`,
		'',
		'— ZIP unpacking —',
		`JSZip: ${has('JSZip')}`,
		`fflate: ${has('fflate')}`,
		`require: ${has('require')}`,
		`window.require: ${typeof window !== 'undefined' ? typeof window.require : 'none'}`,
		'',
		'— formats —',
		`all: ${keys(typeof Formats !== 'undefined' ? Formats : {})}`,
		'',
		'— codecs —',
		`all: ${keys(typeof Codecs !== 'undefined' ? Codecs : {})}`,
		'',
		'— integration —',
		`start screen entry: ${startScreenStatus}`,
		`ModelFormat: ${has('ModelFormat')}`,
		`Animation: ${has('Animation')}, Group: ${has('Group')}`,
		'',
		'— plugins —',
		(() => {
			try { return 'installed: ' + Plugins.all.filter(p => p.installed).map(p => p.id).join(', '); }
			catch (e) { return 'Plugins unavailable: ' + e.message; }
		})(),
	];

	// anything resembling GeckoLib: the exact id is needed to declare a dependency
	try {
		const gecko = Object.keys(Formats).filter(f => /gecko|animated/i.test(f));
		lines.push('', `GeckoLib-like formats found: ${gecko.join(', ') || 'none'}`);
		const f = Formats[gecko[0]];
		if (f) lines.push(`  id=${f.id} name=${f.name} box_uv=${f.box_uv} rotation_limit=${f.rotation_limit}`);
	} catch (e) { lines.push('', 'GeckoLib check failed: ' + e.message); }

	return lines.join('\n');
}

function showEnvironment() {
	const text = environmentReport();
	console.log('[geckolib-import] environment\n' + text);
	new Dialog({
		id: PLUGIN_ID + '_env',
		title: 'Environment diagnostics',
		form: {
			hint: { type: 'info', text: 'Select the text and copy it (Ctrl+A, Ctrl+C).' },
			dump: { label: '', type: 'textarea', value: text, height: 420 },
		},
		singleButton: true,
	}).show();
}


// ------------------------------------------------------- Poly Mesh fuse tool

/** Return Mesh elements from the current selection, including meshes below selected Groups. */
function selectedPolyMeshes() {
	const found = [];
	const seenMeshes = new Set();
	const seenNodes = new Set();
	const addSelection = item => {
		if (!item) return;
		const nodeId = item.uuid || item;
		if (seenNodes.has(nodeId)) return;
		seenNodes.add(nodeId);

		if (typeof Mesh !== 'undefined' && item instanceof Mesh) {
			const id = item.uuid || item;
			if (!seenMeshes.has(id)) { seenMeshes.add(id); found.push(item); }
			return;
		}

		// Selecting envelope_strip000 in the Outliner should be enough to fuse the
		// complete strip: recurse through child bones and gather their Mesh elements.
		if (Array.isArray(item.children)) item.children.forEach(addSelection);
	};

	try {
		if (typeof Mesh !== 'undefined' && Array.isArray(Mesh.selected)) Mesh.selected.forEach(addSelection);
	} catch (e) { /* older Blockbench */ }
	try {
		if (typeof Outliner !== 'undefined' && Array.isArray(Outliner.selected)) Outliner.selected.forEach(addSelection);
	} catch (e) { /* older Blockbench */ }
	try {
		// Some builds expose selected elements through the generic selection array.
		if (typeof selected !== 'undefined' && Array.isArray(selected)) selected.forEach(addSelection);
	} catch (e) { /* optional API */ }
	return found;
}

/** Bake a Mesh element's own Euler rotation into one stored vertex. */
function bakeMeshPoint(mesh, point) {
	const origin = mesh.origin || [0, 0, 0];
	let x = Number(point[0]) || 0;
	let y = Number(point[1]) || 0;
	let z = Number(point[2]) || 0;
	const rot = mesh.rotation || [0, 0, 0];
	if (!rot[0] && !rot[1] && !rot[2]) return [x, y, z];

	x -= origin[0]; y -= origin[1]; z -= origin[2];
	const rx = rot[0] * Math.PI / 180;
	const ry = rot[1] * Math.PI / 180;
	const rz = rot[2] * Math.PI / 180;
	let t = y; y = y * Math.cos(rx) - z * Math.sin(rx); z = t * Math.sin(rx) + z * Math.cos(rx);
	t = x; x = x * Math.cos(ry) + z * Math.sin(ry); z = -t * Math.sin(ry) + z * Math.cos(ry);
	t = x; x = x * Math.cos(rz) - y * Math.sin(rz); y = t * Math.sin(rz) + y * Math.cos(rz);
	return [x + origin[0], y + origin[1], z + origin[2]];
}

function meshParentLabel(mesh) {
	const p = mesh && mesh.parent;
	if (!p || p === 'root') return 'root';
	return p.name || p.uuid || 'root';
}

/**
 * Merge selected Mesh elements into one rigid Mesh and parent it to the chosen
 * source mesh's bone. This is primarily for rigid props that a glTF skin split
 * over several joints even though the object should animate as one piece.
 *
 * The imported Poly Mesh path stores vertices in model coordinates and its
 * element rotations are normally zero. We still bake element rotation here so
 * the command remains safe after manual Blockbench edits.
 */
function fuseSelectedPolyMeshes(options) {
	const meshes = selectedPolyMeshes();
	if (meshes.length < 2) {
		Blockbench.showQuickMessage('Select at least two Mesh elements to fuse', 2200);
		return;
	}

	const target = meshes.find(m => m.uuid === options.target_mesh) || meshes[0];
	const targetParent = target.parent && target.parent !== 'root' ? target.parent : 'root';
	const fusedName = String(options.name || (target.name + '_fused')).trim() || 'fused_mesh';
	const fused = new Mesh({
		name: fusedName,
		origin: [0, 0, 0],
		rotation: [0, 0, 0],
		autouv: 0,
		vertices: {},
	});
	const newFaces = [];
	let vertexCount = 0;
	let faceCount = 0;

	for (const src of meshes) {
		const keyMap = new Map();
		for (const oldKey in src.vertices) {
			const newKey = typeof guid === 'function' ? guid() : `fv_${vertexCount}_${oldKey}`;
			keyMap.set(oldKey, newKey);
			fused.vertices[newKey] = bakeMeshPoint(src, src.vertices[oldKey]);
			vertexCount++;
		}

		for (const faceKey in src.faces) {
			const face = src.faces[faceKey];
			const oldVertices = (face.vertices || []).slice();
			if (oldVertices.length < 3) continue;
			const verts = oldVertices.map(k => keyMap.get(k)).filter(Boolean);
			if (verts.length < 3) continue;
			const uv = {};
			for (const oldKey of oldVertices) {
				const nk = keyMap.get(oldKey);
				if (!nk) continue;
				const srcUV = face.uv && face.uv[oldKey] ? face.uv[oldKey] : [0, 0];
				uv[nk] = [Number(srcUV[0]) || 0, Number(srcUV[1]) || 0];
			}
			newFaces.push(new MeshFace(fused, {
				vertices: verts,
				uv,
				texture: face.texture || undefined,
			}));
			faceCount++;
		}
	}

	if (!faceCount) {
		Blockbench.showQuickMessage('The selected meshes contain no polygon faces', 2400);
		return;
	}

	try {
		if (typeof Undo !== 'undefined' && Undo.initEdit) Undo.initEdit({ elements: meshes, outliner: true });
	} catch (e) { /* undo is best effort */ }

	if (targetParent && targetParent !== 'root' && typeof fused.addTo === 'function') fused.addTo(targetParent);
	else fused.addTo('root');
	fused.addFaces(...newFaces);
	fused.init();

	if (options.delete_sources !== false) {
		for (const src of meshes) {
			try { src.remove(); } catch (e) {
				try { src.removeFromParent && src.removeFromParent(); } catch (e2) { /* best effort */ }
			}
		}
	}

	try {
		if (typeof Undo !== 'undefined' && Undo.finishEdit) Undo.finishEdit('Fuse selected Poly Meshes');
	} catch (e) { /* best effort */ }
	try {
		if (typeof Outliner !== 'undefined' && Outliner.select) Outliner.select(fused);
		else if (fused.select) fused.select();
	} catch (e) { /* selection is cosmetic */ }
	Canvas.updateAll();
	Blockbench.showQuickMessage(`Fused ${meshes.length} meshes → ${fusedName} (${faceCount} faces)`, 3000);
}

function openFusePolyMeshesDialog() {
	const meshes = selectedPolyMeshes();
	if (meshes.length < 2) {
		Blockbench.showMessageBox({
			title: 'Fuse Poly Meshes',
			message: 'Select at least two Mesh elements, or select a bone/group containing them. Child meshes are collected recursively and will become one rigid mesh.',
		});
		return;
	}
	const targetOptions = {};
	for (const m of meshes) targetOptions[m.uuid] = `${m.name}  →  ${meshParentLabel(m)}`;
	const first = meshes[0];

	new Dialog({
		id: PLUGIN_ID + '_fuse_poly_meshes',
		title: 'Fuse Selected Poly Meshes',
		form: {
			target_mesh: {
				label: 'Bone / parent to keep', type: 'select', default: first.uuid,
				options: targetOptions,
			},
			name: { label: 'Fused mesh name', type: 'text', value: (first.name || 'mesh') + '_fused' },
			delete_sources: { label: 'Delete source meshes', type: 'checkbox', value: true },
			hint: {
				type: 'info',
				text: 'All selected polygons are combined into one Mesh and assigned to the selected parent bone. '
					+ 'Use this for rigid objects (case, envelope, weapon part, etc.) that were split across several glTF joints and tear apart when animated. '
					+ 'Do not use it on parts that are supposed to deform or follow different bones.',
			},
		},
		onConfirm(form) { this.hide(); fuseSelectedPolyMeshes(form); },
	}).show();
}

// ------------------------------------------------------------- registration

let action;
let fusePolyMeshesAction;
let envAction;
let importAction;
let sketchfabAction;
let cpmAction;

Plugin.register(PLUGIN_ID, {
	title: 'GeckoLib Model Importer',
	author: 'MopicMP',
	icon: 'view_in_ar',
	description: 'Import glTF models — including straight from Sketchfab — into GeckoLib as cubes or preserved Poly Mesh geometry, or turn them into a Customizable Player Models skin.',
	version: '0.1.12-native-weighted-preview',
	variant: 'both',
	min_version: '4.9.0',
	tags: ['Minecraft: Java Edition', 'Import', 'Animation'],
	website: 'https://github.com/MopicMP/geckolib-model-importer',
	repository: 'https://github.com/MopicMP/geckolib-model-importer',
	bug_tracker: 'https://github.com/MopicMP/geckolib-model-importer/issues',
	creation_date: '2026-08-01',

	onload() {
		enableGeckoMeshEditing();
		installPolyMeshExporter();

		action = new Action(PLUGIN_ID, {
			name: 'Convert Meshes to Cubes',
			description: 'Converts box-shaped meshes into Cubes, carrying the UV over',
			icon: 'view_in_ar',
			condition: () => typeof Mesh !== 'undefined' && Mesh.all.length > 0,
			click() {
				new Dialog({
					id: PLUGIN_ID + '_dialog',
					title: 'Mesh → Cubes',
					form: {
						selected_only: { label: 'Selected only', type: 'checkbox', value: false },
						delete_meshes: { label: 'Delete the source meshes', type: 'checkbox', value: false },
						mirror_mode: {
							label: 'Mirrored UV', type: 'select', default: 'source',
							options: { source: 'As in the source', off: 'Disable mirroring' },
						},
						hint: {
							type: 'info',
							text: 'Run it once without deleting and compare by eye. ' +
								'The meshes are kept regardless if even one object fails to convert.\n\n' +
								'If some textures look mirrored, run again with Disable mirroring ' +
								'and compare which result is closer to the source meshes.',
						},
					},
					onConfirm(form) { this.hide(); runConversion(form); },
				}).show();
			},
		});
		MenuBar.addAction(action, 'filter');

		fusePolyMeshesAction = new Action(PLUGIN_ID + '_fuse_poly_meshes', {
			name: 'Fuse Selected Poly Meshes',
			description: 'Combine selected meshes (including meshes below selected groups) into one rigid mesh on one chosen bone',
			icon: 'merge_type',
			condition: () => typeof Mesh !== 'undefined' && selectedPolyMeshes().length >= 2,
			click: openFusePolyMeshesDialog,
		});
		MenuBar.addAction(fusePolyMeshesAction, 'filter');

		envAction = new Action(PLUGIN_ID + '_env', {
			name: 'Environment diagnostics (GeckoLib Importer)',
			description: 'Shows what is available inside Blockbench: ZIP, formats, codecs',
			icon: 'bug_report',
			click: showEnvironment,
		});
		MenuBar.addAction(envAction, 'help');

		importAction = new Action(PLUGIN_ID + '_import', {
			name: 'GeckoLib from ZIP (glTF + texture)',
			description: 'Builds a ready GeckoLib model from an archive with glTF and textures',
			icon: 'folder_zip',
			// the import creates a project itself, so it needs no open project
			condition: () => true,
			click: importFromZip,
		});
		MenuBar.addAction(importAction, 'file');

		cpmAction = new Action(PLUGIN_ID + '_cpm', {
			name: 'Customizable Player Models from ZIP (glTF + texture)',
			description: 'Same import, saved as a .cpmproject for the CPM mod',
			icon: 'accessibility_new',
			condition: () => true,
			click: importCPMFromZip,
		});
		MenuBar.addAction(cpmAction, 'file');

		sketchfabAction = new Action(PLUGIN_ID + '_sketchfab', {
			name: 'Sketchfab — model search',
			description: 'Search and download downloadable models straight from Blockbench',
			icon: 'travel_explore',
			condition: () => true,
			click: openSketchfabBrowser,
		});
		MenuBar.addAction(sketchfabAction, 'file');

		registerStartScreenFormat();
	},

	onunload() {
		uninstallWeightedSkinPreview();
		uninstallPolyMeshExporter();
		if (action) action.delete();
		if (fusePolyMeshesAction) fusePolyMeshesAction.delete();
		if (envAction) envAction.delete();
		if (importAction) importAction.delete();
		if (cpmAction) cpmAction.delete();
		if (sketchfabAction) sketchfabAction.delete();
		if (importFormat && importFormat.delete) importFormat.delete();
		if (sketchfabCSS && sketchfabCSS.delete) sketchfabCSS.delete();
	},
});

})();
